# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
from collections import deque
from bstack_utils.constants import *
class bstack1ll1l1ll1l_opy_:
    def __init__(self):
        self._11l1ll1111_opy_ = deque()
        self._11l1ll1l11_opy_ = {}
        self._11l1l1l111_opy_ = False
    def bstack11l1l1ll1l_opy_(self, test_name, bstack11l1ll1l1l_opy_):
        bstack11l1l1l11l_opy_ = self._11l1ll1l11_opy_.get(test_name, {})
        return bstack11l1l1l11l_opy_.get(bstack11l1ll1l1l_opy_, 0)
    def bstack11l1l1ll11_opy_(self, test_name, bstack11l1ll1l1l_opy_):
        bstack11l1ll11ll_opy_ = self.bstack11l1l1ll1l_opy_(test_name, bstack11l1ll1l1l_opy_)
        self.bstack11l1l1lll1_opy_(test_name, bstack11l1ll1l1l_opy_)
        return bstack11l1ll11ll_opy_
    def bstack11l1l1lll1_opy_(self, test_name, bstack11l1ll1l1l_opy_):
        if test_name not in self._11l1ll1l11_opy_:
            self._11l1ll1l11_opy_[test_name] = {}
        bstack11l1l1l11l_opy_ = self._11l1ll1l11_opy_[test_name]
        bstack11l1ll11ll_opy_ = bstack11l1l1l11l_opy_.get(bstack11l1ll1l1l_opy_, 0)
        bstack11l1l1l11l_opy_[bstack11l1ll1l1l_opy_] = bstack11l1ll11ll_opy_ + 1
    def bstack1ll1111l11_opy_(self, bstack11l1ll11l1_opy_, bstack11l1ll111l_opy_):
        bstack11l1l1l1ll_opy_ = self.bstack11l1l1ll11_opy_(bstack11l1ll11l1_opy_, bstack11l1ll111l_opy_)
        event_name = bstack11llll1l1l_opy_[bstack11l1ll111l_opy_]
        bstack11l1l1llll_opy_ = bstack1l11ll_opy_ (u"ࠢࡼࡿ࠰ࡿࢂ࠳ࡻࡾࠤቮ").format(bstack11l1ll11l1_opy_, event_name, bstack11l1l1l1ll_opy_)
        self._11l1ll1111_opy_.append(bstack11l1l1llll_opy_)
    def bstack1ll111l11_opy_(self):
        return len(self._11l1ll1111_opy_) == 0
    def bstack11l111l11_opy_(self):
        bstack11l1l1l1l1_opy_ = self._11l1ll1111_opy_.popleft()
        return bstack11l1l1l1l1_opy_
    def capturing(self):
        return self._11l1l1l111_opy_
    def bstack1llllll1ll_opy_(self):
        self._11l1l1l111_opy_ = True
    def bstack111ll1l1l_opy_(self):
        self._11l1l1l111_opy_ = False
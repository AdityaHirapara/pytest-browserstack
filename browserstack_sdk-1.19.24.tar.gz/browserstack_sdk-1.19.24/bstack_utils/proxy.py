# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.messages import bstack1l1111ll1l_opy_
def bstack1l1111ll11_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1l1111llll_opy_(bstack1l1111l1ll_opy_, bstack1l111l111l_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1l1111l1ll_opy_):
        with open(bstack1l1111l1ll_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1l1111ll11_opy_(bstack1l1111l1ll_opy_):
        pac = get_pac(url=bstack1l1111l1ll_opy_)
    else:
        raise Exception(bstack1l11ll_opy_ (u"ࠩࡓࡥࡨࠦࡦࡪ࡮ࡨࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡥࡹ࡫ࡶࡸ࠿ࠦࡻࡾࠩ๫").format(bstack1l1111l1ll_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack1l11ll_opy_ (u"ࠥ࠼࠳࠾࠮࠹࠰࠻ࠦ๬"), 80))
        bstack1l1111lll1_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1l1111lll1_opy_ = bstack1l11ll_opy_ (u"ࠫ࠵࠴࠰࠯࠲࠱࠴ࠬ๭")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1l111l111l_opy_, bstack1l1111lll1_opy_)
    return proxy_url
def bstack1lll111l1l_opy_(config):
    return bstack1l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨ๮") in config or bstack1l11ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪ๯") in config
def bstack11ll1ll1_opy_(config):
    if not bstack1lll111l1l_opy_(config):
        return
    if config.get(bstack1l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡕࡸ࡯ࡹࡻࠪ๰")):
        return config.get(bstack1l11ll_opy_ (u"ࠨࡪࡷࡸࡵࡖࡲࡰࡺࡼࠫ๱"))
    if config.get(bstack1l11ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࡑࡴࡲࡼࡾ࠭๲")):
        return config.get(bstack1l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧ๳"))
def bstack1111l1111_opy_(config, bstack1l111l111l_opy_):
    proxy = bstack11ll1ll1_opy_(config)
    proxies = {}
    if config.get(bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡒࡵࡳࡽࡿࠧ๴")) or config.get(bstack1l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩ๵")):
        if proxy.endswith(bstack1l11ll_opy_ (u"࠭࠮ࡱࡣࡦࠫ๶")):
            proxies = bstack1ll111ll11_opy_(proxy, bstack1l111l111l_opy_)
        else:
            proxies = {
                bstack1l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸ࠭๷"): proxy
            }
    return proxies
def bstack1ll111ll11_opy_(bstack1l1111l1ll_opy_, bstack1l111l111l_opy_):
    proxies = {}
    global bstack1l111l1111_opy_
    if bstack1l11ll_opy_ (u"ࠨࡒࡄࡇࡤࡖࡒࡐ࡚࡜ࠫ๸") in globals():
        return bstack1l111l1111_opy_
    try:
        proxy = bstack1l1111llll_opy_(bstack1l1111l1ll_opy_, bstack1l111l111l_opy_)
        if bstack1l11ll_opy_ (u"ࠤࡇࡍࡗࡋࡃࡕࠤ๹") in proxy:
            proxies = {}
        elif bstack1l11ll_opy_ (u"ࠥࡌ࡙࡚ࡐࠣ๺") in proxy or bstack1l11ll_opy_ (u"ࠦࡍ࡚ࡔࡑࡕࠥ๻") in proxy or bstack1l11ll_opy_ (u"࡙ࠧࡏࡄࡍࡖࠦ๼") in proxy:
            bstack1l1111l1l1_opy_ = proxy.split(bstack1l11ll_opy_ (u"ࠨࠠࠣ๽"))
            if bstack1l11ll_opy_ (u"ࠢ࠻࠱࠲ࠦ๾") in bstack1l11ll_opy_ (u"ࠣࠤ๿").join(bstack1l1111l1l1_opy_[1:]):
                proxies = {
                    bstack1l11ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ຀"): bstack1l11ll_opy_ (u"ࠥࠦກ").join(bstack1l1111l1l1_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࠪຂ"): str(bstack1l1111l1l1_opy_[0]).lower() + bstack1l11ll_opy_ (u"ࠧࡀ࠯࠰ࠤ຃") + bstack1l11ll_opy_ (u"ࠨࠢຄ").join(bstack1l1111l1l1_opy_[1:])
                }
        elif bstack1l11ll_opy_ (u"ࠢࡑࡔࡒ࡜࡞ࠨ຅") in proxy:
            bstack1l1111l1l1_opy_ = proxy.split(bstack1l11ll_opy_ (u"ࠣࠢࠥຆ"))
            if bstack1l11ll_opy_ (u"ࠤ࠽࠳࠴ࠨງ") in bstack1l11ll_opy_ (u"ࠥࠦຈ").join(bstack1l1111l1l1_opy_[1:]):
                proxies = {
                    bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࠪຉ"): bstack1l11ll_opy_ (u"ࠧࠨຊ").join(bstack1l1111l1l1_opy_[1:])
                }
            else:
                proxies = {
                    bstack1l11ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࠬ຋"): bstack1l11ll_opy_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࠣຌ") + bstack1l11ll_opy_ (u"ࠣࠤຍ").join(bstack1l1111l1l1_opy_[1:])
                }
        else:
            proxies = {
                bstack1l11ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࠨຎ"): proxy
            }
    except Exception as e:
        print(bstack1l11ll_opy_ (u"ࠥࡷࡴࡳࡥࠡࡧࡵࡶࡴࡸࠢຏ"), bstack1l1111ll1l_opy_.format(bstack1l1111l1ll_opy_, str(e)))
    bstack1l111l1111_opy_ = proxies
    return proxies
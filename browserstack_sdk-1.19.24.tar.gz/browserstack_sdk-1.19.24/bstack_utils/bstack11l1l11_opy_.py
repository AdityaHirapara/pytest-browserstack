# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import datetime
import json
import logging
import os
import threading
from bstack_utils.helper import bstack11ll1l11l1_opy_, bstack1lll11111_opy_, get_host_info, bstack11ll1ll1l1_opy_, bstack11lll11lll_opy_, bstack11ll11ll1l_opy_, \
    bstack11lll11l11_opy_, bstack11ll1lll11_opy_, bstack1l111ll11_opy_, bstack11ll11lll1_opy_, is_true, bstack1lll1l1_opy_
from bstack_utils.bstack11ll1ll111_opy_ import bstack11lll1111l_opy_
from bstack_utils.bstack1lll1ll_opy_ import bstack1ll1lll_opy_
import bstack_utils.bstack1lll11l1_opy_ as bstack1lll1ll1_opy_
from bstack_utils.constants import bstack11llll1l11_opy_
bstack11ll1l11ll_opy_ = [
    bstack1l11ll_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨᅌ"), bstack1l11ll_opy_ (u"ࠬࡉࡂࡕࡕࡨࡷࡸ࡯࡯࡯ࡅࡵࡩࡦࡺࡥࡥࠩᅍ"), bstack1l11ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨᅎ"), bstack1l11ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔ࡭࡬ࡴࡵ࡫ࡤࠨᅏ"),
    bstack1l11ll_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᅐ"), bstack1l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪᅑ"), bstack1l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫᅒ")
]
bstack11ll1lllll_opy_ = bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࡯࡭࡮ࡨࡧࡹࡵࡲ࠮ࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰࠫᅓ")
logger = logging.getLogger(__name__)
class bstack111lll1_opy_:
    bstack11ll1ll111_opy_ = None
    bs_config = None
    @classmethod
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def launch(cls, bs_config, bstack11lll1l111_opy_):
        cls.bs_config = bs_config
        cls.bstack11ll11l1l1_opy_()
        bstack11ll11ll11_opy_ = bstack11ll1ll1l1_opy_(bs_config)
        bstack11ll1llll1_opy_ = bstack11lll11lll_opy_(bs_config)
        bstack1ll1l1l11l_opy_ = False
        bstack1ll111l1l1_opy_ = False
        if bstack1l11ll_opy_ (u"ࠬࡧࡰࡱࠩᅔ") in bs_config:
            bstack1ll1l1l11l_opy_ = True
        else:
            bstack1ll111l1l1_opy_ = True
        bstack1l1l11111l_opy_ = {
            bstack1l11ll_opy_ (u"࠭࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ᅕ"): cls.bstack1lll1ll11l_opy_(bstack11lll1l111_opy_.get(bstack1l11ll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡹࡸ࡫ࡤࠨᅖ"), bstack1l11ll_opy_ (u"ࠨࠩᅗ"))) and cls.bstack11ll1lll1l_opy_(bstack11lll1l111_opy_.get(bstack1l11ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡻࡳࡦࡦࠪᅘ"), bstack1l11ll_opy_ (u"ࠪࠫᅙ"))),
            bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫᅚ"): bstack1lll1ll1_opy_.bstack11ll1111_opy_(bs_config),
            bstack1l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼࠫᅛ"): bs_config.get(bstack1l11ll_opy_ (u"࠭ࡰࡦࡴࡦࡽࠬᅜ"), False),
            bstack1l11ll_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡦࠩᅝ"): bstack1ll111l1l1_opy_,
            bstack1l11ll_opy_ (u"ࠨࡣࡳࡴࡤࡧࡵࡵࡱࡰࡥࡹ࡫ࠧᅞ"): bstack1ll1l1l11l_opy_
        }
        data = {
            bstack1l11ll_opy_ (u"ࠩࡩࡳࡷࡳࡡࡵࠩᅟ"): bstack1l11ll_opy_ (u"ࠪ࡮ࡸࡵ࡮ࠨᅠ"),
            bstack1l11ll_opy_ (u"ࠫࡵࡸ࡯࡫ࡧࡦࡸࡤࡴࡡ࡮ࡧࠪᅡ"): bs_config.get(bstack1l11ll_opy_ (u"ࠬࡶࡲࡰ࡬ࡨࡧࡹࡔࡡ࡮ࡧࠪᅢ"), bstack1l11ll_opy_ (u"࠭ࠧᅣ")),
            bstack1l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᅤ"): bs_config.get(bstack1l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫᅥ"), os.path.basename(os.path.abspath(os.getcwd()))),
            bstack1l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬᅦ"): bs_config.get(bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬᅧ")),
            bstack1l11ll_opy_ (u"ࠫࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩᅨ"): bs_config.get(bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡈࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨᅩ"), bstack1l11ll_opy_ (u"࠭ࠧᅪ")),
            bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࠫᅫ"): datetime.datetime.now().isoformat(),
            bstack1l11ll_opy_ (u"ࠨࡶࡤ࡫ࡸ࠭ᅬ"): bstack11ll11ll1l_opy_(bs_config),
            bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡸࡺ࡟ࡪࡰࡩࡳࠬᅭ"): get_host_info(),
            bstack1l11ll_opy_ (u"ࠪࡧ࡮ࡥࡩ࡯ࡨࡲࠫᅮ"): bstack1lll11111_opy_(),
            bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢࡶࡺࡴ࡟ࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫᅯ"): os.environ.get(bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡇ࡛ࡉࡍࡆࡢࡖ࡚ࡔ࡟ࡊࡆࡈࡒ࡙ࡏࡆࡊࡇࡕࠫᅰ")),
            bstack1l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩࡥࡴࡦࡵࡷࡷࡤࡸࡥࡳࡷࡱࠫᅱ"): os.environ.get(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡒࡆࡔࡘࡒࠬᅲ"), False),
            bstack1l11ll_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࡡࡦࡳࡳࡺࡲࡰ࡮ࠪᅳ"): bstack11ll1l11l1_opy_(),
            bstack1l11ll_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࡢࡱࡦࡶࠧᅴ"): bstack1l1l11111l_opy_,
            bstack1l11ll_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࡢࡺࡪࡸࡳࡪࡱࡱࠫᅵ"): {
                bstack1l11ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࡎࡢ࡯ࡨࠫᅶ"): bstack11lll1l111_opy_.get(bstack1l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡰࡤࡱࡪ࠭ᅷ"), bstack1l11ll_opy_ (u"࠭ࡐࡺࡶࡨࡷࡹ࠭ᅸ")),
                bstack1l11ll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭࡙ࡩࡷࡹࡩࡰࡰࠪᅹ"): bstack11lll1l111_opy_.get(bstack1l11ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᅺ")),
                bstack1l11ll_opy_ (u"ࠩࡶࡨࡰ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᅻ"): bstack11lll1l111_opy_.get(bstack1l11ll_opy_ (u"ࠪࡷࡩࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨᅼ"))
            }
        }
        config = {
            bstack1l11ll_opy_ (u"ࠫࡦࡻࡴࡩࠩᅽ"): (bstack11ll11ll11_opy_, bstack11ll1llll1_opy_),
            bstack1l11ll_opy_ (u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭ᅾ"): cls.default_headers()
        }
        response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"࠭ࡐࡐࡕࡗࠫᅿ"), cls.request_url(bstack1l11ll_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡣࡷ࡬ࡰࡩࡹࠧᆀ")), data, config)
        if response.status_code != 200:
            os.environ[bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉ࠭ᆁ")] = bstack1l11ll_opy_ (u"ࠩࡱࡹࡱࡲࠧᆂ")
            os.environ[bstack1l11ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡃࡐࡏࡓࡐࡊ࡚ࡅࡅࠩᆃ")] = bstack1l11ll_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪᆄ")
            os.environ[bstack1l11ll_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡍ࡛࡙࠭ᆅ")] = bstack1l11ll_opy_ (u"࠭࡮ࡶ࡮࡯ࠫᆆ")
            os.environ[bstack1l11ll_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉ࠭ᆇ")] = bstack1l11ll_opy_ (u"ࠣࡰࡸࡰࡱࠨᆈ")
            os.environ[bstack1l11ll_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡁࡍࡎࡒ࡛ࡤ࡙ࡃࡓࡇࡈࡒࡘࡎࡏࡕࡕࠪᆉ")] = bstack1l11ll_opy_ (u"ࠥࡲࡺࡲ࡬ࠣᆊ")
            bstack11ll1ll1ll_opy_ = response.json()
            if bstack11ll1ll1ll_opy_ and bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᆋ")]:
                error_message = bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᆌ")]
                if bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"࠭ࡥࡳࡴࡲࡶ࡙ࡿࡰࡦࠩᆍ")] == bstack1l11ll_opy_ (u"ࠧࡆࡔࡕࡓࡗࡥࡉࡏࡘࡄࡐࡎࡊ࡟ࡄࡔࡈࡈࡊࡔࡔࡊࡃࡏࡗࠬᆎ"):
                    logger.error(error_message)
                elif bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠨࡧࡵࡶࡴࡸࡔࡺࡲࡨࠫᆏ")] == bstack1l11ll_opy_ (u"ࠩࡈࡖࡗࡕࡒࡠࡃࡆࡇࡊ࡙ࡓࡠࡆࡈࡒࡎࡋࡄࠨᆐ"):
                    logger.info(error_message)
                elif bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࡖࡼࡴࡪ࠭ᆑ")] == bstack1l11ll_opy_ (u"ࠫࡊࡘࡒࡐࡔࡢࡗࡉࡑ࡟ࡅࡇࡓࡖࡊࡉࡁࡕࡇࡇࠫᆒ"):
                    logger.error(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack1l11ll_opy_ (u"ࠧࡊࡡࡵࡣࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯࡚ࠥࡥࡴࡶࠣࡓࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠣࡪࡦ࡯࡬ࡦࡦࠣࡨࡺ࡫ࠠࡵࡱࠣࡷࡴࡳࡥࠡࡧࡵࡶࡴࡸࠢᆓ"))
            return [None, None, None]
        bstack11ll1ll1ll_opy_ = response.json()
        os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡕࡖࡋࡇࠫᆔ")] = bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩᆕ")]
        if cls.bstack1lll1ll11l_opy_(bstack11lll1l111_opy_.get(bstack1l11ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡺࡹࡥࡥࠩᆖ"), bstack1l11ll_opy_ (u"ࠩࠪᆗ"))) is True and cls.bstack11ll1lll1l_opy_(bstack11lll1l111_opy_.get(bstack1l11ll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡵࡴࡧࡧࠫᆘ"), bstack1l11ll_opy_ (u"ࠫࠬᆙ"))):
            logger.debug(bstack1l11ll_opy_ (u"࡚ࠬࡥࡴࡶࠣࡓࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠣࡆࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤࡘࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬ࠢࠩᆚ"))
            os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡆࡓࡒࡖࡌࡆࡖࡈࡈࠬᆛ")] = bstack1l11ll_opy_ (u"ࠧࡵࡴࡸࡩࠬᆜ")
            if bstack11ll1ll1ll_opy_.get(bstack1l11ll_opy_ (u"ࠨ࡬ࡺࡸࠬᆝ")):
                os.environ[bstack1l11ll_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪᆞ")] = bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠪ࡮ࡼࡺࠧᆟ")]
                os.environ[bstack1l11ll_opy_ (u"ࠫࡈࡘࡅࡅࡇࡑࡘࡎࡇࡌࡔࡡࡉࡓࡗࡥࡃࡓࡃࡖࡌࡤࡘࡅࡑࡑࡕࡘࡎࡔࡇࠨᆠ")] = json.dumps({
                    bstack1l11ll_opy_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧᆡ"): bstack11ll11ll11_opy_,
                    bstack1l11ll_opy_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨᆢ"): bstack11ll1llll1_opy_
                })
            if bstack11ll1ll1ll_opy_.get(bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩᆣ")):
                os.environ[bstack1l11ll_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡍࡇࡓࡉࡇࡇࡣࡎࡊࠧᆤ")] = bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫᆥ")]
            if bstack11ll1ll1ll_opy_.get(bstack1l11ll_opy_ (u"ࠪࡥࡱࡲ࡯ࡸࡡࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹࡹࠧᆦ")):
                os.environ[bstack1l11ll_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡃࡏࡐࡔ࡝࡟ࡔࡅࡕࡉࡊࡔࡓࡉࡑࡗࡗࠬᆧ")] = str(bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠬࡧ࡬࡭ࡱࡺࡣࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࡴࠩᆨ")])
        return [bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"࠭ࡪࡸࡶࠪᆩ")], bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩᆪ")], bstack11ll1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠨࡣ࡯ࡰࡴࡽ࡟ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬᆫ")]]
    @classmethod
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def stop(cls):
        if not cls.on():
            return
        if os.environ[bstack1l11ll_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪᆬ")] == bstack1l11ll_opy_ (u"ࠥࡲࡺࡲ࡬ࠣᆭ") or os.environ[bstack1l11ll_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡄࡘࡍࡑࡊ࡟ࡉࡃࡖࡌࡊࡊ࡟ࡊࡆࠪᆮ")] == bstack1l11ll_opy_ (u"ࠧࡴࡵ࡭࡮ࠥᆯ"):
            print(bstack1l11ll_opy_ (u"࠭ࡅ࡙ࡅࡈࡔ࡙ࡏࡏࡏࠢࡌࡒࠥࡹࡴࡰࡲࡅࡹ࡮ࡲࡤࡖࡲࡶࡸࡷ࡫ࡡ࡮ࠢࡕࡉࡖ࡛ࡅࡔࡖࠣࡘࡔࠦࡔࡆࡕࡗࠤࡔࡈࡓࡆࡔ࡙ࡅࡇࡏࡌࡊࡖ࡜ࠤ࠿ࠦࡍࡪࡵࡶ࡭ࡳ࡭ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡶࡲ࡯ࡪࡴࠧᆰ"))
            return {
                bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧᆱ"): bstack1l11ll_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧᆲ"),
                bstack1l11ll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᆳ"): bstack1l11ll_opy_ (u"ࠪࡘࡴࡱࡥ࡯࠱ࡥࡹ࡮ࡲࡤࡊࡆࠣ࡭ࡸࠦࡵ࡯ࡦࡨࡪ࡮ࡴࡥࡥ࠮ࠣࡦࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤࡲ࡯ࡧࡩࡶࠣ࡬ࡦࡼࡥࠡࡨࡤ࡭ࡱ࡫ࡤࠨᆴ")
            }
        else:
            cls.bstack11ll1ll111_opy_.shutdown()
            data = {
                bstack1l11ll_opy_ (u"ࠫࡸࡺ࡯ࡱࡡࡷ࡭ࡲ࡫ࠧᆵ"): datetime.datetime.now().isoformat()
            }
            config = {
                bstack1l11ll_opy_ (u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭ᆶ"): cls.default_headers()
            }
            bstack11ll1l1111_opy_ = bstack1l11ll_opy_ (u"࠭ࡡࡱ࡫࠲ࡺ࠶࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾ࠱ࡶࡸࡴࡶࠧᆷ").format(os.environ[bstack1l11ll_opy_ (u"ࠢࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉࠨᆸ")])
            bstack11ll1l111l_opy_ = cls.request_url(bstack11ll1l1111_opy_)
            response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"ࠨࡒࡘࡘࠬᆹ"), bstack11ll1l111l_opy_, data, config)
            if not response.ok:
                raise Exception(bstack1l11ll_opy_ (u"ࠤࡖࡸࡴࡶࠠࡳࡧࡴࡹࡪࡹࡴࠡࡰࡲࡸࠥࡵ࡫ࠣᆺ"))
    @classmethod
    def bstack11l1111_opy_(cls):
        if cls.bstack11ll1ll111_opy_ is None:
            return
        cls.bstack11ll1ll111_opy_.shutdown()
    @classmethod
    def bstack1ll1l1lll_opy_(cls):
        if cls.on():
            print(
                bstack1l11ll_opy_ (u"࡚ࠪ࡮ࡹࡩࡵࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾࠢࡷࡳࠥࡼࡩࡦࡹࠣࡦࡺ࡯࡬ࡥࠢࡵࡩࡵࡵࡲࡵ࠮ࠣ࡭ࡳࡹࡩࡨࡪࡷࡷ࠱ࠦࡡ࡯ࡦࠣࡱࡦࡴࡹࠡ࡯ࡲࡶࡪࠦࡤࡦࡤࡸ࡫࡬࡯࡮ࡨࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴࠠࡢ࡮࡯ࠤࡦࡺࠠࡰࡰࡨࠤࡵࡲࡡࡤࡧࠤࡠࡳ࠭ᆻ").format(os.environ[bstack1l11ll_opy_ (u"ࠦࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡄࡘࡍࡑࡊ࡟ࡉࡃࡖࡌࡊࡊ࡟ࡊࡆࠥᆼ")]))
    @classmethod
    def bstack11ll11l1l1_opy_(cls):
        if cls.bstack11ll1ll111_opy_ is not None:
            return
        cls.bstack11ll1ll111_opy_ = bstack11lll1111l_opy_(cls.bstack11ll11l11l_opy_)
        cls.bstack11ll1ll111_opy_.start()
    @classmethod
    def bstack1lllllll_opy_(cls, bstack11ll11l_opy_, bstack11lll11ll1_opy_=bstack1l11ll_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡡࡵࡥ࡫ࠫᆽ")):
        if not cls.on():
            return
        bstack111l11ll_opy_ = bstack11ll11l_opy_[bstack1l11ll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪᆾ")]
        bstack11ll1l1lll_opy_ = {
            bstack1l11ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨᆿ"): bstack1l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡥࡓࡵࡣࡵࡸࡤ࡛ࡰ࡭ࡱࡤࡨࠬᇀ"),
            bstack1l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫᇁ"): bstack1l11ll_opy_ (u"ࠪࡘࡪࡹࡴࡠࡇࡱࡨࡤ࡛ࡰ࡭ࡱࡤࡨࠬᇂ"),
            bstack1l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡱࡩࡱࡲࡨࡨࠬᇃ"): bstack1l11ll_opy_ (u"࡚ࠬࡥࡴࡶࡢࡗࡰ࡯ࡰࡱࡧࡧࡣ࡚ࡶ࡬ࡰࡣࡧࠫᇄ"),
            bstack1l11ll_opy_ (u"࠭ࡌࡰࡩࡆࡶࡪࡧࡴࡦࡦࠪᇅ"): bstack1l11ll_opy_ (u"ࠧࡍࡱࡪࡣ࡚ࡶ࡬ࡰࡣࡧࠫᇆ"),
            bstack1l11ll_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡕࡷࡥࡷࡺࡥࡥࠩᇇ"): bstack1l11ll_opy_ (u"ࠩࡋࡳࡴࡱ࡟ࡔࡶࡤࡶࡹࡥࡕࡱ࡮ࡲࡥࡩ࠭ᇈ"),
            bstack1l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬᇉ"): bstack1l11ll_opy_ (u"ࠫࡍࡵ࡯࡬ࡡࡈࡲࡩࡥࡕࡱ࡮ࡲࡥࡩ࠭ᇊ"),
            bstack1l11ll_opy_ (u"ࠬࡉࡂࡕࡕࡨࡷࡸ࡯࡯࡯ࡅࡵࡩࡦࡺࡥࡥࠩᇋ"): bstack1l11ll_opy_ (u"࠭ࡃࡃࡖࡢ࡙ࡵࡲ࡯ࡢࡦࠪᇌ")
        }.get(bstack111l11ll_opy_)
        if bstack11lll11ll1_opy_ == bstack1l11ll_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡣࡣࡷࡧ࡭࠭ᇍ"):
            cls.bstack11ll11l1l1_opy_()
            cls.bstack11ll1ll111_opy_.add(bstack11ll11l_opy_)
        elif bstack11lll11ll1_opy_ == bstack1l11ll_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࡸ࠭ᇎ"):
            cls.bstack11ll11l11l_opy_([bstack11ll11l_opy_], bstack11lll11ll1_opy_)
    @classmethod
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def bstack11ll11l11l_opy_(cls, bstack11ll11l_opy_, bstack11lll11ll1_opy_=bstack1l11ll_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡥࡹࡩࡨࠨᇏ")):
        config = {
            bstack1l11ll_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫᇐ"): cls.default_headers()
        }
        response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"ࠫࡕࡕࡓࡕࠩᇑ"), cls.request_url(bstack11lll11ll1_opy_), bstack11ll11l_opy_, config)
        bstack11ll1l1ll1_opy_ = response.json()
    @classmethod
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def bstack1l1l1l1_opy_(cls, bstack1lllll1_opy_):
        bstack11lll11111_opy_ = []
        for log in bstack1lllll1_opy_:
            bstack11ll1l1l1l_opy_ = {
                bstack1l11ll_opy_ (u"ࠬࡱࡩ࡯ࡦࠪᇒ"): bstack1l11ll_opy_ (u"࠭ࡔࡆࡕࡗࡣࡑࡕࡇࠨᇓ"),
                bstack1l11ll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ᇔ"): log[bstack1l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧᇕ")],
                bstack1l11ll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬᇖ"): log[bstack1l11ll_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ᇗ")],
                bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡡࡵࡩࡸࡶ࡯࡯ࡵࡨࠫᇘ"): {},
                bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᇙ"): log[bstack1l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᇚ")],
            }
            if bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᇛ") in log:
                bstack11ll1l1l1l_opy_[bstack1l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᇜ")] = log[bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩᇝ")]
            elif bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᇞ") in log:
                bstack11ll1l1l1l_opy_[bstack1l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫᇟ")] = log[bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᇠ")]
            bstack11lll11111_opy_.append(bstack11ll1l1l1l_opy_)
        cls.bstack1lllllll_opy_({
            bstack1l11ll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪᇡ"): bstack1l11ll_opy_ (u"ࠧࡍࡱࡪࡇࡷ࡫ࡡࡵࡧࡧࠫᇢ"),
            bstack1l11ll_opy_ (u"ࠨ࡮ࡲ࡫ࡸ࠭ᇣ"): bstack11lll11111_opy_
        })
    @classmethod
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def bstack11ll11llll_opy_(cls, steps):
        bstack11lll11l1l_opy_ = []
        for step in steps:
            bstack11ll111lll_opy_ = {
                bstack1l11ll_opy_ (u"ࠩ࡮࡭ࡳࡪࠧᇤ"): bstack1l11ll_opy_ (u"ࠪࡘࡊ࡙ࡔࡠࡕࡗࡉࡕ࠭ᇥ"),
                bstack1l11ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪᇦ"): step[bstack1l11ll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫᇧ")],
                bstack1l11ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩᇨ"): step[bstack1l11ll_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪᇩ")],
                bstack1l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᇪ"): step[bstack1l11ll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᇫ")],
                bstack1l11ll_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬᇬ"): step[bstack1l11ll_opy_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ᇭ")]
            }
            if bstack1l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᇮ") in step:
                bstack11ll111lll_opy_[bstack1l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ᇯ")] = step[bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᇰ")]
            elif bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᇱ") in step:
                bstack11ll111lll_opy_[bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩᇲ")] = step[bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᇳ")]
            bstack11lll11l1l_opy_.append(bstack11ll111lll_opy_)
        cls.bstack1lllllll_opy_({
            bstack1l11ll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨᇴ"): bstack1l11ll_opy_ (u"ࠬࡒ࡯ࡨࡅࡵࡩࡦࡺࡥࡥࠩᇵ"),
            bstack1l11ll_opy_ (u"࠭࡬ࡰࡩࡶࠫᇶ"): bstack11lll11l1l_opy_
        })
    @classmethod
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def bstack1l1l111111_opy_(cls, screenshot):
        cls.bstack1lllllll_opy_({
            bstack1l11ll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫᇷ"): bstack1l11ll_opy_ (u"ࠨࡎࡲ࡫ࡈࡸࡥࡢࡶࡨࡨࠬᇸ"),
            bstack1l11ll_opy_ (u"ࠩ࡯ࡳ࡬ࡹࠧᇹ"): [{
                bstack1l11ll_opy_ (u"ࠪ࡯࡮ࡴࡤࠨᇺ"): bstack1l11ll_opy_ (u"࡙ࠫࡋࡓࡕࡡࡖࡇࡗࡋࡅࡏࡕࡋࡓ࡙࠭ᇻ"),
                bstack1l11ll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨᇼ"): datetime.datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"࡚࠭ࠨᇽ"),
                bstack1l11ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᇾ"): screenshot[bstack1l11ll_opy_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧᇿ")],
                bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩሀ"): screenshot[bstack1l11ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪሁ")]
            }]
        }, bstack11lll11ll1_opy_=bstack1l11ll_opy_ (u"ࠫࡦࡶࡩ࠰ࡸ࠴࠳ࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࡴࠩሂ"))
    @classmethod
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def bstack11ll11lll_opy_(cls, driver):
        current_test_uuid = cls.current_test_uuid()
        if not current_test_uuid:
            return
        cls.bstack1lllllll_opy_({
            bstack1l11ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩሃ"): bstack1l11ll_opy_ (u"࠭ࡃࡃࡖࡖࡩࡸࡹࡩࡰࡰࡆࡶࡪࡧࡴࡦࡦࠪሄ"),
            bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࠩህ"): {
                bstack1l11ll_opy_ (u"ࠣࡷࡸ࡭ࡩࠨሆ"): cls.current_test_uuid(),
                bstack1l11ll_opy_ (u"ࠤ࡬ࡲࡹ࡫ࡧࡳࡣࡷ࡭ࡴࡴࡳࠣሇ"): cls.bstack1l1111l_opy_(driver)
            }
        })
    @classmethod
    def on(cls):
        if os.environ.get(bstack1l11ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡋ࡙ࡗࠫለ"), None) is None or os.environ[bstack1l11ll_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡌ࡚ࡘࠬሉ")] == bstack1l11ll_opy_ (u"ࠧࡴࡵ࡭࡮ࠥሊ"):
            return False
        return True
    @classmethod
    def bstack1lll1ll11l_opy_(cls, framework=bstack1l11ll_opy_ (u"ࠨࠢላ")):
        bstack11ll11l111_opy_ = framework in bstack11llll1l11_opy_
        return is_true(cls.bs_config.get(bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡔࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫሌ"), bstack11ll11l111_opy_))
    @classmethod
    def bstack11ll1lll1l_opy_(cls, framework):
        return framework in bstack11llll1l11_opy_
    @staticmethod
    def request_url(url):
        return bstack1l11ll_opy_ (u"ࠨࡽࢀ࠳ࢀࢃࠧል").format(bstack11ll1lllll_opy_, url)
    @staticmethod
    def default_headers():
        headers = {
            bstack1l11ll_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨሎ"): bstack1l11ll_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ሏ"),
            bstack1l11ll_opy_ (u"ࠫ࡝࠳ࡂࡔࡖࡄࡇࡐ࠳ࡔࡆࡕࡗࡓࡕ࡙ࠧሐ"): bstack1l11ll_opy_ (u"ࠬࡺࡲࡶࡧࠪሑ")
        }
        if os.environ.get(bstack1l11ll_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡎ࡜࡚ࠧሒ"), None):
            headers[bstack1l11ll_opy_ (u"ࠧࡂࡷࡷ࡬ࡴࡸࡩࡻࡣࡷ࡭ࡴࡴࠧሓ")] = bstack1l11ll_opy_ (u"ࠨࡄࡨࡥࡷ࡫ࡲࠡࡽࢀࠫሔ").format(os.environ[bstack1l11ll_opy_ (u"ࠤࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠥሕ")])
        return headers
    @staticmethod
    def current_test_uuid():
        return getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡࡸࡹ࡮ࡪࠧሖ"), None)
    @staticmethod
    def current_hook_uuid():
        return getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤ࡮࡯ࡰ࡭ࡢࡹࡺ࡯ࡤࠨሗ"), None)
    @staticmethod
    def bstack1lll111_opy_():
        if getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩመ"), None):
            return {
                bstack1l11ll_opy_ (u"࠭ࡴࡺࡲࡨࠫሙ"): bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࠬሚ"),
                bstack1l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨማ"): getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭ሜ"), None)
            }
        if getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧም"), None):
            return {
                bstack1l11ll_opy_ (u"ࠫࡹࡿࡰࡦࠩሞ"): bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࠪሟ"),
                bstack1l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ሠ"): getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡪࡲࡳࡰࡥࡵࡶ࡫ࡧࠫሡ"), None)
            }
        return None
    @staticmethod
    def bstack1l1111l_opy_(driver):
        return {
            bstack11ll1lll11_opy_(): bstack11lll11l11_opy_(driver)
        }
    @staticmethod
    def bstack11lll111l1_opy_(exception_info, report):
        return [{bstack1l11ll_opy_ (u"ࠨࡤࡤࡧࡰࡺࡲࡢࡥࡨࠫሢ"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack1l111lll1l_opy_(typename):
        if bstack1l11ll_opy_ (u"ࠤࡄࡷࡸ࡫ࡲࡵ࡫ࡲࡲࠧሣ") in typename:
            return bstack1l11ll_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࡋࡲࡳࡱࡵࠦሤ")
        return bstack1l11ll_opy_ (u"࡚ࠦࡴࡨࡢࡰࡧࡰࡪࡪࡅࡳࡴࡲࡶࠧሥ")
    @staticmethod
    def bstack11lll111ll_opy_(func):
        def wrap(*args, **kwargs):
            if bstack111lll1_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def bstack1l1l111_opy_(test, hook_name=None):
        bstack11ll1ll11l_opy_ = test.parent
        if hook_name in [bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡨࡲࡡࡴࡵࠪሦ"), bstack1l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡥ࡯ࡥࡸࡹࠧሧ"), bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥ࡭ࡰࡦࡸࡰࡪ࠭ረ"), bstack1l11ll_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡱࡴࡪࡵ࡭ࡧࠪሩ")]:
            bstack11ll1ll11l_opy_ = test
        scope = []
        while bstack11ll1ll11l_opy_ is not None:
            scope.append(bstack11ll1ll11l_opy_.name)
            bstack11ll1ll11l_opy_ = bstack11ll1ll11l_opy_.parent
        scope.reverse()
        return scope[2:]
    @staticmethod
    def bstack11ll11l1ll_opy_(hook_type):
        if hook_type == bstack1l11ll_opy_ (u"ࠤࡅࡉࡋࡕࡒࡆࡡࡈࡅࡈࡎࠢሪ"):
            return bstack1l11ll_opy_ (u"ࠥࡗࡪࡺࡵࡱࠢ࡫ࡳࡴࡱࠢራ")
        elif hook_type == bstack1l11ll_opy_ (u"ࠦࡆࡌࡔࡆࡔࡢࡉࡆࡉࡈࠣሬ"):
            return bstack1l11ll_opy_ (u"࡚ࠧࡥࡢࡴࡧࡳࡼࡴࠠࡩࡱࡲ࡯ࠧር")
    @staticmethod
    def bstack11ll1l1l11_opy_(bstack1ll11111_opy_):
        try:
            if not bstack111lll1_opy_.on():
                return bstack1ll11111_opy_
            if os.environ.get(bstack1l11ll_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡘࡅࡓࡗࡑࠦሮ"), None) == bstack1l11ll_opy_ (u"ࠢࡵࡴࡸࡩࠧሯ"):
                tests = os.environ.get(bstack1l11ll_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡓࡇࡕ࡙ࡓࡥࡔࡆࡕࡗࡗࠧሰ"), None)
                if tests is None or tests == bstack1l11ll_opy_ (u"ࠤࡱࡹࡱࡲࠢሱ"):
                    return bstack1ll11111_opy_
                bstack1ll11111_opy_ = tests.split(bstack1l11ll_opy_ (u"ࠪ࠰ࠬሲ"))
                return bstack1ll11111_opy_
        except Exception as exc:
            print(bstack1l11ll_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡶࡪࡸࡵ࡯ࠢ࡫ࡥࡳࡪ࡬ࡦࡴ࠽ࠤࠧሳ"), str(exc))
        return bstack1ll11111_opy_
    @classmethod
    def bstack111l1ll_opy_(cls, event: str, bstack11ll11l_opy_: bstack1ll1lll_opy_):
        bstack1111l1l_opy_ = {
            bstack1l11ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩሴ"): event,
            bstack11ll11l_opy_.bstack1ll11ll_opy_(): bstack11ll11l_opy_.bstack1l111l1_opy_(event)
        }
        bstack111lll1_opy_.bstack1lllllll_opy_(bstack1111l1l_opy_)
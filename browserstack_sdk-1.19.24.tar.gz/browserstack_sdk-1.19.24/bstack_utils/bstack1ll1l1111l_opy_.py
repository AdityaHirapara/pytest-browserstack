# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import sys
import logging
import tarfile
import io
import os
import requests
import re
from requests_toolbelt.multipart.encoder import MultipartEncoder
from bstack_utils.constants import bstack11lll1ll1l_opy_
import tempfile
import json
bstack111ll11l11_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡪࡥࡣࡷࡪ࠲ࡱࡵࡧࠨᑐ"))
def get_logger(name=__name__, level=None):
  logger = logging.getLogger(name)
  if level:
    logging.basicConfig(
      level=level,
      format=bstack1l11ll_opy_ (u"ࠧ࡝ࡰࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࡜ࠧࠫࡲࡦࡳࡥࠪࡵࡠ࡟ࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࡡࠥ࠳ࠠࠦࠪࡰࡩࡸࡹࡡࡨࡧࠬࡷࠬᑑ"),
      datefmt=bstack1l11ll_opy_ (u"ࠨࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪᑒ"),
      stream=sys.stdout
    )
  return logger
def bstack111ll111ll_opy_():
  global bstack111ll11l11_opy_
  if os.path.exists(bstack111ll11l11_opy_):
    os.remove(bstack111ll11l11_opy_)
def bstack1ll11l1ll1_opy_():
  for handler in logging.getLogger().handlers:
    logging.getLogger().removeHandler(handler)
def bstack1ll1ll111l_opy_(config, log_level):
  bstack111ll111l1_opy_ = log_level
  if bstack1l11ll_opy_ (u"ࠩ࡯ࡳ࡬ࡒࡥࡷࡧ࡯ࠫᑓ") in config:
    bstack111ll111l1_opy_ = bstack11lll1ll1l_opy_[config[bstack1l11ll_opy_ (u"ࠪࡰࡴ࡭ࡌࡦࡸࡨࡰࠬᑔ")]]
  if config.get(bstack1l11ll_opy_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡆࡻࡴࡰࡅࡤࡴࡹࡻࡲࡦࡎࡲ࡫ࡸ࠭ᑕ"), False):
    logging.getLogger().setLevel(bstack111ll111l1_opy_)
    return bstack111ll111l1_opy_
  global bstack111ll11l11_opy_
  bstack1ll11l1ll1_opy_()
  bstack111l1lll11_opy_ = logging.Formatter(
    fmt=bstack1l11ll_opy_ (u"ࠬࡢ࡮ࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥࡡࠥࠩࡰࡤࡱࡪ࠯ࡳ࡞࡝ࠨࠬࡱ࡫ࡶࡦ࡮ࡱࡥࡲ࡫ࠩࡴ࡟ࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪᑖ"),
    datefmt=bstack1l11ll_opy_ (u"࠭ࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨᑗ")
  )
  bstack111l1ll1ll_opy_ = logging.StreamHandler(sys.stdout)
  file_handler = logging.FileHandler(bstack111ll11l11_opy_)
  file_handler.setFormatter(bstack111l1lll11_opy_)
  bstack111l1ll1ll_opy_.setFormatter(bstack111l1lll11_opy_)
  file_handler.setLevel(logging.DEBUG)
  bstack111l1ll1ll_opy_.setLevel(log_level)
  file_handler.addFilter(lambda r: r.name != bstack1l11ll_opy_ (u"ࠧࡴࡧ࡯ࡩࡳ࡯ࡵ࡮࠰ࡺࡩࡧࡪࡲࡪࡸࡨࡶ࠳ࡸࡥ࡮ࡱࡷࡩ࠳ࡸࡥ࡮ࡱࡷࡩࡤࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠩᑘ"))
  logging.getLogger().setLevel(logging.DEBUG)
  bstack111l1ll1ll_opy_.setLevel(bstack111ll111l1_opy_)
  logging.getLogger().addHandler(bstack111l1ll1ll_opy_)
  logging.getLogger().addHandler(file_handler)
  return bstack111ll111l1_opy_
def bstack111l1ll1l1_opy_(config):
  try:
    bstack111ll11ll1_opy_ = set([
      bstack1l11ll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪᑙ"), bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬᑚ"), bstack1l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭ᑛ"), bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨᑜ"), bstack1l11ll_opy_ (u"ࠬࡩࡵࡴࡶࡲࡱ࡛ࡧࡲࡪࡣࡥࡰࡪࡹࠧᑝ"),
      bstack1l11ll_opy_ (u"࠭ࡰࡳࡱࡻࡽ࡚ࡹࡥࡳࠩᑞ"), bstack1l11ll_opy_ (u"ࠧࡱࡴࡲࡼࡾࡖࡡࡴࡵࠪᑟ"), bstack1l11ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡐࡳࡱࡻࡽ࡚ࡹࡥࡳࠩᑠ"), bstack1l11ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡑࡴࡲࡼࡾࡖࡡࡴࡵࠪᑡ")
    ])
    bstack111ll1111l_opy_ = bstack1l11ll_opy_ (u"ࠪࠫᑢ")
    with open(bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡽࡲࡲࠧᑣ")) as bstack111ll11lll_opy_:
      bstack111ll11l1l_opy_ = bstack111ll11lll_opy_.read()
      bstack111ll1111l_opy_ = re.sub(bstack1l11ll_opy_ (u"ࡷ࠭࡞ࠩ࡞ࡶ࠯࠮ࡅࠣ࠯ࠬࠧࡠࡳ࠭ᑤ"), bstack1l11ll_opy_ (u"࠭ࠧᑥ"), bstack111ll11l1l_opy_, flags=re.M)
      bstack111ll1111l_opy_ = re.sub(
        bstack1l11ll_opy_ (u"ࡲࠨࡠࠫࡠࡸ࠱ࠩࡀࠪࠪᑦ") + bstack1l11ll_opy_ (u"ࠨࡾࠪᑧ").join(bstack111ll11ll1_opy_) + bstack1l11ll_opy_ (u"ࠩࠬ࠲࠯ࠪࠧᑨ"),
        bstack1l11ll_opy_ (u"ࡵࠫࡡ࠸࠺ࠡ࡝ࡕࡉࡉࡇࡃࡕࡇࡇࡡࠬᑩ"),
        bstack111ll1111l_opy_, flags=re.M | re.I
      )
    def bstack111l1lll1l_opy_(dic):
      bstack111l1lllll_opy_ = {}
      for key, value in dic.items():
        if key in bstack111ll11ll1_opy_:
          bstack111l1lllll_opy_[key] = bstack1l11ll_opy_ (u"ࠫࡠࡘࡅࡅࡃࡆࡘࡊࡊ࡝ࠨᑪ")
        else:
          if isinstance(value, dict):
            bstack111l1lllll_opy_[key] = bstack111l1lll1l_opy_(value)
          else:
            bstack111l1lllll_opy_[key] = value
      return bstack111l1lllll_opy_
    bstack111l1lllll_opy_ = bstack111l1lll1l_opy_(config)
    return {
      bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡾࡳ࡬ࠨᑫ"): bstack111ll1111l_opy_,
      bstack1l11ll_opy_ (u"࠭ࡦࡪࡰࡤࡰࡨࡵ࡮ࡧ࡫ࡪ࠲࡯ࡹ࡯࡯ࠩᑬ"): json.dumps(bstack111l1lllll_opy_)
    }
  except Exception as e:
    return {}
def bstack1l1l1l1_opy_(config):
  global bstack111ll11l11_opy_
  try:
    if config.get(bstack1l11ll_opy_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡂࡷࡷࡳࡈࡧࡰࡵࡷࡵࡩࡑࡵࡧࡴࠩᑭ"), False):
      return
    uuid = os.getenv(bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡗࡘࡍࡉ࠭ᑮ"))
    if not uuid or uuid == bstack1l11ll_opy_ (u"ࠩࡱࡹࡱࡲࠧᑯ"):
      return
    bstack111ll11111_opy_ = [bstack1l11ll_opy_ (u"ࠪࡶࡪࡷࡵࡪࡴࡨࡱࡪࡴࡴࡴ࠰ࡷࡼࡹ࠭ᑰ"), bstack1l11ll_opy_ (u"ࠫࡕ࡯ࡰࡧ࡫࡯ࡩࠬᑱ"), bstack1l11ll_opy_ (u"ࠬࡶࡹࡱࡴࡲ࡮ࡪࡩࡴ࠯ࡶࡲࡱࡱ࠭ᑲ"), bstack111ll11l11_opy_]
    bstack1ll11l1ll1_opy_()
    logging.shutdown()
    output_file = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࠳࡬ࡰࡩࡶ࠱ࠬᑳ") + uuid + bstack1l11ll_opy_ (u"ࠧ࠯ࡶࡤࡶ࠳࡭ࡺࠨᑴ"))
    with tarfile.open(output_file, bstack1l11ll_opy_ (u"ࠣࡹ࠽࡫ࡿࠨᑵ")) as archive:
      for file in filter(lambda f: os.path.exists(f), bstack111ll11111_opy_):
        try:
          archive.add(file,  arcname=os.path.basename(file))
        except:
          pass
      for name, data in bstack111l1ll1l1_opy_(config).items():
        tarinfo = tarfile.TarInfo(name)
        bstack111l1llll1_opy_ = data.encode()
        tarinfo.size = len(bstack111l1llll1_opy_)
        archive.addfile(tarinfo, io.BytesIO(bstack111l1llll1_opy_))
    bstack11lll111l_opy_ = MultipartEncoder(
      fields= {
        bstack1l11ll_opy_ (u"ࠩࡧࡥࡹࡧࠧᑶ"): (os.path.basename(output_file), open(os.path.abspath(output_file), bstack1l11ll_opy_ (u"ࠪࡶࡧ࠭ᑷ")), bstack1l11ll_opy_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱࡬ࢀࡩࡱࠩᑸ")),
        bstack1l11ll_opy_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡇࡻࡩ࡭ࡦࡘࡹ࡮ࡪࠧᑹ"): uuid
      }
    )
    response = requests.post(
      bstack1l11ll_opy_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࡶࡲ࡯ࡳࡦࡪ࠭ࡰࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡧࡱ࡯ࡥ࡯ࡶ࠰ࡰࡴ࡭ࡳ࠰ࡷࡳࡰࡴࡧࡤࠣᑺ"),
      data=bstack11lll111l_opy_,
      headers={bstack1l11ll_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᑻ"): bstack11lll111l_opy_.content_type},
      auth=(config[bstack1l11ll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪᑼ")], config[bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬᑽ")])
    )
    os.remove(output_file)
    if response.status_code != 200:
      get_logger().debug(bstack1l11ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡸࡴࡱࡵࡡࡥࠢ࡯ࡳ࡬ࡹ࠺ࠡࠩᑾ") + response.status_code)
  except Exception as e:
    get_logger().debug(bstack1l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡷࡪࡴࡤࡪࡰࡪࠤࡱࡵࡧࡴ࠼ࠪᑿ") + str(e))
  finally:
    try:
      bstack111ll111ll_opy_()
    except:
      pass
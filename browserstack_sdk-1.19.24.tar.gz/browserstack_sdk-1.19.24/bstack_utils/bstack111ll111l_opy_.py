# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import re
from bstack_utils.bstack1ll1llll11_opy_ import bstack1l111ll111_opy_
def bstack11ll11111l_opy_(fixture_name):
    if fixture_name.startswith(bstack1l11ll_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡳࡦࡶࡸࡴࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨስ")):
        return bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠳ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨሶ")
    elif fixture_name.startswith(bstack1l11ll_opy_ (u"ࠨࡡࡻࡹࡳ࡯ࡴࡠࡵࡨࡸࡺࡶ࡟࡮ࡱࡧࡹࡱ࡫࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨሷ")):
        return bstack1l11ll_opy_ (u"ࠩࡶࡩࡹࡻࡰ࠮࡯ࡲࡨࡺࡲࡥࠨሸ")
    elif fixture_name.startswith(bstack1l11ll_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨሹ")):
        return bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳ࠳ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨሺ")
    elif fixture_name.startswith(bstack1l11ll_opy_ (u"ࠬࡥࡸࡶࡰ࡬ࡸࡤࡺࡥࡢࡴࡧࡳࡼࡴ࡟ࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡩ࡭ࡽࡺࡵࡳࡧࠪሻ")):
        return bstack1l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮࠮࡯ࡲࡨࡺࡲࡥࠨሼ")
def bstack11l1llll11_opy_(fixture_name):
    return bool(re.match(bstack1l11ll_opy_ (u"ࠧ࡟ࡡࡻࡹࡳ࡯ࡴࡠࠪࡶࡩࡹࡻࡰࡽࡶࡨࡥࡷࡪ࡯ࡸࡰࠬࡣ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࡼ࡮ࡱࡧࡹࡱ࡫ࠩࡠࡨ࡬ࡼࡹࡻࡲࡦࡡ࠱࠮ࠬሽ"), fixture_name))
def bstack11ll111l11_opy_(fixture_name):
    return bool(re.match(bstack1l11ll_opy_ (u"ࠨࡠࡢࡼࡺࡴࡩࡵࡡࠫࡷࡪࡺࡵࡱࡾࡷࡩࡦࡸࡤࡰࡹࡱ࠭ࡤࡳ࡯ࡥࡷ࡯ࡩࡤ࡬ࡩࡹࡶࡸࡶࡪࡥ࠮ࠫࠩሾ"), fixture_name))
def bstack11ll111l1l_opy_(fixture_name):
    return bool(re.match(bstack1l11ll_opy_ (u"ࠩࡡࡣࡽࡻ࡮ࡪࡶࡢࠬࡸ࡫ࡴࡶࡲࡿࡸࡪࡧࡲࡥࡱࡺࡲ࠮ࡥࡣ࡭ࡣࡶࡷࡤ࡬ࡩࡹࡶࡸࡶࡪࡥ࠮ࠫࠩሿ"), fixture_name))
def bstack11l1lll1ll_opy_(fixture_name):
    if fixture_name.startswith(bstack1l11ll_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡷࡪࡺࡵࡱࡡࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬቀ")):
        return bstack1l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲ࠰ࡪࡺࡴࡣࡵ࡫ࡲࡲࠬቁ"), bstack1l11ll_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡋࡁࡄࡊࠪቂ")
    elif fixture_name.startswith(bstack1l11ll_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡳࡦࡶࡸࡴࡤࡳ࡯ࡥࡷ࡯ࡩࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ቃ")):
        return bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠳࡭ࡰࡦࡸࡰࡪ࠭ቄ"), bstack1l11ll_opy_ (u"ࠨࡄࡈࡊࡔࡘࡅࡠࡃࡏࡐࠬቅ")
    elif fixture_name.startswith(bstack1l11ll_opy_ (u"ࠩࡢࡼࡺࡴࡩࡵࡡࡷࡩࡦࡸࡤࡰࡹࡱࡣ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡥࡦࡪࡺࡷࡹࡷ࡫ࠧቆ")):
        return bstack1l11ll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲ࠲࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧቇ"), bstack1l11ll_opy_ (u"ࠫࡆࡌࡔࡆࡔࡢࡉࡆࡉࡈࠨቈ")
    elif fixture_name.startswith(bstack1l11ll_opy_ (u"ࠬࡥࡸࡶࡰ࡬ࡸࡤࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡱࡧࡹࡱ࡫࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨ቉")):
        return bstack1l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮࠮࡯ࡲࡨࡺࡲࡥࠨቊ"), bstack1l11ll_opy_ (u"ࠧࡂࡈࡗࡉࡗࡥࡁࡍࡎࠪቋ")
    return None, None
def bstack11l1llllll_opy_(hook_name):
    if hook_name in [bstack1l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧቌ"), bstack1l11ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࠫቍ")]:
        return hook_name.capitalize()
    return hook_name
def bstack11ll111ll1_opy_(hook_name):
    if hook_name in [bstack1l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࡡࡩࡹࡳࡩࡴࡪࡱࡱࠫ቎"), bstack1l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡱࡪࡺࡨࡰࡦࠪ቏")]:
        return bstack1l11ll_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡋࡁࡄࡊࠪቐ")
    elif hook_name in [bstack1l11ll_opy_ (u"࠭ࡳࡦࡶࡸࡴࡤࡳ࡯ࡥࡷ࡯ࡩࠬቑ"), bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥࡣ࡭ࡣࡶࡷࠬቒ")]:
        return bstack1l11ll_opy_ (u"ࠨࡄࡈࡊࡔࡘࡅࡠࡃࡏࡐࠬቓ")
    elif hook_name in [bstack1l11ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࡣ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭ቔ"), bstack1l11ll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤࡳࡥࡵࡪࡲࡨࠬቕ")]:
        return bstack1l11ll_opy_ (u"ࠫࡆࡌࡔࡆࡔࡢࡉࡆࡉࡈࠨቖ")
    elif hook_name in [bstack1l11ll_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡱࡧࡹࡱ࡫ࠧ቗"), bstack1l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡥ࡯ࡥࡸࡹࠧቘ")]:
        return bstack1l11ll_opy_ (u"ࠧࡂࡈࡗࡉࡗࡥࡁࡍࡎࠪ቙")
    return hook_name
def bstack11l1llll1l_opy_(node, scenario):
    if hasattr(node, bstack1l11ll_opy_ (u"ࠨࡥࡤࡰࡱࡹࡰࡦࡥࠪቚ")):
        parts = node.nodeid.rsplit(bstack1l11ll_opy_ (u"ࠤ࡞ࠦቛ"))
        params = parts[-1]
        return bstack1l11ll_opy_ (u"ࠥࡿࢂ࡛ࠦࡼࡿࠥቜ").format(scenario.name, params)
    return scenario.name
def bstack11l1lllll1_opy_(node):
    try:
        examples = []
        if hasattr(node, bstack1l11ll_opy_ (u"ࠫࡨࡧ࡬࡭ࡵࡳࡩࡨ࠭ቝ")):
            examples = list(node.callspec.params[bstack1l11ll_opy_ (u"ࠬࡥࡰࡺࡶࡨࡷࡹࡥࡢࡥࡦࡢࡩࡽࡧ࡭ࡱ࡮ࡨࠫ቞")].values())
        return examples
    except:
        return []
def bstack11ll111111_opy_(feature, scenario):
    return list(feature.tags) + list(scenario.tags)
def bstack11ll1111ll_opy_(report):
    try:
        status = bstack1l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭቟")
        if report.passed or (report.failed and hasattr(report, bstack1l11ll_opy_ (u"ࠢࡸࡣࡶࡼ࡫ࡧࡩ࡭ࠤበ"))):
            status = bstack1l11ll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨቡ")
        elif report.skipped:
            status = bstack1l11ll_opy_ (u"ࠩࡶ࡯࡮ࡶࡰࡦࡦࠪቢ")
        bstack1l111ll111_opy_(status)
    except:
        pass
def bstack1ll1lll1l1_opy_(status):
    try:
        bstack11ll1111l1_opy_ = bstack1l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪባ")
        if status == bstack1l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫቤ"):
            bstack11ll1111l1_opy_ = bstack1l11ll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬብ")
        elif status == bstack1l11ll_opy_ (u"࠭ࡳ࡬࡫ࡳࡴࡪࡪࠧቦ"):
            bstack11ll1111l1_opy_ = bstack1l11ll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨቧ")
        bstack1l111ll111_opy_(bstack11ll1111l1_opy_)
    except:
        pass
def bstack11l1lll1l1_opy_(item=None, report=None, summary=None, extra=None):
    return
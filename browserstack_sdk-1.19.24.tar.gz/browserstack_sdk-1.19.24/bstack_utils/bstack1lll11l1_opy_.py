# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
import json
import requests
import logging
from urllib.parse import urlparse
from datetime import datetime
from bstack_utils.constants import bstack11llll11l1_opy_ as bstack111111111l_opy_
from bstack_utils.bstack1lll1ll1l1_opy_ import bstack1lll1ll1l1_opy_
from bstack_utils.helper import current_time, bstack11l1l1111_opy_, bstack11ll1ll1l1_opy_, bstack11lll11lll_opy_, bstack1lll11111_opy_, get_host_info, bstack11ll1l11l1_opy_, bstack1l111ll11_opy_, bstack1lll1l1_opy_
from browserstack_sdk._version import __version__
logger = logging.getLogger(__name__)
@bstack1lll1l1_opy_(bstack11ll1l1_opy_=False)
def _1lllllllll1_opy_(driver, bstack1llll11l_opy_):
  response = {}
  try:
    caps = driver.capabilities
    response = {
        bstack1l11ll_opy_ (u"࠭࡯ࡴࡡࡱࡥࡲ࡫ࠧᔷ"): caps.get(bstack1l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪ࠭ᔸ"), None),
        bstack1l11ll_opy_ (u"ࠨࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬᔹ"): bstack1llll11l_opy_.get(bstack1l11ll_opy_ (u"ࠩࡲࡷ࡛࡫ࡲࡴ࡫ࡲࡲࠬᔺ"), None),
        bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡣࡳࡧ࡭ࡦࠩᔻ"): caps.get(bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩᔼ"), None),
        bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧᔽ"): caps.get(bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᔾ"), None)
    }
  except Exception as error:
    logger.debug(bstack1l11ll_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡦࡦࡶࡦ࡬࡮ࡴࡧࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠣࡨࡪࡺࡡࡪ࡮ࡶࠤࡼ࡯ࡴࡩࠢࡨࡶࡷࡵࡲࠡ࠼ࠣࠫᔿ") + str(error))
  return response
def bstack11ll1111_opy_(config):
  return config.get(bstack1l11ll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᕀ"), False) or any([p.get(bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᕁ"), False) == True for p in config.get(bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ᕂ"), [])])
def bstack1l1ll11ll_opy_(config, bstack111l1llll_opy_):
  try:
    if not bstack11l1l1111_opy_(config):
      return False
    bstack1llllllll1l_opy_ = config.get(bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫᕃ"), False)
    bstack1llllllllll_opy_ = config[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨᕄ")][bstack111l1llll_opy_].get(bstack1l11ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭ᕅ"), None)
    if bstack1llllllllll_opy_ != None:
      bstack1llllllll1l_opy_ = bstack1llllllllll_opy_
    bstack1lllllll1l1_opy_ = os.getenv(bstack1l11ll_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬᕆ")) is not None and len(os.getenv(bstack1l11ll_opy_ (u"ࠨࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙࠭ᕇ"))) > 0 and os.getenv(bstack1l11ll_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡎ࡜࡚ࠧᕈ")) != bstack1l11ll_opy_ (u"ࠪࡲࡺࡲ࡬ࠨᕉ")
    return bstack1llllllll1l_opy_ and bstack1lllllll1l1_opy_
  except Exception as error:
    logger.debug(bstack1l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡺࡪࡸࡩࡧࡻ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡷࡪࡹࡳࡪࡱࡱࠤࡼ࡯ࡴࡩࠢࡨࡶࡷࡵࡲࠡ࠼ࠣࠫᕊ") + str(error))
  return False
def bstack1l1l1ll11_opy_(bstack1111111111_opy_, test_tags):
  bstack1111111111_opy_ = os.getenv(bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ᕋ"))
  if bstack1111111111_opy_ is None:
    return True
  bstack1111111111_opy_ = json.loads(bstack1111111111_opy_)
  try:
    include_tags = bstack1111111111_opy_[bstack1l11ll_opy_ (u"࠭ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫᕌ")] if bstack1l11ll_opy_ (u"ࠧࡪࡰࡦࡰࡺࡪࡥࡕࡣࡪࡷࡎࡴࡔࡦࡵࡷ࡭ࡳ࡭ࡓࡤࡱࡳࡩࠬᕍ") in bstack1111111111_opy_ and isinstance(bstack1111111111_opy_[bstack1l11ll_opy_ (u"ࠨ࡫ࡱࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭ᕎ")], list) else []
    exclude_tags = bstack1111111111_opy_[bstack1l11ll_opy_ (u"ࠩࡨࡼࡨࡲࡵࡥࡧࡗࡥ࡬ࡹࡉ࡯ࡖࡨࡷࡹ࡯࡮ࡨࡕࡦࡳࡵ࡫ࠧᕏ")] if bstack1l11ll_opy_ (u"ࠪࡩࡽࡩ࡬ࡶࡦࡨࡘࡦ࡭ࡳࡊࡰࡗࡩࡸࡺࡩ࡯ࡩࡖࡧࡴࡶࡥࠨᕐ") in bstack1111111111_opy_ and isinstance(bstack1111111111_opy_[bstack1l11ll_opy_ (u"ࠫࡪࡾࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩᕑ")], list) else []
    excluded = any(tag in exclude_tags for tag in test_tags)
    included = len(include_tags) == 0 or any(tag in include_tags for tag in test_tags)
    return not excluded and included
  except Exception as error:
    logger.debug(bstack1l11ll_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡺࡦࡲࡩࡥࡣࡷ࡭ࡳ࡭ࠠࡵࡧࡶࡸࠥࡩࡡࡴࡧࠣࡪࡴࡸࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡣࡧࡩࡳࡷ࡫ࠠࡴࡥࡤࡲࡳ࡯࡮ࡨ࠰ࠣࡉࡷࡸ࡯ࡳࠢ࠽ࠤࠧᕒ") + str(error))
  return False
def bstack111111l1l_opy_(config, frameworkName, bstack1lllllll1ll_opy_, bstack111111l11l_opy_):
  bstack11ll11ll11_opy_ = bstack11ll1ll1l1_opy_(config)
  bstack11ll1llll1_opy_ = bstack11lll11lll_opy_(config)
  if bstack11ll11ll11_opy_ is None or bstack11ll1llll1_opy_ is None:
    logger.error(bstack1l11ll_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡸࡪࡹࡴࠡࡴࡸࡲࠥ࡬࡯ࡳࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲ࠿ࠦࡍࡪࡵࡶ࡭ࡳ࡭ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡶࡲ࡯ࡪࡴࠧᕓ"))
    return [None, None]
  try:
    settings = json.loads(os.getenv(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨᕔ"), bstack1l11ll_opy_ (u"ࠨࡽࢀࠫᕕ")))
    data = {
        bstack1l11ll_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠧᕖ"): config[bstack1l11ll_opy_ (u"ࠪࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠨᕗ")],
        bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧᕘ"): config.get(bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨᕙ"), os.path.basename(os.getcwd())),
        bstack1l11ll_opy_ (u"࠭ࡳࡵࡣࡵࡸ࡙࡯࡭ࡦࠩᕚ"): current_time(),
        bstack1l11ll_opy_ (u"ࠧࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠬᕛ"): config.get(bstack1l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡄࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠫᕜ"), bstack1l11ll_opy_ (u"ࠩࠪᕝ")),
        bstack1l11ll_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪᕞ"): {
            bstack1l11ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࡎࡢ࡯ࡨࠫᕟ"): frameworkName,
            bstack1l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡗࡧࡵࡷ࡮ࡵ࡮ࠨᕠ"): bstack1lllllll1ll_opy_,
            bstack1l11ll_opy_ (u"࠭ࡳࡥ࡭࡙ࡩࡷࡹࡩࡰࡰࠪᕡ"): __version__,
            bstack1l11ll_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩᕢ"): bstack1l11ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨᕣ"),
            bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺࡆࡳࡣࡰࡩࡼࡵࡲ࡬ࠩᕤ"): bstack1l11ll_opy_ (u"ࠪࡷࡪࡲࡥ࡯࡫ࡸࡱࠬᕥ"),
            bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡈࡵࡥࡲ࡫ࡷࡰࡴ࡮࡚ࡪࡸࡳࡪࡱࡱࠫᕦ"): bstack111111l11l_opy_
        },
        bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧᕧ"): settings,
        bstack1l11ll_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࡃࡰࡰࡷࡶࡴࡲࠧᕨ"): bstack11ll1l11l1_opy_(),
        bstack1l11ll_opy_ (u"ࠧࡤ࡫ࡌࡲ࡫ࡵࠧᕩ"): bstack1lll11111_opy_(),
        bstack1l11ll_opy_ (u"ࠨࡪࡲࡷࡹࡏ࡮ࡧࡱࠪᕪ"): get_host_info(),
        bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠫᕫ"): bstack11l1l1111_opy_(config)
    }
    headers = {
        bstack1l11ll_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᕬ"): bstack1l11ll_opy_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧᕭ"),
    }
    config = {
        bstack1l11ll_opy_ (u"ࠬࡧࡵࡵࡪࠪᕮ"): (bstack11ll11ll11_opy_, bstack11ll1llll1_opy_),
        bstack1l11ll_opy_ (u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧᕯ"): headers
    }
    response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"ࠧࡑࡑࡖࡘࠬᕰ"), bstack111111111l_opy_ + bstack1l11ll_opy_ (u"ࠨ࠱ࡹ࠶࠴ࡺࡥࡴࡶࡢࡶࡺࡴࡳࠨᕱ"), data, config)
    bstack11ll1l1ll1_opy_ = response.json()
    if bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠩࡶࡹࡨࡩࡥࡴࡵࠪᕲ")]:
      parsed = json.loads(os.getenv(bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫᕳ"), bstack1l11ll_opy_ (u"ࠫࢀࢃࠧᕴ")))
      parsed[bstack1l11ll_opy_ (u"ࠬࡹࡣࡢࡰࡱࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᕵ")] = bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"࠭ࡤࡢࡶࡤࠫᕶ")][bstack1l11ll_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨᕷ")]
      os.environ[bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡤࡇࡃࡄࡇࡖࡗࡎࡈࡉࡍࡋࡗ࡝ࡤࡉࡏࡏࡈࡌࡋ࡚ࡘࡁࡕࡋࡒࡒࡤ࡟ࡍࡍࠩᕸ")] = json.dumps(parsed)
      bstack1lll1ll1l1_opy_.bstack11111l1111_opy_(bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠩࡧࡥࡹࡧࠧᕹ")][bstack1l11ll_opy_ (u"ࠪࡷࡨࡸࡩࡱࡶࡶࠫᕺ")])
      bstack1lll1ll1l1_opy_.bstack111111l1ll_opy_(bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠫࡩࡧࡴࡢࠩᕻ")][bstack1l11ll_opy_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡹࠧᕼ")])
      bstack1lll1ll1l1_opy_.store()
      return bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"࠭ࡤࡢࡶࡤࠫᕽ")][bstack1l11ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡔࡰ࡭ࡨࡲࠬᕾ")], bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠨࡦࡤࡸࡦ࠭ᕿ")][bstack1l11ll_opy_ (u"ࠩ࡬ࡨࠬᖀ")]
    else:
      logger.error(bstack1l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯࠼ࠣࠫᖁ") + bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᖂ")])
      if bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᖃ")] == bstack1l11ll_opy_ (u"࠭ࡉ࡯ࡸࡤࡰ࡮ࡪࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡱࡣࡶࡷࡪࡪ࠮ࠨᖄ"):
        for bstack1llllllll11_opy_ in bstack11ll1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠧࡦࡴࡵࡳࡷࡹࠧᖅ")]:
          logger.error(bstack1llllllll11_opy_[bstack1l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᖆ")])
      return None, None
  except Exception as error:
    logger.error(bstack1l11ll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡽࡨࡪ࡮ࡨࠤࡨࡸࡥࡢࡶ࡬ࡲ࡬ࠦࡴࡦࡵࡷࠤࡷࡻ࡮ࠡࡨࡲࡶࠥࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮࠻ࠢࠥᖇ") +  str(error))
    return None, None
def bstack1l111l111_opy_():
  if os.getenv(bstack1l11ll_opy_ (u"ࠪࡆࡘࡥࡁ࠲࠳࡜ࡣࡏ࡝ࡔࠨᖈ")) is None:
    return {
        bstack1l11ll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫᖉ"): bstack1l11ll_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫᖊ"),
        bstack1l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᖋ"): bstack1l11ll_opy_ (u"ࠧࡃࡷ࡬ࡰࡩࠦࡣࡳࡧࡤࡸ࡮ࡵ࡮ࠡࡪࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨ࠳࠭ᖌ")
    }
  data = {bstack1l11ll_opy_ (u"ࠨࡧࡱࡨ࡙࡯࡭ࡦࠩᖍ"): current_time()}
  headers = {
      bstack1l11ll_opy_ (u"ࠩࡄࡹࡹ࡮࡯ࡳ࡫ࡽࡥࡹ࡯࡯࡯ࠩᖎ"): bstack1l11ll_opy_ (u"ࠪࡆࡪࡧࡲࡦࡴࠣࠫᖏ") + os.getenv(bstack1l11ll_opy_ (u"ࠦࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠤᖐ")),
      bstack1l11ll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᖑ"): bstack1l11ll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩᖒ")
  }
  response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"ࠧࡑࡗࡗࠫᖓ"), bstack111111111l_opy_ + bstack1l11ll_opy_ (u"ࠨ࠱ࡷࡩࡸࡺ࡟ࡳࡷࡱࡷ࠴ࡹࡴࡰࡲࠪᖔ"), data, { bstack1l11ll_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪᖕ"): headers })
  try:
    if response.status_code == 200:
      logger.info(bstack1l11ll_opy_ (u"ࠥࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡔࡦࡵࡷࠤࡗࡻ࡮ࠡ࡯ࡤࡶࡰ࡫ࡤࠡࡣࡶࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠠࡢࡶࠣࠦᖖ") + datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"ࠫ࡟࠭ᖗ"))
      return {bstack1l11ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬᖘ"): bstack1l11ll_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧᖙ"), bstack1l11ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᖚ"): bstack1l11ll_opy_ (u"ࠨࠩᖛ")}
    else:
      response.raise_for_status()
  except requests.RequestException as error:
    logger.error(bstack1l11ll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡽࡨࡪ࡮ࡨࠤࡲࡧࡲ࡬࡫ࡱ࡫ࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡯࡯࡯ࠢࡲࡪࠥࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡖࡨࡷࡹࠦࡒࡶࡰ࠽ࠤࠧᖜ") + str(error))
    return {
        bstack1l11ll_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪᖝ"): bstack1l11ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪᖞ"),
        bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᖟ"): str(error)
    }
def bstack1l1l11l111_opy_(caps, options):
  try:
    bstack1111111lll_opy_ = caps.get(bstack1l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧᖠ"), {}).get(bstack1l11ll_opy_ (u"ࠧࡥࡧࡹ࡭ࡨ࡫ࡎࡢ࡯ࡨࠫᖡ"), caps.get(bstack1l11ll_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨᖢ"), bstack1l11ll_opy_ (u"ࠩࠪᖣ")))
    if bstack1111111lll_opy_:
      logger.warn(bstack1l11ll_opy_ (u"ࠥࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡸ࡫࡯ࡰࠥࡸࡵ࡯ࠢࡲࡲࡱࡿࠠࡰࡰࠣࡈࡪࡹ࡫ࡵࡱࡳࠤࡧࡸ࡯ࡸࡵࡨࡶࡸ࠴ࠢᖤ"))
      return False
    browser = caps.get(bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩᖥ"), bstack1l11ll_opy_ (u"ࠬ࠭ᖦ")).lower()
    if browser != bstack1l11ll_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪ࠭ᖧ"):
      logger.warn(bstack1l11ll_opy_ (u"ࠢࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡵࡹࡳࠦ࡯࡯࡮ࡼࠤࡴࡴࠠࡄࡪࡵࡳࡲ࡫ࠠࡣࡴࡲࡻࡸ࡫ࡲࡴ࠰ࠥᖨ"))
      return False
    browser_version = caps.get(bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩᖩ"), caps.get(bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡢࡺࡪࡸࡳࡪࡱࡱࠫᖪ")))
    if browser_version and browser_version != bstack1l11ll_opy_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪᖫ") and int(browser_version.split(bstack1l11ll_opy_ (u"ࠫ࠳࠭ᖬ"))[0]) <= 94:
      logger.warn(bstack1l11ll_opy_ (u"ࠧࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡺ࡭ࡱࡲࠠࡳࡷࡱࠤࡴࡴ࡬ࡺࠢࡲࡲࠥࡉࡨࡳࡱࡰࡩࠥࡨࡲࡰࡹࡶࡩࡷࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡨࡴࡨࡥࡹ࡫ࡲࠡࡶ࡫ࡥࡳࠦ࠹࠵࠰ࠥᖭ"))
      return False
    if not options is None:
      bstack1lllllll11l_opy_ = options.to_capabilities().get(bstack1l11ll_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫᖮ"), {})
      if bstack1l11ll_opy_ (u"ࠧ࠮࠯࡫ࡩࡦࡪ࡬ࡦࡵࡶࠫᖯ") in bstack1lllllll11l_opy_.get(bstack1l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ᖰ"), []):
        logger.warn(bstack1l11ll_opy_ (u"ࠤࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡷࡪ࡮࡯ࠤࡳࡵࡴࠡࡴࡸࡲࠥࡵ࡮ࠡ࡮ࡨ࡫ࡦࡩࡹࠡࡪࡨࡥࡩࡲࡥࡴࡵࠣࡱࡴࡪࡥ࠯ࠢࡖࡻ࡮ࡺࡣࡩࠢࡷࡳࠥࡴࡥࡸࠢ࡫ࡩࡦࡪ࡬ࡦࡵࡶࠤࡲࡵࡤࡦࠢࡲࡶࠥࡧࡶࡰ࡫ࡧࠤࡺࡹࡩ࡯ࡩࠣ࡬ࡪࡧࡤ࡭ࡧࡶࡷࠥࡳ࡯ࡥࡧ࠱ࠦᖱ"))
        return False
    return True
  except Exception as error:
    logger.debug(bstack1l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡹࡥࡱ࡯ࡤࡢࡶࡨࠤࡦ࠷࠱ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࠣ࠾ࠧᖲ") + str(error))
    return False
def set_capabilities(caps, config):
  try:
    bstack11111111l1_opy_ = config.get(bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫᖳ"), {})
    bstack11111111l1_opy_[bstack1l11ll_opy_ (u"ࠬࡧࡵࡵࡪࡗࡳࡰ࡫࡮ࠨᖴ")] = os.getenv(bstack1l11ll_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫᖵ"))
    bstack1111111l11_opy_ = json.loads(os.getenv(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨᖶ"), bstack1l11ll_opy_ (u"ࠨࡽࢀࠫᖷ"))).get(bstack1l11ll_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᖸ"))
    caps[bstack1l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪᖹ")] = True
    if bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬᖺ") in caps:
      caps[bstack1l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ᖻ")][bstack1l11ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᖼ")] = bstack11111111l1_opy_
      caps[bstack1l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨᖽ")][bstack1l11ll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨᖾ")][bstack1l11ll_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪᖿ")] = bstack1111111l11_opy_
    else:
      caps[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩᗀ")] = bstack11111111l1_opy_
      caps[bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪᗁ")][bstack1l11ll_opy_ (u"ࠬࡹࡣࡢࡰࡱࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᗂ")] = bstack1111111l11_opy_
  except Exception as error:
    logger.debug(bstack1l11ll_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡵࡨࡸࡹ࡯࡮ࡨࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡣࡢࡲࡤࡦ࡮ࡲࡩࡵ࡫ࡨࡷ࠳ࠦࡅࡳࡴࡲࡶ࠿ࠦࠢᗃ") +  str(error))
def bstack1lll1llll1_opy_(driver, bstack11111111ll_opy_):
  try:
    setattr(driver, bstack1l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱࡁ࠲࠳ࡼࡗ࡭ࡵࡵ࡭ࡦࡖࡧࡦࡴࠧᗄ"), True)
    session = driver.session_id
    if session:
      bstack1111111ll1_opy_ = True
      current_url = driver.current_url
      try:
        url = urlparse(current_url)
      except Exception as e:
        bstack1111111ll1_opy_ = False
      bstack1111111ll1_opy_ = url.scheme in [bstack1l11ll_opy_ (u"ࠣࡪࡷࡸࡵࠨᗅ"), bstack1l11ll_opy_ (u"ࠤ࡫ࡸࡹࡶࡳࠣᗆ")]
      if bstack1111111ll1_opy_:
        if bstack11111111ll_opy_:
          logger.info(bstack1l11ll_opy_ (u"ࠥࡗࡪࡺࡵࡱࠢࡩࡳࡷࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡴࡦࡵࡷ࡭ࡳ࡭ࠠࡩࡣࡶࠤࡸࡺࡡࡳࡶࡨࡨ࠳ࠦࡁࡶࡶࡲࡱࡦࡺࡥࠡࡶࡨࡷࡹࠦࡣࡢࡵࡨࠤࡪࡾࡥࡤࡷࡷ࡭ࡴࡴࠠࡸ࡫࡯ࡰࠥࡨࡥࡨ࡫ࡱࠤࡲࡵ࡭ࡦࡰࡷࡥࡷ࡯࡬ࡺ࠰ࠥᗇ"))
      return bstack11111111ll_opy_
  except Exception as e:
    logger.error(bstack1l11ll_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡷࡹࡧࡲࡵ࡫ࡱ࡫ࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡶࡧࡦࡴࠠࡧࡱࡵࠤࡹ࡮ࡩࡴࠢࡷࡩࡸࡺࠠࡤࡣࡶࡩ࠿ࠦࠢᗈ") + str(e))
    return False
def bstack1ll1l111_opy_(driver, class_name, name, module_name, path, bstack1llll11l_opy_):
  try:
    bstack1ll1l1l1_opy_ = [class_name] if not class_name is None else []
    bstack111111l111_opy_ = {
        bstack1l11ll_opy_ (u"ࠧࡹࡡࡷࡧࡕࡩࡸࡻ࡬ࡵࡵࠥᗉ"): True,
        bstack1l11ll_opy_ (u"ࠨࡴࡦࡵࡷࡈࡪࡺࡡࡪ࡮ࡶࠦᗊ"): {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᗋ"): name,
            bstack1l11ll_opy_ (u"ࠣࡶࡨࡷࡹࡘࡵ࡯ࡋࡧࠦᗌ"): os.environ.get(bstack1l11ll_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡘࡊ࡙ࡔࡠࡔࡘࡒࡤࡏࡄࠨᗍ")),
            bstack1l11ll_opy_ (u"ࠥࡪ࡮ࡲࡥࡑࡣࡷ࡬ࠧᗎ"): str(path),
            bstack1l11ll_opy_ (u"ࠦࡸࡩ࡯ࡱࡧࡏ࡭ࡸࡺࠢᗏ"): [module_name, *bstack1ll1l1l1_opy_, name],
        },
        bstack1l11ll_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢᗐ"): _1lllllllll1_opy_(driver, bstack1llll11l_opy_)
    }
    logger.debug(bstack1l11ll_opy_ (u"࠭ࡐࡦࡴࡩࡳࡷࡳࡩ࡯ࡩࠣࡷࡨࡧ࡮ࠡࡤࡨࡪࡴࡸࡥࠡࡵࡤࡺ࡮ࡴࡧࠡࡴࡨࡷࡺࡲࡴࡴࠩᗑ"))
    logger.debug(driver.execute_async_script(bstack1lll1ll1l1_opy_.perform_scan, {bstack1l11ll_opy_ (u"ࠢ࡮ࡧࡷ࡬ࡴࡪࠢᗒ"): name}))
    logger.debug(driver.execute_async_script(bstack1lll1ll1l1_opy_.bstack111111ll11_opy_, bstack111111l111_opy_))
    logger.info(bstack1l11ll_opy_ (u"ࠣࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡶࡨࡷࡹ࡯࡮ࡨࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡹ࡫ࡳࡵࠢࡦࡥࡸ࡫ࠠࡩࡣࡶࠤࡪࡴࡤࡦࡦ࠱ࠦᗓ"))
  except Exception as bstack1111111l1l_opy_:
    logger.error(bstack1l11ll_opy_ (u"ࠤࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡵࡩࡸࡻ࡬ࡵࡵࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡢࡦࠢࡳࡶࡴࡩࡥࡴࡵࡨࡨࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦ࠼ࠣࠦᗔ") + str(path) + bstack1l11ll_opy_ (u"ࠥࠤࡊࡸࡲࡰࡴࠣ࠾ࠧᗕ") + str(bstack1111111l1l_opy_))
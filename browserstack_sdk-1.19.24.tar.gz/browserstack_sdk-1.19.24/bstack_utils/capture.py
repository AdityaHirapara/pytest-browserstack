# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import sys
class bstack11l11l1_opy_:
    def __init__(self, handler):
        self._11l1lll111_opy_ = sys.stdout.write
        self._11l1ll1lll_opy_ = sys.stderr.write
        self.handler = handler
        self._started = False
    def start(self):
        if self._started:
            return
        self._started = True
        sys.stdout.write = self.bstack11l1lll11l_opy_
        sys.stdout.error = self.bstack11l1ll1ll1_opy_
    def bstack11l1lll11l_opy_(self, _str):
        self._11l1lll111_opy_(_str)
        if self.handler:
            self.handler({bstack1l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧቨ"): bstack1l11ll_opy_ (u"ࠩࡌࡒࡋࡕࠧቩ"), bstack1l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫቪ"): _str})
    def bstack11l1ll1ll1_opy_(self, _str):
        self._11l1ll1lll_opy_(_str)
        if self.handler:
            self.handler({bstack1l11ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪቫ"): bstack1l11ll_opy_ (u"ࠬࡋࡒࡓࡑࡕࠫቬ"), bstack1l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧቭ"): _str})
    def reset(self):
        if not self._started:
            return
        self._started = False
        sys.stdout.write = self._11l1lll111_opy_
        sys.stderr.write = self._11l1ll1lll_opy_
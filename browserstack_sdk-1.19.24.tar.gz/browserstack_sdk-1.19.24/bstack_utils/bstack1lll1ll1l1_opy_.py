# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
import json
class bstack111111lll1_opy_(object):
  bstack1ll11ll11_opy_ = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"࠭ࡾࠨᔢ")), bstack1l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧᔣ"))
  bstack11111l111l_opy_ = os.path.join(bstack1ll11ll11_opy_, bstack1l11ll_opy_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡵ࠱࡮ࡸࡵ࡮ࠨᔤ"))
  bstack111111ll1l_opy_ = None
  perform_scan = None
  bstack1l11l11l1_opy_ = None
  bstack1l1l1l11ll_opy_ = None
  bstack111111ll11_opy_ = None
  def __new__(cls):
    if not hasattr(cls, bstack1l11ll_opy_ (u"ࠩ࡬ࡲࡸࡺࡡ࡯ࡥࡨࠫᔥ")):
      cls.instance = super(bstack111111lll1_opy_, cls).__new__(cls)
      cls.instance.bstack11111l11l1_opy_()
    return cls.instance
  def bstack11111l11l1_opy_(self):
    try:
      with open(self.bstack11111l111l_opy_, bstack1l11ll_opy_ (u"ࠪࡶࠬᔦ")) as bstack1ll111111_opy_:
        bstack111111l1l1_opy_ = bstack1ll111111_opy_.read()
        data = json.loads(bstack111111l1l1_opy_)
        if bstack1l11ll_opy_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡸ࠭ᔧ") in data:
          self.bstack111111l1ll_opy_(data[bstack1l11ll_opy_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡹࠧᔨ")])
        if bstack1l11ll_opy_ (u"࠭ࡳࡤࡴ࡬ࡴࡹࡹࠧᔩ") in data:
          self.bstack11111l1111_opy_(data[bstack1l11ll_opy_ (u"ࠧࡴࡥࡵ࡭ࡵࡺࡳࠨᔪ")])
    except:
      pass
  def bstack11111l1111_opy_(self, scripts):
    if scripts != None:
      self.perform_scan = scripts[bstack1l11ll_opy_ (u"ࠨࡵࡦࡥࡳ࠭ᔫ")]
      self.bstack1l11l11l1_opy_ = scripts[bstack1l11ll_opy_ (u"ࠩࡪࡩࡹࡘࡥࡴࡷ࡯ࡸࡸ࠭ᔬ")]
      self.bstack1l1l1l11ll_opy_ = scripts[bstack1l11ll_opy_ (u"ࠪ࡫ࡪࡺࡒࡦࡵࡸࡰࡹࡹࡓࡶ࡯ࡰࡥࡷࡿࠧᔭ")]
      self.bstack111111ll11_opy_ = scripts[bstack1l11ll_opy_ (u"ࠫࡸࡧࡶࡦࡔࡨࡷࡺࡲࡴࡴࠩᔮ")]
  def bstack111111l1ll_opy_(self, bstack111111ll1l_opy_):
    if bstack111111ll1l_opy_ != None and len(bstack111111ll1l_opy_) != 0:
      self.bstack111111ll1l_opy_ = bstack111111ll1l_opy_
  def store(self):
    try:
      with open(self.bstack11111l111l_opy_, bstack1l11ll_opy_ (u"ࠬࡽࠧᔯ")) as file:
        json.dump({
          bstack1l11ll_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪࡳࠣᔰ"): self.bstack111111ll1l_opy_,
          bstack1l11ll_opy_ (u"ࠢࡴࡥࡵ࡭ࡵࡺࡳࠣᔱ"): {
            bstack1l11ll_opy_ (u"ࠣࡵࡦࡥࡳࠨᔲ"): self.perform_scan,
            bstack1l11ll_opy_ (u"ࠤࡪࡩࡹࡘࡥࡴࡷ࡯ࡸࡸࠨᔳ"): self.bstack1l11l11l1_opy_,
            bstack1l11ll_opy_ (u"ࠥ࡫ࡪࡺࡒࡦࡵࡸࡰࡹࡹࡓࡶ࡯ࡰࡥࡷࡿࠢᔴ"): self.bstack1l1l1l11ll_opy_,
            bstack1l11ll_opy_ (u"ࠦࡸࡧࡶࡦࡔࡨࡷࡺࡲࡴࡴࠤᔵ"): self.bstack111111ll11_opy_
          }
        }, file)
    except:
      pass
  def bstack1llllllll1_opy_(self, bstack111111llll_opy_):
    try:
      return any(command.get(bstack1l11ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᔶ")) == bstack111111llll_opy_ for command in self.bstack111111ll1l_opy_)
    except:
      return False
bstack1lll1ll1l1_opy_ = bstack111111lll1_opy_()
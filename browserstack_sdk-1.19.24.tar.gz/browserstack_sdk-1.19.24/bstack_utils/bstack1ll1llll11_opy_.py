# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import json
import os
import threading
from bstack_utils.config import Config
from bstack_utils.helper import bstack1l111l1l11_opy_, bstack11ll1llll_opy_, bstack1111111_opy_, bstack1ll1llllll_opy_, \
    bstack1l111l11ll_opy_
def bstack1l11l1l1l1_opy_(bstack1l111l1lll_opy_):
    for driver in bstack1l111l1lll_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack1l11lll1l_opy_(driver, status, reason=bstack1l11ll_opy_ (u"࠭ࠧื")):
    bstack1llll1ll_opy_ = Config.get_instance()
    if bstack1llll1ll_opy_.bstack1l1ll11l_opy_():
        return
    bstack1l1ll1ll11_opy_ = bstack1111l111_opy_(bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵุࠪ"), bstack1l11ll_opy_ (u"ࠨูࠩ"), status, reason, bstack1l11ll_opy_ (u"ฺࠩࠪ"), bstack1l11ll_opy_ (u"ࠪࠫ฻"))
    driver.execute_script(bstack1l1ll1ll11_opy_)
def bstack1l1111l11_opy_(page, status, reason=bstack1l11ll_opy_ (u"ࠫࠬ฼")):
    try:
        if page is None:
            return
        bstack1llll1ll_opy_ = Config.get_instance()
        if bstack1llll1ll_opy_.bstack1l1ll11l_opy_():
            return
        bstack1l1ll1ll11_opy_ = bstack1111l111_opy_(bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠨ฽"), bstack1l11ll_opy_ (u"࠭ࠧ฾"), status, reason, bstack1l11ll_opy_ (u"ࠧࠨ฿"), bstack1l11ll_opy_ (u"ࠨࠩเ"))
        page.evaluate(bstack1l11ll_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥแ"), bstack1l1ll1ll11_opy_)
    except Exception as e:
        print(bstack1l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࠣࡷࡪࡹࡳࡪࡱࡱࠤࡸࡺࡡࡵࡷࡶࠤ࡫ࡵࡲࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࢁࡽࠣโ"), e)
def bstack1111l111_opy_(type, name, status, reason, bstack1111111ll_opy_, bstack11111ll11_opy_):
    bstack111l1l1l_opy_ = {
        bstack1l11ll_opy_ (u"ࠫࡦࡩࡴࡪࡱࡱࠫใ"): type,
        bstack1l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨไ"): {}
    }
    if type == bstack1l11ll_opy_ (u"࠭ࡡ࡯ࡰࡲࡸࡦࡺࡥࠨๅ"):
        bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪๆ")][bstack1l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧ็")] = bstack1111111ll_opy_
        bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷ่ࠬ")][bstack1l11ll_opy_ (u"ࠪࡨࡦࡺࡡࠨ้")] = json.dumps(str(bstack11111ll11_opy_))
    if type == bstack1l11ll_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩ๊ࠬ"):
        bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ๋")][bstack1l11ll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ์")] = name
    if type == bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠪํ"):
        bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ๎")][bstack1l11ll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ๏")] = status
        if status == bstack1l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ๐") and str(reason) != bstack1l11ll_opy_ (u"ࠦࠧ๑"):
            bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ๒")][bstack1l11ll_opy_ (u"࠭ࡲࡦࡣࡶࡳࡳ࠭๓")] = json.dumps(str(reason))
    bstack1l11lllll1_opy_ = bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࢁࠬ๔").format(json.dumps(bstack111l1l1l_opy_))
    return bstack1l11lllll1_opy_
def bstack1l11l1ll1_opy_(url, config, logger, bstack1ll1ll1lll_opy_=False):
    hostname = bstack11ll1llll_opy_(url)
    is_private = bstack1ll1llllll_opy_(hostname)
    try:
        if is_private or bstack1ll1ll1lll_opy_:
            file_path = bstack1l111l1l11_opy_(bstack1l11ll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨ๕"), bstack1l11ll_opy_ (u"ࠩ࠱ࡦࡸࡺࡡࡤ࡭࠰ࡧࡴࡴࡦࡪࡩ࠱࡮ࡸࡵ࡮ࠨ๖"), logger)
            if os.environ.get(bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡏࡓࡈࡇࡌࡠࡐࡒࡘࡤ࡙ࡅࡕࡡࡈࡖࡗࡕࡒࠨ๗")) and eval(
                    os.environ.get(bstack1l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡑࡓ࡙ࡥࡓࡆࡖࡢࡉࡗࡘࡏࡓࠩ๘"))):
                return
            if (bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩ๙") in config and not config[bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪ๚")]):
                os.environ[bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡔࡏࡕࡡࡖࡉ࡙ࡥࡅࡓࡔࡒࡖࠬ๛")] = str(True)
                bstack1l111l11l1_opy_ = {bstack1l11ll_opy_ (u"ࠨࡪࡲࡷࡹࡴࡡ࡮ࡧࠪ๜"): hostname}
                bstack1l111l11ll_opy_(bstack1l11ll_opy_ (u"ࠩ࠱ࡦࡸࡺࡡࡤ࡭࠰ࡧࡴࡴࡦࡪࡩ࠱࡮ࡸࡵ࡮ࠨ๝"), bstack1l11ll_opy_ (u"ࠪࡲࡺࡪࡧࡦࡡ࡯ࡳࡨࡧ࡬ࠨ๞"), bstack1l111l11l1_opy_, logger)
    except Exception as e:
        pass
def bstack1llll111l1_opy_(caps, bstack1l111l1ll1_opy_):
    if bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬ๟") in caps:
        caps[bstack1l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭๠")][bstack1l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࠬ๡")] = True
        if bstack1l111l1ll1_opy_:
            caps[bstack1l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨ๢")][bstack1l11ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ๣")] = bstack1l111l1ll1_opy_
    else:
        caps[bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯࡮ࡲࡧࡦࡲࠧ๤")] = True
        if bstack1l111l1ll1_opy_:
            caps[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ๥")] = bstack1l111l1ll1_opy_
def bstack1l111ll111_opy_(bstack11l11ll_opy_):
    bstack1l111l1l1l_opy_ = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡕࡷࡥࡹࡻࡳࠨ๦"), bstack1l11ll_opy_ (u"ࠬ࠭๧"))
    if bstack1l111l1l1l_opy_ == bstack1l11ll_opy_ (u"࠭ࠧ๨") or bstack1l111l1l1l_opy_ == bstack1l11ll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨ๩"):
        threading.current_thread().testStatus = bstack11l11ll_opy_
    else:
        if bstack11l11ll_opy_ == bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ๪"):
            threading.current_thread().testStatus = bstack11l11ll_opy_
# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
import re
import sys
import json
import time
import shutil
import tempfile
import requests
import subprocess
from threading import Thread
from os.path import expanduser
from bstack_utils.constants import *
from requests.auth import HTTPBasicAuth
from bstack_utils.helper import bstack1111ll1ll_opy_, bstack1l111ll11_opy_
class bstack1lll1ll11_opy_:
  working_dir = os.getcwd()
  bstack11l1l1l11_opy_ = False
  config = {}
  binary_path = bstack1l11ll_opy_ (u"ࠫࠬᒾ")
  bstack1111l1lll1_opy_ = bstack1l11ll_opy_ (u"ࠬ࠭ᒿ")
  bstack111l11l11_opy_ = False
  bstack1111l1llll_opy_ = None
  bstack1111ll11l1_opy_ = {}
  bstack11111l1l11_opy_ = 300
  bstack1111ll1l1l_opy_ = False
  logger = None
  bstack11111lll11_opy_ = False
  bstack11111l1ll1_opy_ = bstack1l11ll_opy_ (u"࠭ࠧᓀ")
  bstack11111lll1l_opy_ = {
    bstack1l11ll_opy_ (u"ࠧࡤࡪࡵࡳࡲ࡫ࠧᓁ") : 1,
    bstack1l11ll_opy_ (u"ࠨࡨ࡬ࡶࡪ࡬࡯ࡹࠩᓂ") : 2,
    bstack1l11ll_opy_ (u"ࠩࡨࡨ࡬࡫ࠧᓃ") : 3,
    bstack1l11ll_opy_ (u"ࠪࡷࡦ࡬ࡡࡳ࡫ࠪᓄ") : 4
  }
  def __init__(self) -> None: pass
  def bstack1111ll1l11_opy_(self):
    bstack1111l11l11_opy_ = bstack1l11ll_opy_ (u"ࠫࠬᓅ")
    bstack1111llll11_opy_ = sys.platform
    bstack11111ll111_opy_ = bstack1l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼࠫᓆ")
    if re.match(bstack1l11ll_opy_ (u"ࠨࡤࡢࡴࡺ࡭ࡳࢂ࡭ࡢࡥࠣࡳࡸࠨᓇ"), bstack1111llll11_opy_) != None:
      bstack1111l11l11_opy_ = bstack11llll111l_opy_ + bstack1l11ll_opy_ (u"ࠢ࠰ࡲࡨࡶࡨࡿ࠭ࡰࡵࡻ࠲ࡿ࡯ࡰࠣᓈ")
      self.bstack11111l1ll1_opy_ = bstack1l11ll_opy_ (u"ࠨ࡯ࡤࡧࠬᓉ")
    elif re.match(bstack1l11ll_opy_ (u"ࠤࡰࡷࡼ࡯࡮ࡽ࡯ࡶࡽࡸࢂ࡭ࡪࡰࡪࡻࢁࡩࡹࡨࡹ࡬ࡲࢁࡨࡣࡤࡹ࡬ࡲࢁࡽࡩ࡯ࡥࡨࢀࡪࡳࡣࡽࡹ࡬ࡲ࠸࠸ࠢᓊ"), bstack1111llll11_opy_) != None:
      bstack1111l11l11_opy_ = bstack11llll111l_opy_ + bstack1l11ll_opy_ (u"ࠥ࠳ࡵ࡫ࡲࡤࡻ࠰ࡻ࡮ࡴ࠮ࡻ࡫ࡳࠦᓋ")
      bstack11111ll111_opy_ = bstack1l11ll_opy_ (u"ࠦࡵ࡫ࡲࡤࡻ࠱ࡩࡽ࡫ࠢᓌ")
      self.bstack11111l1ll1_opy_ = bstack1l11ll_opy_ (u"ࠬࡽࡩ࡯ࠩᓍ")
    else:
      bstack1111l11l11_opy_ = bstack11llll111l_opy_ + bstack1l11ll_opy_ (u"ࠨ࠯ࡱࡧࡵࡧࡾ࠳࡬ࡪࡰࡸࡼ࠳ࢀࡩࡱࠤᓎ")
      self.bstack11111l1ll1_opy_ = bstack1l11ll_opy_ (u"ࠧ࡭࡫ࡱࡹࡽ࠭ᓏ")
    return bstack1111l11l11_opy_, bstack11111ll111_opy_
  def bstack1111l111l1_opy_(self):
    try:
      bstack1111llll1l_opy_ = [os.path.join(expanduser(bstack1l11ll_opy_ (u"ࠣࢀࠥᓐ")), bstack1l11ll_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩᓑ")), self.working_dir, tempfile.gettempdir()]
      for path in bstack1111llll1l_opy_:
        if(self.bstack1111ll11ll_opy_(path)):
          return path
      raise bstack1l11ll_opy_ (u"࡙ࠥࡳࡧ࡬ࡣࡧࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡨࡶࡨࡿࠠࡣ࡫ࡱࡥࡷࡿࠢᓒ")
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡧ࡫ࡱࡨࠥࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡲࡤࡸ࡭ࠦࡦࡰࡴࠣࡴࡪࡸࡣࡺࠢࡧࡳࡼࡴ࡬ࡰࡣࡧ࠰ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࠯ࠣࡿࢂࠨᓓ").format(e))
  def bstack1111ll11ll_opy_(self, path):
    try:
      if not os.path.exists(path):
        os.makedirs(path)
      return True
    except:
      return False
  def bstack1111l1l1ll_opy_(self, bstack1111l11l11_opy_, bstack11111ll111_opy_):
    try:
      bstack11111lllll_opy_ = self.bstack1111l111l1_opy_()
      bstack11111ll1l1_opy_ = os.path.join(bstack11111lllll_opy_, bstack1l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼ࠲ࡿ࡯ࡰࠨᓔ"))
      bstack1111l1l1l1_opy_ = os.path.join(bstack11111lllll_opy_, bstack11111ll111_opy_)
      if os.path.exists(bstack1111l1l1l1_opy_):
        self.logger.info(bstack1l11ll_opy_ (u"ࠨࡐࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࡼࡿ࠯ࠤࡸࡱࡩࡱࡲ࡬ࡲ࡬ࠦࡤࡰࡹࡱࡰࡴࡧࡤࠣᓕ").format(bstack1111l1l1l1_opy_))
        return bstack1111l1l1l1_opy_
      if os.path.exists(bstack11111ll1l1_opy_):
        self.logger.info(bstack1l11ll_opy_ (u"ࠢࡑࡧࡵࡧࡾࠦࡺࡪࡲࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࢁࡽ࠭ࠢࡸࡲࡿ࡯ࡰࡱ࡫ࡱ࡫ࠧᓖ").format(bstack11111ll1l1_opy_))
        return self.bstack1111ll111l_opy_(bstack11111ll1l1_opy_, bstack11111ll111_opy_)
      self.logger.info(bstack1l11ll_opy_ (u"ࠣࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠥ࡬ࡲࡰ࡯ࠣࡿࢂࠨᓗ").format(bstack1111l11l11_opy_))
      response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"ࠩࡊࡉ࡙࠭ᓘ"), bstack1111l11l11_opy_, {}, {})
      if response.status_code == 200:
        with open(bstack11111ll1l1_opy_, bstack1l11ll_opy_ (u"ࠪࡻࡧ࠭ᓙ")) as file:
          file.write(response.content)
        self.logger.info(bstack1l11ll_opy_ (u"ࠦࡉࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡲࡨࡶࡨࡿࠠࡣ࡫ࡱࡥࡷࡿࠠࡢࡰࡧࠤࡸࡧࡶࡦࡦࠣࡥࡹࠦࡻࡾࠤᓚ").format(bstack11111ll1l1_opy_))
        return self.bstack1111ll111l_opy_(bstack11111ll1l1_opy_, bstack11111ll111_opy_)
      else:
        raise(bstack1l11ll_opy_ (u"ࠧࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡧ࡫࡯ࡩ࠳ࠦࡓࡵࡣࡷࡹࡸࠦࡣࡰࡦࡨ࠾ࠥࢁࡽࠣᓛ").format(response.status_code))
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵ࡫ࡲࡤࡻࠣࡦ࡮ࡴࡡࡳࡻ࠽ࠤࢀࢃࠢᓜ").format(e))
  def bstack11111l11ll_opy_(self, bstack1111l11l11_opy_, bstack11111ll111_opy_):
    try:
      retry = 2
      bstack1111l1l1l1_opy_ = None
      bstack111l11111l_opy_ = False
      while retry > 0:
        bstack1111l1l1l1_opy_ = self.bstack1111l1l1ll_opy_(bstack1111l11l11_opy_, bstack11111ll111_opy_)
        bstack111l11111l_opy_ = self.bstack1111l11l1l_opy_(bstack1111l11l11_opy_, bstack11111ll111_opy_, bstack1111l1l1l1_opy_)
        if bstack111l11111l_opy_:
          break
        retry -= 1
      return bstack1111l1l1l1_opy_, bstack111l11111l_opy_
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣ࡫ࡪࡺࠠࡱࡧࡵࡧࡾࠦࡢࡪࡰࡤࡶࡾࠦࡰࡢࡶ࡫ࠦᓝ").format(e))
    return bstack1111l1l1l1_opy_, False
  def bstack1111l11l1l_opy_(self, bstack1111l11l11_opy_, bstack11111ll111_opy_, bstack1111l1l1l1_opy_, bstack1111ll1lll_opy_ = 0):
    if bstack1111ll1lll_opy_ > 1:
      return False
    if bstack1111l1l1l1_opy_ == None or os.path.exists(bstack1111l1l1l1_opy_) == False:
      self.logger.warn(bstack1l11ll_opy_ (u"ࠣࡒࡨࡶࡨࡿࠠࡱࡣࡷ࡬ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤ࠭ࠢࡵࡩࡹࡸࡹࡪࡰࡪࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠨᓞ"))
      return False
    bstack1111l1l11l_opy_ = bstack1l11ll_opy_ (u"ࠤࡡ࠲࠯ࡆࡰࡦࡴࡦࡽࡡ࠵ࡣ࡭࡫ࠣࡠࡩ࠴࡜ࡥ࠭࠱ࡠࡩ࠱ࠢᓟ")
    command = bstack1l11ll_opy_ (u"ࠪࡿࢂࠦ࠭࠮ࡸࡨࡶࡸ࡯࡯࡯ࠩᓠ").format(bstack1111l1l1l1_opy_)
    bstack1111ll1ll1_opy_ = subprocess.check_output(command, shell=True, text=True)
    if re.match(bstack1111l1l11l_opy_, bstack1111ll1ll1_opy_) != None:
      return True
    else:
      self.logger.error(bstack1l11ll_opy_ (u"ࠦࡕ࡫ࡲࡤࡻࠣࡺࡪࡸࡳࡪࡱࡱࠤࡨ࡮ࡥࡤ࡭ࠣࡪࡦ࡯࡬ࡦࡦࠥᓡ"))
      return False
  def bstack1111ll111l_opy_(self, bstack11111ll1l1_opy_, bstack11111ll111_opy_):
    try:
      working_dir = os.path.dirname(bstack11111ll1l1_opy_)
      shutil.unpack_archive(bstack11111ll1l1_opy_, working_dir)
      bstack1111l1l1l1_opy_ = os.path.join(working_dir, bstack11111ll111_opy_)
      os.chmod(bstack1111l1l1l1_opy_, 0o755)
      return bstack1111l1l1l1_opy_
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡷࡱࡾ࡮ࡶࠠࡱࡧࡵࡧࡾࠦࡢࡪࡰࡤࡶࡾࠨᓢ"))
  def bstack11111ll11l_opy_(self):
    try:
      percy = str(self.config.get(bstack1l11ll_opy_ (u"࠭ࡰࡦࡴࡦࡽࠬᓣ"), bstack1l11ll_opy_ (u"ࠢࡧࡣ࡯ࡷࡪࠨᓤ"))).lower()
      if percy != bstack1l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨᓥ"):
        return False
      self.bstack111l11l11_opy_ = True
      return True
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡦࡸࠥࡶࡥࡳࡥࡼ࠰ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡽࢀࠦᓦ").format(e))
  def bstack1111lll11l_opy_(self):
    try:
      bstack1111lll11l_opy_ = str(self.config.get(bstack1l11ll_opy_ (u"ࠪࡴࡪࡸࡣࡺࡅࡤࡴࡹࡻࡲࡦࡏࡲࡨࡪ࠭ᓧ"), bstack1l11ll_opy_ (u"ࠦࡦࡻࡴࡰࠤᓨ"))).lower()
      return bstack1111lll11l_opy_
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡨࡸࡪࡩࡴࠡࡲࡨࡶࡨࡿࠠࡤࡣࡳࡸࡺࡸࡥࠡ࡯ࡲࡨࡪ࠲ࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡿࢂࠨᓩ").format(e))
  def init(self, bstack11l1l1l11_opy_, config, logger):
    self.bstack11l1l1l11_opy_ = bstack11l1l1l11_opy_
    self.config = config
    self.logger = logger
    if not self.bstack11111ll11l_opy_():
      return
    self.bstack1111ll11l1_opy_ = config.get(bstack1l11ll_opy_ (u"࠭ࡰࡦࡴࡦࡽࡔࡶࡴࡪࡱࡱࡷࠬᓪ"), {})
    self.bstack111l111l11_opy_ = config.get(bstack1l11ll_opy_ (u"ࠧࡱࡧࡵࡧࡾࡉࡡࡱࡶࡸࡶࡪࡓ࡯ࡥࡧࠪᓫ"), bstack1l11ll_opy_ (u"ࠣࡣࡸࡸࡴࠨᓬ"))
    try:
      bstack1111l11l11_opy_, bstack11111ll111_opy_ = self.bstack1111ll1l11_opy_()
      bstack1111l1l1l1_opy_, bstack111l11111l_opy_ = self.bstack11111l11ll_opy_(bstack1111l11l11_opy_, bstack11111ll111_opy_)
      if bstack111l11111l_opy_:
        self.binary_path = bstack1111l1l1l1_opy_
        thread = Thread(target=self.bstack111l111ll1_opy_)
        thread.start()
      else:
        self.bstack11111lll11_opy_ = True
        self.logger.error(bstack1l11ll_opy_ (u"ࠤࡌࡲࡻࡧ࡬ࡪࡦࠣࡴࡪࡸࡣࡺࠢࡳࡥࡹ࡮ࠠࡧࡱࡸࡲࡩࠦ࠭ࠡࡽࢀ࠰࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡑࡧࡵࡧࡾࠨᓭ").format(bstack1111l1l1l1_opy_))
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡶࡥࡳࡥࡼ࠰ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡽࢀࠦᓮ").format(e))
  def bstack1111l11ll1_opy_(self):
    try:
      logfile = os.path.join(self.working_dir, bstack1l11ll_opy_ (u"ࠫࡱࡵࡧࠨᓯ"), bstack1l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼ࠲ࡱࡵࡧࠨᓰ"))
      os.makedirs(os.path.dirname(logfile)) if not os.path.exists(os.path.dirname(logfile)) else None
      self.logger.debug(bstack1l11ll_opy_ (u"ࠨࡐࡶࡵ࡫࡭ࡳ࡭ࠠࡱࡧࡵࡧࡾࠦ࡬ࡰࡩࡶࠤࡦࡺࠠࡼࡿࠥᓱ").format(logfile))
      self.bstack1111l1lll1_opy_ = logfile
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡷࡪࡺࠠࡱࡧࡵࡧࡾࠦ࡬ࡰࡩࠣࡴࡦࡺࡨ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࢁࡽࠣᓲ").format(e))
  def bstack111l111ll1_opy_(self):
    bstack1111lll111_opy_ = self.bstack1111l1ll1l_opy_()
    if bstack1111lll111_opy_ == None:
      self.bstack11111lll11_opy_ = True
      self.logger.error(bstack1l11ll_opy_ (u"ࠣࡒࡨࡶࡨࡿࠠࡵࡱ࡮ࡩࡳࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥ࠮ࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡶࡥࡳࡥࡼࠦᓳ"))
      return False
    command_args = [bstack1l11ll_opy_ (u"ࠤࡤࡴࡵࡀࡥࡹࡧࡦ࠾ࡸࡺࡡࡳࡶࠥᓴ") if self.bstack11l1l1l11_opy_ else bstack1l11ll_opy_ (u"ࠪࡩࡽ࡫ࡣ࠻ࡵࡷࡥࡷࡺࠧᓵ")]
    bstack1111l11111_opy_ = self.bstack1111ll1111_opy_()
    if bstack1111l11111_opy_ != None:
      command_args.append(bstack1l11ll_opy_ (u"ࠦ࠲ࡩࠠࡼࡿࠥᓶ").format(bstack1111l11111_opy_))
    env = os.environ.copy()
    env[bstack1l11ll_opy_ (u"ࠧࡖࡅࡓࡅ࡜ࡣ࡙ࡕࡋࡆࡐࠥᓷ")] = bstack1111lll111_opy_
    bstack111l1111l1_opy_ = [self.binary_path]
    self.bstack1111l11ll1_opy_()
    self.bstack1111l1llll_opy_ = self.bstack1111l1ll11_opy_(bstack111l1111l1_opy_ + command_args, env)
    self.logger.debug(bstack1l11ll_opy_ (u"ࠨࡓࡵࡣࡵࡸ࡮ࡴࡧࠡࡊࡨࡥࡱࡺࡨࠡࡅ࡫ࡩࡨࡱࠢᓸ"))
    bstack1111ll1lll_opy_ = 0
    while self.bstack1111l1llll_opy_.poll() == None:
      bstack1111lll1ll_opy_ = self.bstack111l111l1l_opy_()
      if bstack1111lll1ll_opy_:
        self.logger.debug(bstack1l11ll_opy_ (u"ࠢࡉࡧࡤࡰࡹ࡮ࠠࡄࡪࡨࡧࡰࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮ࠥᓹ"))
        self.bstack1111ll1l1l_opy_ = True
        return True
      bstack1111ll1lll_opy_ += 1
      self.logger.debug(bstack1l11ll_opy_ (u"ࠣࡊࡨࡥࡱࡺࡨࠡࡅ࡫ࡩࡨࡱࠠࡓࡧࡷࡶࡾࠦ࠭ࠡࡽࢀࠦᓺ").format(bstack1111ll1lll_opy_))
      time.sleep(2)
    self.logger.error(bstack1l11ll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡵ࡫ࡲࡤࡻ࠯ࠤࡍ࡫ࡡ࡭ࡶ࡫ࠤࡈ࡮ࡥࡤ࡭ࠣࡊࡦ࡯࡬ࡦࡦࠣࡥ࡫ࡺࡥࡳࠢࡾࢁࠥࡧࡴࡵࡧࡰࡴࡹࡹࠢᓻ").format(bstack1111ll1lll_opy_))
    self.bstack11111lll11_opy_ = True
    return False
  def bstack111l111l1l_opy_(self, bstack1111ll1lll_opy_ = 0):
    try:
      if bstack1111ll1lll_opy_ > 10:
        return False
      bstack1111llllll_opy_ = os.environ.get(bstack1l11ll_opy_ (u"ࠪࡔࡊࡘࡃ࡚ࡡࡖࡉࡗ࡜ࡅࡓࡡࡄࡈࡉࡘࡅࡔࡕࠪᓼ"), bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠵࠶࠼ࠬᓽ"))
      bstack111l1111ll_opy_ = bstack1111llllll_opy_ + bstack11lll1llll_opy_
      response = requests.get(bstack111l1111ll_opy_)
      return True if response.json() else False
    except:
      return False
  def bstack1111l1ll1l_opy_(self):
    bstack1111l11lll_opy_ = bstack1l11ll_opy_ (u"ࠬࡧࡰࡱࠩᓾ") if self.bstack11l1l1l11_opy_ else bstack1l11ll_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡥࠨᓿ")
    bstack11ll1l1111_opy_ = bstack1l11ll_opy_ (u"ࠢࡢࡲ࡬࠳ࡦࡶࡰࡠࡲࡨࡶࡨࡿ࠯ࡨࡧࡷࡣࡵࡸ࡯࡫ࡧࡦࡸࡤࡺ࡯࡬ࡧࡱࡃࡳࡧ࡭ࡦ࠿ࡾࢁࠫࡺࡹࡱࡧࡀࡿࢂࠨᔀ").format(self.config[bstack1l11ll_opy_ (u"ࠨࡲࡵࡳ࡯࡫ࡣࡵࡐࡤࡱࡪ࠭ᔁ")], bstack1111l11lll_opy_)
    uri = bstack1111ll1ll_opy_(bstack11ll1l1111_opy_)
    try:
      response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"ࠩࡊࡉ࡙࠭ᔂ"), uri, {}, {bstack1l11ll_opy_ (u"ࠪࡥࡺࡺࡨࠨᔃ"): (self.config[bstack1l11ll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ᔄ")], self.config[bstack1l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨᔅ")])})
      if response.status_code == 200:
        bstack1111l111ll_opy_ = response.json()
        if bstack1l11ll_opy_ (u"ࠨࡴࡰ࡭ࡨࡲࠧᔆ") in bstack1111l111ll_opy_:
          return bstack1111l111ll_opy_[bstack1l11ll_opy_ (u"ࠢࡵࡱ࡮ࡩࡳࠨᔇ")]
        else:
          raise bstack1l11ll_opy_ (u"ࠨࡖࡲ࡯ࡪࡴࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠣ࠱ࠥࢁࡽࠨᔈ").format(bstack1111l111ll_opy_)
      else:
        raise bstack1l11ll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥ࡬ࡥࡵࡥ࡫ࠤࡵ࡫ࡲࡤࡻࠣࡸࡴࡱࡥ࡯࠮ࠣࡖࡪࡹࡰࡰࡰࡶࡩࠥࡹࡴࡢࡶࡸࡷࠥ࠳ࠠࡼࡿ࠯ࠤࡗ࡫ࡳࡱࡱࡱࡷࡪࠦࡂࡰࡦࡼࠤ࠲ࠦࡻࡾࠤᔉ").format(response.status_code, response.json())
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡦࡶࡪࡧࡴࡪࡰࡪࠤࡵ࡫ࡲࡤࡻࠣࡴࡷࡵࡪࡦࡥࡷࠦᔊ").format(e))
  def bstack1111ll1111_opy_(self):
    bstack1111l1l111_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"ࠦࡵ࡫ࡲࡤࡻࡆࡳࡳ࡬ࡩࡨ࠰࡭ࡷࡴࡴࠢᔋ"))
    try:
      if bstack1l11ll_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ᔌ") not in self.bstack1111ll11l1_opy_:
        self.bstack1111ll11l1_opy_[bstack1l11ll_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧᔍ")] = 2
      with open(bstack1111l1l111_opy_, bstack1l11ll_opy_ (u"ࠧࡸࠩᔎ")) as fp:
        json.dump(self.bstack1111ll11l1_opy_, fp)
      return bstack1111l1l111_opy_
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡨࡸࡥࡢࡶࡨࠤࡵ࡫ࡲࡤࡻࠣࡧࡴࡴࡦ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࢁࡽࠣᔏ").format(e))
  def bstack1111l1ll11_opy_(self, cmd, env = os.environ.copy()):
    try:
      if self.bstack11111l1ll1_opy_ == bstack1l11ll_opy_ (u"ࠩࡺ࡭ࡳ࠭ᔐ"):
        bstack1111l1111l_opy_ = [bstack1l11ll_opy_ (u"ࠪࡧࡲࡪ࠮ࡦࡺࡨࠫᔑ"), bstack1l11ll_opy_ (u"ࠫ࠴ࡩࠧᔒ")]
        cmd = bstack1111l1111l_opy_ + cmd
      cmd = bstack1l11ll_opy_ (u"ࠬࠦࠧᔓ").join(cmd)
      self.logger.debug(bstack1l11ll_opy_ (u"ࠨࡒࡶࡰࡱ࡭ࡳ࡭ࠠࡼࡿࠥᔔ").format(cmd))
      with open(self.bstack1111l1lll1_opy_, bstack1l11ll_opy_ (u"ࠢࡢࠤᔕ")) as bstack11111llll1_opy_:
        process = subprocess.Popen(cmd, shell=True, stdout=bstack11111llll1_opy_, text=True, stderr=bstack11111llll1_opy_, env=env, universal_newlines=True)
      return process
    except Exception as e:
      self.bstack11111lll11_opy_ = True
      self.logger.error(bstack1l11ll_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡴࡪࡸࡣࡺࠢࡺ࡭ࡹ࡮ࠠࡤ࡯ࡧࠤ࠲ࠦࡻࡾ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࡀࠠࡼࡿࠥᔖ").format(cmd, e))
  def shutdown(self):
    try:
      if self.bstack1111ll1l1l_opy_:
        self.logger.info(bstack1l11ll_opy_ (u"ࠤࡖࡸࡴࡶࡰࡪࡰࡪࠤࡕ࡫ࡲࡤࡻࠥᔗ"))
        cmd = [self.binary_path, bstack1l11ll_opy_ (u"ࠥࡩࡽ࡫ࡣ࠻ࡵࡷࡳࡵࠨᔘ")]
        self.bstack1111l1ll11_opy_(cmd)
        self.bstack1111ll1l1l_opy_ = False
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡴࡶࡲࡴࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡷࡪࡶ࡫ࠤࡨࡵ࡭࡮ࡣࡱࡨࠥ࠳ࠠࡼࡿ࠯ࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡽࢀࠦᔙ").format(cmd, e))
  def bstack1ll1ll1ll_opy_(self):
    if not self.bstack111l11l11_opy_:
      return
    try:
      bstack1111lllll1_opy_ = 0
      while not self.bstack1111ll1l1l_opy_ and bstack1111lllll1_opy_ < self.bstack11111l1l11_opy_:
        if self.bstack11111lll11_opy_:
          self.logger.info(bstack1l11ll_opy_ (u"ࠧࡖࡥࡳࡥࡼࠤࡸ࡫ࡴࡶࡲࠣࡪࡦ࡯࡬ࡦࡦࠥᔚ"))
          return
        time.sleep(1)
        bstack1111lllll1_opy_ += 1
      os.environ[bstack1l11ll_opy_ (u"࠭ࡐࡆࡔࡆ࡝ࡤࡈࡅࡔࡖࡢࡔࡑࡇࡔࡇࡑࡕࡑࠬᔛ")] = str(self.bstack11111l1l1l_opy_())
      self.logger.info(bstack1l11ll_opy_ (u"ࠢࡑࡧࡵࡧࡾࠦࡳࡦࡶࡸࡴࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠣᔜ"))
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡸ࡫ࡴࡶࡲࠣࡴࡪࡸࡣࡺ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤᔝ").format(e))
  def bstack11111l1l1l_opy_(self):
    if self.bstack11l1l1l11_opy_:
      return
    try:
      bstack11111ll1ll_opy_ = [platform[bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧᔞ")].lower() for platform in self.config.get(bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ᔟ"), [])]
      bstack11111l1lll_opy_ = sys.maxsize
      bstack111l111111_opy_ = bstack1l11ll_opy_ (u"ࠫࠬᔠ")
      for browser in bstack11111ll1ll_opy_:
        if browser in self.bstack11111lll1l_opy_:
          bstack1111lll1l1_opy_ = self.bstack11111lll1l_opy_[browser]
        if bstack1111lll1l1_opy_ < bstack11111l1lll_opy_:
          bstack11111l1lll_opy_ = bstack1111lll1l1_opy_
          bstack111l111111_opy_ = browser
      return bstack111l111111_opy_
    except Exception as e:
      self.logger.error(bstack1l11ll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡨ࡬ࡲࡩࠦࡢࡦࡵࡷࠤࡵࡲࡡࡵࡨࡲࡶࡲ࠲ࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡿࢂࠨᔡ").format(e))
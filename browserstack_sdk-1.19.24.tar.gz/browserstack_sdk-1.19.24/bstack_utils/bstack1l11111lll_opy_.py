# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
from _pytest import fixtures
from _pytest.python import _call_with_optional_argument
from pytest import Module, Class
from bstack_utils.helper import Result, bstack1l1111l111_opy_
from browserstack_sdk.bstack1lll111l_opy_ import bstack1lll1l1l_opy_
def _11lllllll1_opy_(method, this, arg):
    arg_count = method.__code__.co_argcount
    if arg_count > 1:
        method(this, arg)
    else:
        method(this)
class bstack11llllll1l_opy_:
    def __init__(self, handler):
        self._1l1111l11l_opy_ = {}
        self._11lllll11l_opy_ = {}
        self.handler = handler
        self.patch()
        pass
    def patch(self):
        bstack1l111111ll_opy_ = bstack1lll1l1l_opy_.version()
        if bstack1l1111l111_opy_(bstack1l111111ll_opy_, bstack1l11ll_opy_ (u"ࠦ࠽࠴࠱࠯࠳ࠥຐ")) >= 0:
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨຑ")] = Module._register_setup_function_fixture
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"࠭࡭ࡰࡦࡸࡰࡪࡥࡦࡪࡺࡷࡹࡷ࡫ࠧຒ")] = Module._register_setup_module_fixture
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"ࠧࡤ࡮ࡤࡷࡸࡥࡦࡪࡺࡷࡹࡷ࡫ࠧຓ")] = Class._register_setup_class_fixture
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨ࡬ࡼࡹࡻࡲࡦࠩດ")] = Class._register_setup_method_fixture
            Module._register_setup_function_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬຕ"))
            Module._register_setup_module_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"ࠪࡱࡴࡪࡵ࡭ࡧࡢࡪ࡮ࡾࡴࡶࡴࡨࠫຖ"))
            Class._register_setup_class_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"ࠫࡨࡲࡡࡴࡵࡢࡪ࡮ࡾࡴࡶࡴࡨࠫທ"))
            Class._register_setup_method_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ຘ"))
        else:
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩນ")] = Module._inject_setup_function_fixture
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"ࠧ࡮ࡱࡧࡹࡱ࡫࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨບ")] = Module._inject_setup_module_fixture
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"ࠨࡥ࡯ࡥࡸࡹ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨປ")] = Class._inject_setup_class_fixture
            self._1l1111l11l_opy_[bstack1l11ll_opy_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩ࡭ࡽࡺࡵࡳࡧࠪຜ")] = Class._inject_setup_method_fixture
            Module._inject_setup_function_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ຝ"))
            Module._inject_setup_module_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"ࠫࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠬພ"))
            Class._inject_setup_class_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"ࠬࡩ࡬ࡢࡵࡶࡣ࡫࡯ࡸࡵࡷࡵࡩࠬຟ"))
            Class._inject_setup_method_fixture = self.bstack1l1111111l_opy_(bstack1l11ll_opy_ (u"࠭࡭ࡦࡶ࡫ࡳࡩࡥࡦࡪࡺࡷࡹࡷ࡫ࠧຠ"))
    def bstack1l111111l1_opy_(self, bstack1l11111111_opy_, hook_type):
        meth = getattr(bstack1l11111111_opy_, hook_type, None)
        if meth is not None and fixtures.getfixturemarker(meth) is None:
            self._11lllll11l_opy_[hook_type] = meth
            setattr(bstack1l11111111_opy_, hook_type, self.bstack11llllll11_opy_(hook_type))
    def bstack11llllllll_opy_(self, instance, bstack1l11111l1l_opy_):
        if bstack1l11111l1l_opy_ == bstack1l11ll_opy_ (u"ࠢࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡩ࡭ࡽࡺࡵࡳࡧࠥມ"):
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠣࡵࡨࡸࡺࡶ࡟ࡧࡷࡱࡧࡹ࡯࡯࡯ࠤຢ"))
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠤࡷࡩࡦࡸࡤࡰࡹࡱࡣ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠨຣ"))
        if bstack1l11111l1l_opy_ == bstack1l11ll_opy_ (u"ࠥࡱࡴࡪࡵ࡭ࡧࡢࡪ࡮ࡾࡴࡶࡴࡨࠦ຤"):
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠦࡸ࡫ࡴࡶࡲࡢࡱࡴࡪࡵ࡭ࡧࠥລ"))
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡱࡧࡹࡱ࡫ࠢ຦"))
        if bstack1l11111l1l_opy_ == bstack1l11ll_opy_ (u"ࠨࡣ࡭ࡣࡶࡷࡤ࡬ࡩࡹࡶࡸࡶࡪࠨວ"):
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠢࡴࡧࡷࡹࡵࡥࡣ࡭ࡣࡶࡷࠧຨ"))
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠣࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡧࡱࡧࡳࡴࠤຩ"))
        if bstack1l11111l1l_opy_ == bstack1l11ll_opy_ (u"ࠤࡰࡩࡹ࡮࡯ࡥࡡࡩ࡭ࡽࡺࡵࡳࡧࠥສ"):
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠥࡷࡪࡺࡵࡱࡡࡰࡩࡹ࡮࡯ࡥࠤຫ"))
            self.bstack1l111111l1_opy_(instance.obj, bstack1l11ll_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࡥ࡭ࡦࡶ࡫ࡳࡩࠨຬ"))
    @staticmethod
    def bstack1l11111l11_opy_(hook_type, func, args):
        if hook_type in [bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲ࡫ࡴࡩࡱࡧࠫອ"), bstack1l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡨࡸ࡭ࡵࡤࠨຮ")]:
            _11lllllll1_opy_(func, args[0], args[1])
            return
        _call_with_optional_argument(func, args[0])
    def bstack11llllll11_opy_(self, hook_type):
        def bstack11lllll1ll_opy_(arg=None):
            self.handler(hook_type, bstack1l11ll_opy_ (u"ࠧࡣࡧࡩࡳࡷ࡫ࠧຯ"))
            result = None
            exception = None
            try:
                self.bstack1l11111l11_opy_(hook_type, self._11lllll11l_opy_[hook_type], (arg,))
                result = Result(result=bstack1l11ll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨະ"))
            except Exception as e:
                result = Result(result=bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩັ"), exception=e)
                self.handler(hook_type, bstack1l11ll_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࠩາ"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1l11ll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࠪຳ"), result)
        def bstack11lllll1l1_opy_(this, arg=None):
            self.handler(hook_type, bstack1l11ll_opy_ (u"ࠬࡨࡥࡧࡱࡵࡩࠬິ"))
            result = None
            exception = None
            try:
                self.bstack1l11111l11_opy_(hook_type, self._11lllll11l_opy_[hook_type], (this, arg))
                result = Result(result=bstack1l11ll_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭ີ"))
            except Exception as e:
                result = Result(result=bstack1l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧຶ"), exception=e)
                self.handler(hook_type, bstack1l11ll_opy_ (u"ࠨࡣࡩࡸࡪࡸࠧື"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack1l11ll_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࠨຸ"), result)
        if hook_type in [bstack1l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࡡࡰࡩࡹ࡮࡯ࡥູࠩ"), bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳࡥ࡭ࡦࡶ࡫ࡳࡩ຺࠭")]:
            return bstack11lllll1l1_opy_
        return bstack11lllll1ll_opy_
    def bstack1l1111111l_opy_(self, bstack1l11111l1l_opy_):
        def bstack1l11111ll1_opy_(this, *args, **kwargs):
            self.bstack11llllllll_opy_(this, bstack1l11111l1l_opy_)
            self._1l1111l11l_opy_[bstack1l11111l1l_opy_](this, *args, **kwargs)
        return bstack1l11111ll1_opy_
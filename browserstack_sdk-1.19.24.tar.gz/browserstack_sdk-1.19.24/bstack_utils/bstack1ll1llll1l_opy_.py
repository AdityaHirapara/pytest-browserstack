# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
from browserstack_sdk.bstack1lll111l_opy_ import bstack1lll1l1l_opy_
from browserstack_sdk.bstack1ll1ll1_opy_ import RobotHandler
def bstack1llll11ll_opy_(framework):
    if framework.lower() == bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫᗖ"):
        return bstack1lll1l1l_opy_.version()
    elif framework.lower() == bstack1l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫᗗ"):
        return RobotHandler.version()
    elif framework.lower() == bstack1l11ll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭ᗘ"):
        import behave
        return behave.__version__
    else:
        return bstack1l11ll_opy_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨᗙ")
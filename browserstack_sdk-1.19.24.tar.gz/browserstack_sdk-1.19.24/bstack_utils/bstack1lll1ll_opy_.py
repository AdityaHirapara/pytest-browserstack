# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
from uuid import uuid4
from bstack_utils.helper import current_time, bstack11l11111l1_opy_
from bstack_utils.bstack111ll111l_opy_ import bstack11l1lllll1_opy_
class bstack1ll1lll_opy_:
    def __init__(self, name=None, code=None, uuid=None, file_path=None, bstack111ll11_opy_=None, framework=None, tags=[], scope=[], bstack111l1l1ll1_opy_=None, bstack111l11llll_opy_=True, bstack111l11l1l1_opy_=None, bstack111l11ll_opy_=None, result=None, duration=None, bstack1lllll1l_opy_=None, meta={}):
        self.bstack1lllll1l_opy_ = bstack1lllll1l_opy_
        self.name = name
        self.code = code
        self.file_path = file_path
        self.uuid = uuid
        if not self.uuid and bstack111l11llll_opy_:
            self.uuid = uuid4().__str__()
        self.bstack111ll11_opy_ = bstack111ll11_opy_
        self.framework = framework
        self.tags = tags
        self.scope = scope
        self.bstack111l1l1ll1_opy_ = bstack111l1l1ll1_opy_
        self.bstack111l11l1l1_opy_ = bstack111l11l1l1_opy_
        self.bstack111l11ll_opy_ = bstack111l11ll_opy_
        self.result = result
        self.duration = duration
        self.meta = meta
    def bstack1llll11_opy_(self):
        if self.uuid:
            return self.uuid
        self.uuid = uuid4().__str__()
        return self.uuid
    def bstack111l1l111l_opy_(self):
        bstack111l11lll1_opy_ = os.path.relpath(self.file_path, start=os.getcwd())
        return {
            bstack1l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨᒀ"): bstack111l11lll1_opy_,
            bstack1l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨᒁ"): bstack111l11lll1_opy_,
            bstack1l11ll_opy_ (u"ࠧࡷࡥࡢࡪ࡮ࡲࡥࡱࡣࡷ࡬ࠬᒂ"): bstack111l11lll1_opy_
        }
    def set(self, **kwargs):
        for key, val in kwargs.items():
            if not hasattr(self, key):
                raise TypeError(bstack1l11ll_opy_ (u"ࠣࡗࡱࡩࡽࡶࡥࡤࡶࡨࡨࠥࡧࡲࡨࡷࡰࡩࡳࡺ࠺ࠡࠤᒃ") + key)
            setattr(self, key, val)
    def bstack111l1l11ll_opy_(self):
        return {
            bstack1l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧᒄ"): self.name,
            bstack1l11ll_opy_ (u"ࠪࡦࡴࡪࡹࠨᒅ"): {
                bstack1l11ll_opy_ (u"ࠫࡱࡧ࡮ࡨࠩᒆ"): bstack1l11ll_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬᒇ"),
                bstack1l11ll_opy_ (u"࠭ࡣࡰࡦࡨࠫᒈ"): self.code
            },
            bstack1l11ll_opy_ (u"ࠧࡴࡥࡲࡴࡪࡹࠧᒉ"): self.scope,
            bstack1l11ll_opy_ (u"ࠨࡶࡤ࡫ࡸ࠭ᒊ"): self.tags,
            bstack1l11ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬᒋ"): self.framework,
            bstack1l11ll_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᒌ"): self.bstack111ll11_opy_
        }
    def bstack111l1l1l1l_opy_(self):
        return {
         bstack1l11ll_opy_ (u"ࠫࡲ࡫ࡴࡢࠩᒍ"): self.meta
        }
    def bstack111l1l1111_opy_(self):
        return {
            bstack1l11ll_opy_ (u"ࠬࡩࡵࡴࡶࡲࡱࡗ࡫ࡲࡶࡰࡓࡥࡷࡧ࡭ࠨᒎ"): {
                bstack1l11ll_opy_ (u"࠭ࡲࡦࡴࡸࡲࡤࡴࡡ࡮ࡧࠪᒏ"): self.bstack111l1l1ll1_opy_
            }
        }
    def bstack111l11ll11_opy_(self, bstack111l1l1l11_opy_, details):
        step = next(filter(lambda st: st[bstack1l11ll_opy_ (u"ࠧࡪࡦࠪᒐ")] == bstack111l1l1l11_opy_, self.meta[bstack1l11ll_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧᒑ")]), None)
        step.update(details)
    def bstack111l11l11l_opy_(self, bstack111l1l1l11_opy_):
        step = next(filter(lambda st: st[bstack1l11ll_opy_ (u"ࠩ࡬ࡨࠬᒒ")] == bstack111l1l1l11_opy_, self.meta[bstack1l11ll_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᒓ")]), None)
        step.update({
            bstack1l11ll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᒔ"): current_time()
        })
    def bstack1l1l1ll_opy_(self, bstack111l1l1l11_opy_, result, duration=None):
        bstack111l11l1l1_opy_ = current_time()
        if bstack111l1l1l11_opy_ is not None and self.meta.get(bstack1l11ll_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫᒕ")):
            step = next(filter(lambda st: st[bstack1l11ll_opy_ (u"࠭ࡩࡥࠩᒖ")] == bstack111l1l1l11_opy_, self.meta[bstack1l11ll_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᒗ")]), None)
            step.update({
                bstack1l11ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᒘ"): bstack111l11l1l1_opy_,
                bstack1l11ll_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫᒙ"): duration if duration else bstack11l11111l1_opy_(step[bstack1l11ll_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᒚ")], bstack111l11l1l1_opy_),
                bstack1l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᒛ"): result.result,
                bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ᒜ"): str(result.exception) if result.exception else None
            })
    def add_step(self, bstack111l1l11l1_opy_):
        if self.meta.get(bstack1l11ll_opy_ (u"࠭ࡳࡵࡧࡳࡷࠬᒝ")):
            self.meta[bstack1l11ll_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ᒞ")].append(bstack111l1l11l1_opy_)
        else:
            self.meta[bstack1l11ll_opy_ (u"ࠨࡵࡷࡩࡵࡹࠧᒟ")] = [ bstack111l1l11l1_opy_ ]
    def bstack111l1l1lll_opy_(self):
        return {
            bstack1l11ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᒠ"): self.bstack1llll11_opy_(),
            **self.bstack111l1l11ll_opy_(),
            **self.bstack111l1l111l_opy_(),
            **self.bstack111l1l1l1l_opy_()
        }
    def bstack111l1ll11l_opy_(self):
        if not self.result:
            return {}
        data = {
            bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᒡ"): self.bstack111l11l1l1_opy_,
            bstack1l11ll_opy_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳࡥࡩ࡯ࡡࡰࡷࠬᒢ"): self.duration,
            bstack1l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᒣ"): self.result.result
        }
        if data[bstack1l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᒤ")] == bstack1l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧᒥ"):
            data[bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࡡࡷࡽࡵ࡫ࠧᒦ")] = self.result.bstack1l111lll1l_opy_()
            data[bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪᒧ")] = [{bstack1l11ll_opy_ (u"ࠪࡦࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ᒨ"): self.result.bstack11l11ll1ll_opy_()}]
        return data
    def bstack111l1ll111_opy_(self):
        return {
            bstack1l11ll_opy_ (u"ࠫࡺࡻࡩࡥࠩᒩ"): self.bstack1llll11_opy_(),
            **self.bstack111l1l11ll_opy_(),
            **self.bstack111l1l111l_opy_(),
            **self.bstack111l1ll11l_opy_(),
            **self.bstack111l1l1l1l_opy_()
        }
    def bstack1l111l1_opy_(self, event, result=None):
        if result:
            self.result = result
        if bstack1l11ll_opy_ (u"࡙ࠬࡴࡢࡴࡷࡩࡩ࠭ᒪ") in event:
            return self.bstack111l1l1lll_opy_()
        elif bstack1l11ll_opy_ (u"࠭ࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨᒫ") in event:
            return self.bstack111l1ll111_opy_()
    def bstack1ll11ll_opy_(self):
        pass
    def stop(self, time=None, duration=None, result=None):
        self.bstack111l11l1l1_opy_ = time if time else current_time()
        self.duration = duration if duration else bstack11l11111l1_opy_(self.bstack111ll11_opy_, self.bstack111l11l1l1_opy_)
        if result:
            self.result = result
class bstack1l1ll1l_opy_(bstack1ll1lll_opy_):
    def __init__(self, hooks=[], bstack11l1ll1_opy_={}, *args, **kwargs):
        self.hooks = hooks
        self.bstack11l1ll1_opy_ = bstack11l1ll1_opy_
        super().__init__(*args, **kwargs, bstack111l11ll_opy_=bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࠬᒬ"))
    @classmethod
    def bstack111l111lll_opy_(cls, scenario, feature, test, **kwargs):
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack1l11ll_opy_ (u"ࠨ࡫ࡧࠫᒭ"): id(step),
                bstack1l11ll_opy_ (u"ࠩࡷࡩࡽࡺࠧᒮ"): step.name,
                bstack1l11ll_opy_ (u"ࠪ࡯ࡪࡿࡷࡰࡴࡧࠫᒯ"): step.keyword,
            })
        return bstack1l1ll1l_opy_(
            **kwargs,
            meta={
                bstack1l11ll_opy_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࠬᒰ"): {
                    bstack1l11ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᒱ"): feature.name,
                    bstack1l11ll_opy_ (u"࠭ࡰࡢࡶ࡫ࠫᒲ"): feature.filename,
                    bstack1l11ll_opy_ (u"ࠧࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠬᒳ"): feature.description
                },
                bstack1l11ll_opy_ (u"ࠨࡵࡦࡩࡳࡧࡲࡪࡱࠪᒴ"): {
                    bstack1l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧᒵ"): scenario.name
                },
                bstack1l11ll_opy_ (u"ࠪࡷࡹ࡫ࡰࡴࠩᒶ"): steps,
                bstack1l11ll_opy_ (u"ࠫࡪࡾࡡ࡮ࡲ࡯ࡩࡸ࠭ᒷ"): bstack11l1lllll1_opy_(test)
            }
        )
    def bstack111l11ll1l_opy_(self):
        return {
            bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᒸ"): self.hooks
        }
    def bstack111l11l111_opy_(self):
        if self.bstack11l1ll1_opy_:
            return {
                bstack1l11ll_opy_ (u"࠭ࡩ࡯ࡶࡨ࡫ࡷࡧࡴࡪࡱࡱࡷࠬᒹ"): self.bstack11l1ll1_opy_
            }
        return {}
    def bstack111l1ll111_opy_(self):
        return {
            **super().bstack111l1ll111_opy_(),
            **self.bstack111l11ll1l_opy_()
        }
    def bstack111l1l1lll_opy_(self):
        return {
            **super().bstack111l1l1lll_opy_(),
            **self.bstack111l11l111_opy_()
        }
    def bstack1ll11ll_opy_(self):
        return bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࠩᒺ")
class bstack1l11lll_opy_(bstack1ll1lll_opy_):
    def __init__(self, hook_type, *args, **kwargs):
        self.hook_type = hook_type
        super().__init__(*args, **kwargs, bstack111l11ll_opy_=bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰ࠭ᒻ"))
    def bstack1l1ll11_opy_(self):
        return self.hook_type
    def bstack111l11l1ll_opy_(self):
        return {
            bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᒼ"): self.hook_type
        }
    def bstack111l1ll111_opy_(self):
        return {
            **super().bstack111l1ll111_opy_(),
            **self.bstack111l11l1ll_opy_()
        }
    def bstack111l1l1lll_opy_(self):
        return {
            **super().bstack111l1l1lll_opy_(),
            **self.bstack111l11l1ll_opy_()
        }
    def bstack1ll11ll_opy_(self):
        return bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࠬᒽ")
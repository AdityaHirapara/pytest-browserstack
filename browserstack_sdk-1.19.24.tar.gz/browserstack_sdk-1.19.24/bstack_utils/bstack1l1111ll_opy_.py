# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
class bstack11lll1l1l_opy_:
    def __init__(self, handler):
        self._11lll1l1ll_opy_ = None
        self.handler = handler
        self._11lll1ll11_opy_ = self.bstack11lll1l1l1_opy_()
        self.patch()
    def patch(self):
        self._11lll1l1ll_opy_ = self._11lll1ll11_opy_.execute
        self._11lll1ll11_opy_.execute = self.bstack11lll1l11l_opy_()
    def bstack11lll1l11l_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            self.handler(bstack1l11ll_opy_ (u"ࠤࡥࡩ࡫ࡵࡲࡦࠤᅊ"), driver_command, None, this, args)
            response = self._11lll1l1ll_opy_(this, driver_command, *args, **kwargs)
            self.handler(bstack1l11ll_opy_ (u"ࠥࡥ࡫ࡺࡥࡳࠤᅋ"), driver_command, response)
            return response
        return execute
    def reset(self):
        self._11lll1ll11_opy_.execute = self._11lll1l1ll_opy_
    @staticmethod
    def bstack11lll1l1l1_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver
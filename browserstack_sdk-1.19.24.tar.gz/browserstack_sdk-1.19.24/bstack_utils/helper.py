# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import datetime
import json
import os
import platform
import re
import subprocess
import traceback
import tempfile
import multiprocessing
import threading
from urllib.parse import urlparse
import git
import requests
from packaging import version
from bstack_utils.config import Config
from bstack_utils.constants import bstack11lll1lll1_opy_, bstack11llll11_opy_, bstack1lll1l1l1_opy_, bstack1l11ll11ll_opy_
from bstack_utils.messages import bstack1lll1lll1_opy_, bstack1l1111l1_opy_
from bstack_utils.proxy import bstack1111l1111_opy_, bstack11ll1ll1_opy_
bstack1llll1ll_opy_ = Config.get_instance()
def bstack11ll1ll1l1_opy_(config):
    return config[bstack1l11ll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪቯ")]
def bstack11lll11lll_opy_(config):
    return config[bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬተ")]
def bstack11ll1lll_opy_():
    try:
        import playwright
        return True
    except ImportError:
        return False
def bstack11l1111l1l_opy_(obj):
    values = []
    bstack111llll1ll_opy_ = re.compile(bstack1l11ll_opy_ (u"ࡵࠦࡣࡉࡕࡔࡖࡒࡑࡤ࡚ࡁࡈࡡ࡟ࡨ࠰ࠪࠢቱ"), re.I)
    for key in obj.keys():
        if bstack111llll1ll_opy_.match(key):
            values.append(obj[key])
    return values
def bstack11ll11ll1l_opy_(config):
    tags = []
    tags.extend(bstack11l1111l1l_opy_(os.environ))
    tags.extend(bstack11l1111l1l_opy_(config))
    return tags
def bstack111lll1ll1_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack11l111l1ll_opy_(bstack111llll111_opy_):
    if not bstack111llll111_opy_:
        return bstack1l11ll_opy_ (u"ࠫࠬቲ")
    return bstack1l11ll_opy_ (u"ࠧࢁࡽࠡࠪࡾࢁ࠮ࠨታ").format(bstack111llll111_opy_.name, bstack111llll111_opy_.email)
def bstack11ll1l11l1_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack111lll1l11_opy_ = repo.common_dir
        info = {
            bstack1l11ll_opy_ (u"ࠨࡳࡩࡣࠥቴ"): repo.head.commit.hexsha,
            bstack1l11ll_opy_ (u"ࠢࡴࡪࡲࡶࡹࡥࡳࡩࡣࠥት"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack1l11ll_opy_ (u"ࠣࡤࡵࡥࡳࡩࡨࠣቶ"): repo.active_branch.name,
            bstack1l11ll_opy_ (u"ࠤࡷࡥ࡬ࠨቷ"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack1l11ll_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡷࡩࡷࠨቸ"): bstack11l111l1ll_opy_(repo.head.commit.committer),
            bstack1l11ll_opy_ (u"ࠦࡨࡵ࡭࡮࡫ࡷࡸࡪࡸ࡟ࡥࡣࡷࡩࠧቹ"): repo.head.commit.committed_datetime.isoformat(),
            bstack1l11ll_opy_ (u"ࠧࡧࡵࡵࡪࡲࡶࠧቺ"): bstack11l111l1ll_opy_(repo.head.commit.author),
            bstack1l11ll_opy_ (u"ࠨࡡࡶࡶ࡫ࡳࡷࡥࡤࡢࡶࡨࠦቻ"): repo.head.commit.authored_datetime.isoformat(),
            bstack1l11ll_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺ࡟࡮ࡧࡶࡷࡦ࡭ࡥࠣቼ"): repo.head.commit.message,
            bstack1l11ll_opy_ (u"ࠣࡴࡲࡳࡹࠨች"): repo.git.rev_parse(bstack1l11ll_opy_ (u"ࠤ࠰࠱ࡸ࡮࡯ࡸ࠯ࡷࡳࡵࡲࡥࡷࡧ࡯ࠦቾ")),
            bstack1l11ll_opy_ (u"ࠥࡧࡴࡳ࡭ࡰࡰࡢ࡫࡮ࡺ࡟ࡥ࡫ࡵࠦቿ"): bstack111lll1l11_opy_,
            bstack1l11ll_opy_ (u"ࠦࡼࡵࡲ࡬ࡶࡵࡩࡪࡥࡧࡪࡶࡢࡨ࡮ࡸࠢኀ"): subprocess.check_output([bstack1l11ll_opy_ (u"ࠧ࡭ࡩࡵࠤኁ"), bstack1l11ll_opy_ (u"ࠨࡲࡦࡸ࠰ࡴࡦࡸࡳࡦࠤኂ"), bstack1l11ll_opy_ (u"ࠢ࠮࠯ࡪ࡭ࡹ࠳ࡣࡰ࡯ࡰࡳࡳ࠳ࡤࡪࡴࠥኃ")]).strip().decode(
                bstack1l11ll_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧኄ")),
            bstack1l11ll_opy_ (u"ࠤ࡯ࡥࡸࡺ࡟ࡵࡣࡪࠦኅ"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack1l11ll_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡶࡣࡸ࡯࡮ࡤࡧࡢࡰࡦࡹࡴࡠࡶࡤ࡫ࠧኆ"): repo.git.rev_list(
                bstack1l11ll_opy_ (u"ࠦࢀࢃ࠮࠯ࡽࢀࠦኇ").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack11l111l11l_opy_ = []
        for remote in remotes:
            bstack11l111ll11_opy_ = {
                bstack1l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥኈ"): remote.name,
                bstack1l11ll_opy_ (u"ࠨࡵࡳ࡮ࠥ኉"): remote.url,
            }
            bstack11l111l11l_opy_.append(bstack11l111ll11_opy_)
        return {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧኊ"): bstack1l11ll_opy_ (u"ࠣࡩ࡬ࡸࠧኋ"),
            **info,
            bstack1l11ll_opy_ (u"ࠤࡵࡩࡲࡵࡴࡦࡵࠥኌ"): bstack11l111l11l_opy_
        }
    except git.InvalidGitRepositoryError:
        return {}
    except Exception as err:
        print(bstack1l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡳࡵࡻ࡬ࡢࡶ࡬ࡲ࡬ࠦࡇࡪࡶࠣࡱࡪࡺࡡࡥࡣࡷࡥࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠣࡿࢂࠨኍ").format(err))
        return {}
def bstack1lll11111_opy_():
    env = os.environ
    if (bstack1l11ll_opy_ (u"ࠦࡏࡋࡎࡌࡋࡑࡗࡤ࡛ࡒࡍࠤ኎") in env and len(env[bstack1l11ll_opy_ (u"ࠧࡐࡅࡏࡍࡌࡒࡘࡥࡕࡓࡎࠥ኏")]) > 0) or (
            bstack1l11ll_opy_ (u"ࠨࡊࡆࡐࡎࡍࡓ࡙࡟ࡉࡑࡐࡉࠧነ") in env and len(env[bstack1l11ll_opy_ (u"ࠢࡋࡇࡑࡏࡎࡔࡓࡠࡊࡒࡑࡊࠨኑ")]) > 0):
        return {
            bstack1l11ll_opy_ (u"ࠣࡰࡤࡱࡪࠨኒ"): bstack1l11ll_opy_ (u"ࠤࡍࡩࡳࡱࡩ࡯ࡵࠥና"),
            bstack1l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨኔ"): env.get(bstack1l11ll_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢን")),
            bstack1l11ll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢኖ"): env.get(bstack1l11ll_opy_ (u"ࠨࡊࡐࡄࡢࡒࡆࡓࡅࠣኗ")),
            bstack1l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨኘ"): env.get(bstack1l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢኙ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠤࡆࡍࠧኚ")) == bstack1l11ll_opy_ (u"ࠥࡸࡷࡻࡥࠣኛ") and is_true(env.get(bstack1l11ll_opy_ (u"ࠦࡈࡏࡒࡄࡎࡈࡇࡎࠨኜ"))):
        return {
            bstack1l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥኝ"): bstack1l11ll_opy_ (u"ࠨࡃࡪࡴࡦࡰࡪࡉࡉࠣኞ"),
            bstack1l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥኟ"): env.get(bstack1l11ll_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡠࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦአ")),
            bstack1l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦኡ"): env.get(bstack1l11ll_opy_ (u"ࠥࡇࡎࡘࡃࡍࡇࡢࡎࡔࡈࠢኢ")),
            bstack1l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥኣ"): env.get(bstack1l11ll_opy_ (u"ࠧࡉࡉࡓࡅࡏࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࠣኤ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠨࡃࡊࠤእ")) == bstack1l11ll_opy_ (u"ࠢࡵࡴࡸࡩࠧኦ") and is_true(env.get(bstack1l11ll_opy_ (u"ࠣࡖࡕࡅ࡛ࡏࡓࠣኧ"))):
        return {
            bstack1l11ll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢከ"): bstack1l11ll_opy_ (u"ࠥࡘࡷࡧࡶࡪࡵࠣࡇࡎࠨኩ"),
            bstack1l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢኪ"): env.get(bstack1l11ll_opy_ (u"࡚ࠧࡒࡂࡘࡌࡗࡤࡈࡕࡊࡎࡇࡣ࡜ࡋࡂࡠࡗࡕࡐࠧካ")),
            bstack1l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣኬ"): env.get(bstack1l11ll_opy_ (u"ࠢࡕࡔࡄ࡚ࡎ࡙࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤክ")),
            bstack1l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢኮ"): env.get(bstack1l11ll_opy_ (u"ࠤࡗࡖࡆ࡜ࡉࡔࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣኯ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠥࡇࡎࠨኰ")) == bstack1l11ll_opy_ (u"ࠦࡹࡸࡵࡦࠤ኱") and env.get(bstack1l11ll_opy_ (u"ࠧࡉࡉࡠࡐࡄࡑࡊࠨኲ")) == bstack1l11ll_opy_ (u"ࠨࡣࡰࡦࡨࡷ࡭࡯ࡰࠣኳ"):
        return {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧኴ"): bstack1l11ll_opy_ (u"ࠣࡅࡲࡨࡪࡹࡨࡪࡲࠥኵ"),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧ኶"): None,
            bstack1l11ll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧ኷"): None,
            bstack1l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥኸ"): None
        }
    if env.get(bstack1l11ll_opy_ (u"ࠧࡈࡉࡕࡄࡘࡇࡐࡋࡔࡠࡄࡕࡅࡓࡉࡈࠣኹ")) and env.get(bstack1l11ll_opy_ (u"ࠨࡂࡊࡖࡅ࡙ࡈࡑࡅࡕࡡࡆࡓࡒࡓࡉࡕࠤኺ")):
        return {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧኻ"): bstack1l11ll_opy_ (u"ࠣࡄ࡬ࡸࡧࡻࡣ࡬ࡧࡷࠦኼ"),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧኽ"): env.get(bstack1l11ll_opy_ (u"ࠥࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡇࡊࡖࡢࡌ࡙࡚ࡐࡠࡑࡕࡍࡌࡏࡎࠣኾ")),
            bstack1l11ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨ኿"): None,
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦዀ"): env.get(bstack1l11ll_opy_ (u"ࠨࡂࡊࡖࡅ࡙ࡈࡑࡅࡕࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣ዁"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠢࡄࡋࠥዂ")) == bstack1l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨዃ") and is_true(env.get(bstack1l11ll_opy_ (u"ࠤࡇࡖࡔࡔࡅࠣዄ"))):
        return {
            bstack1l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣዅ"): bstack1l11ll_opy_ (u"ࠦࡉࡸ࡯࡯ࡧࠥ዆"),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ዇"): env.get(bstack1l11ll_opy_ (u"ࠨࡄࡓࡑࡑࡉࡤࡈࡕࡊࡎࡇࡣࡑࡏࡎࡌࠤወ")),
            bstack1l11ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤዉ"): None,
            bstack1l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢዊ"): env.get(bstack1l11ll_opy_ (u"ࠤࡇࡖࡔࡔࡅࡠࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢዋ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠥࡇࡎࠨዌ")) == bstack1l11ll_opy_ (u"ࠦࡹࡸࡵࡦࠤው") and is_true(env.get(bstack1l11ll_opy_ (u"࡙ࠧࡅࡎࡃࡓࡌࡔࡘࡅࠣዎ"))):
        return {
            bstack1l11ll_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦዏ"): bstack1l11ll_opy_ (u"ࠢࡔࡧࡰࡥࡵ࡮࡯ࡳࡧࠥዐ"),
            bstack1l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦዑ"): env.get(bstack1l11ll_opy_ (u"ࠤࡖࡉࡒࡇࡐࡉࡑࡕࡉࡤࡕࡒࡈࡃࡑࡍ࡟ࡇࡔࡊࡑࡑࡣ࡚ࡘࡌࠣዒ")),
            bstack1l11ll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧዓ"): env.get(bstack1l11ll_opy_ (u"ࠦࡘࡋࡍࡂࡒࡋࡓࡗࡋ࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤዔ")),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦዕ"): env.get(bstack1l11ll_opy_ (u"ࠨࡓࡆࡏࡄࡔࡍࡕࡒࡆࡡࡍࡓࡇࡥࡉࡅࠤዖ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠢࡄࡋࠥ዗")) == bstack1l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨዘ") and is_true(env.get(bstack1l11ll_opy_ (u"ࠤࡊࡍ࡙ࡒࡁࡃࡡࡆࡍࠧዙ"))):
        return {
            bstack1l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣዚ"): bstack1l11ll_opy_ (u"ࠦࡌ࡯ࡴࡍࡣࡥࠦዛ"),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣዜ"): env.get(bstack1l11ll_opy_ (u"ࠨࡃࡊࡡࡍࡓࡇࡥࡕࡓࡎࠥዝ")),
            bstack1l11ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤዞ"): env.get(bstack1l11ll_opy_ (u"ࠣࡅࡌࡣࡏࡕࡂࡠࡐࡄࡑࡊࠨዟ")),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣዠ"): env.get(bstack1l11ll_opy_ (u"ࠥࡇࡎࡥࡊࡐࡄࡢࡍࡉࠨዡ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠦࡈࡏࠢዢ")) == bstack1l11ll_opy_ (u"ࠧࡺࡲࡶࡧࠥዣ") and is_true(env.get(bstack1l11ll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࠤዤ"))):
        return {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧዥ"): bstack1l11ll_opy_ (u"ࠣࡄࡸ࡭ࡱࡪ࡫ࡪࡶࡨࠦዦ"),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧዧ"): env.get(bstack1l11ll_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤየ")),
            bstack1l11ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨዩ"): env.get(bstack1l11ll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡏࡎ࡚ࡅࡠࡎࡄࡆࡊࡒࠢዪ")) or env.get(bstack1l11ll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࡡࡓࡍࡕࡋࡌࡊࡐࡈࡣࡓࡇࡍࡆࠤያ")),
            bstack1l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨዬ"): env.get(bstack1l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥይ"))
        }
    if is_true(env.get(bstack1l11ll_opy_ (u"ࠤࡗࡊࡤࡈࡕࡊࡎࡇࠦዮ"))):
        return {
            bstack1l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣዯ"): bstack1l11ll_opy_ (u"࡛ࠦ࡯ࡳࡶࡣ࡯ࠤࡘࡺࡵࡥ࡫ࡲࠤ࡙࡫ࡡ࡮ࠢࡖࡩࡷࡼࡩࡤࡧࡶࠦደ"),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣዱ"): bstack1l11ll_opy_ (u"ࠨࡻࡾࡽࢀࠦዲ").format(env.get(bstack1l11ll_opy_ (u"ࠧࡔ࡛ࡖࡘࡊࡓ࡟ࡕࡇࡄࡑࡋࡕࡕࡏࡆࡄࡘࡎࡕࡎࡔࡇࡕ࡚ࡊࡘࡕࡓࡋࠪዳ")), env.get(bstack1l11ll_opy_ (u"ࠨࡕ࡜ࡗ࡙ࡋࡍࡠࡖࡈࡅࡒࡖࡒࡐࡌࡈࡇ࡙ࡏࡄࠨዴ"))),
            bstack1l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦድ"): env.get(bstack1l11ll_opy_ (u"ࠥࡗ࡞࡙ࡔࡆࡏࡢࡈࡊࡌࡉࡏࡋࡗࡍࡔࡔࡉࡅࠤዶ")),
            bstack1l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥዷ"): env.get(bstack1l11ll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡌࡈࠧዸ"))
        }
    if is_true(env.get(bstack1l11ll_opy_ (u"ࠨࡁࡑࡒ࡙ࡉ࡞ࡕࡒࠣዹ"))):
        return {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧዺ"): bstack1l11ll_opy_ (u"ࠣࡃࡳࡴࡻ࡫ࡹࡰࡴࠥዻ"),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧዼ"): bstack1l11ll_opy_ (u"ࠥࡿࢂ࠵ࡰࡳࡱ࡭ࡩࡨࡺ࠯ࡼࡿ࠲ࡿࢂ࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾࠤዽ").format(env.get(bstack1l11ll_opy_ (u"ࠫࡆࡖࡐࡗࡇ࡜ࡓࡗࡥࡕࡓࡎࠪዾ")), env.get(bstack1l11ll_opy_ (u"ࠬࡇࡐࡑࡘࡈ࡝ࡔࡘ࡟ࡂࡅࡆࡓ࡚ࡔࡔࡠࡐࡄࡑࡊ࠭ዿ")), env.get(bstack1l11ll_opy_ (u"࠭ࡁࡑࡒ࡙ࡉ࡞ࡕࡒࡠࡒࡕࡓࡏࡋࡃࡕࡡࡖࡐ࡚ࡍࠧጀ")), env.get(bstack1l11ll_opy_ (u"ࠧࡂࡒࡓ࡚ࡊ࡟ࡏࡓࡡࡅ࡙ࡎࡒࡄࡠࡋࡇࠫጁ"))),
            bstack1l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥጂ"): env.get(bstack1l11ll_opy_ (u"ࠤࡄࡔࡕ࡜ࡅ࡚ࡑࡕࡣࡏࡕࡂࡠࡐࡄࡑࡊࠨጃ")),
            bstack1l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤጄ"): env.get(bstack1l11ll_opy_ (u"ࠦࡆࡖࡐࡗࡇ࡜ࡓࡗࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠧጅ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠧࡇ࡚ࡖࡔࡈࡣࡍ࡚ࡔࡑࡡࡘࡗࡊࡘ࡟ࡂࡉࡈࡒ࡙ࠨጆ")) and env.get(bstack1l11ll_opy_ (u"ࠨࡔࡇࡡࡅ࡙ࡎࡒࡄࠣጇ")):
        return {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧገ"): bstack1l11ll_opy_ (u"ࠣࡃࡽࡹࡷ࡫ࠠࡄࡋࠥጉ"),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧጊ"): bstack1l11ll_opy_ (u"ࠥࡿࢂࢁࡽ࠰ࡡࡥࡹ࡮ࡲࡤ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡥࡹ࡮ࡲࡤࡊࡦࡀࡿࢂࠨጋ").format(env.get(bstack1l11ll_opy_ (u"ࠫࡘ࡟ࡓࡕࡇࡐࡣ࡙ࡋࡁࡎࡈࡒ࡙ࡓࡊࡁࡕࡋࡒࡒࡘࡋࡒࡗࡇࡕ࡙ࡗࡏࠧጌ")), env.get(bstack1l11ll_opy_ (u"࡙࡙ࠬࡔࡖࡈࡑࡤ࡚ࡅࡂࡏࡓࡖࡔࡐࡅࡄࡖࠪግ")), env.get(bstack1l11ll_opy_ (u"࠭ࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡍࡉ࠭ጎ"))),
            bstack1l11ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤጏ"): env.get(bstack1l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡃࡗࡌࡐࡉࡏࡄࠣጐ")),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣ጑"): env.get(bstack1l11ll_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡡࡅ࡙ࡎࡒࡄࡊࡆࠥጒ"))
        }
    if any([env.get(bstack1l11ll_opy_ (u"ࠦࡈࡕࡄࡆࡄࡘࡍࡑࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠤጓ")), env.get(bstack1l11ll_opy_ (u"ࠧࡉࡏࡅࡇࡅ࡙ࡎࡒࡄࡠࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗࡔ࡛ࡒࡄࡇࡢ࡚ࡊࡘࡓࡊࡑࡑࠦጔ")), env.get(bstack1l11ll_opy_ (u"ࠨࡃࡐࡆࡈࡆ࡚ࡏࡌࡅࡡࡖࡓ࡚ࡘࡃࡆࡡ࡙ࡉࡗ࡙ࡉࡐࡐࠥጕ"))]):
        return {
            bstack1l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧ጖"): bstack1l11ll_opy_ (u"ࠣࡃ࡚ࡗࠥࡉ࡯ࡥࡧࡅࡹ࡮ࡲࡤࠣ጗"),
            bstack1l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧጘ"): env.get(bstack1l11ll_opy_ (u"ࠥࡇࡔࡊࡅࡃࡗࡌࡐࡉࡥࡐࡖࡄࡏࡍࡈࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤጙ")),
            bstack1l11ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨጚ"): env.get(bstack1l11ll_opy_ (u"ࠧࡉࡏࡅࡇࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠥጛ")),
            bstack1l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧጜ"): env.get(bstack1l11ll_opy_ (u"ࠢࡄࡑࡇࡉࡇ࡛ࡉࡍࡆࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠧጝ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠣࡤࡤࡱࡧࡵ࡯ࡠࡤࡸ࡭ࡱࡪࡎࡶ࡯ࡥࡩࡷࠨጞ")):
        return {
            bstack1l11ll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢጟ"): bstack1l11ll_opy_ (u"ࠥࡆࡦࡳࡢࡰࡱࠥጠ"),
            bstack1l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢጡ"): env.get(bstack1l11ll_opy_ (u"ࠧࡨࡡ࡮ࡤࡲࡳࡤࡨࡵࡪ࡮ࡧࡖࡪࡹࡵ࡭ࡶࡶ࡙ࡷࡲࠢጢ")),
            bstack1l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣጣ"): env.get(bstack1l11ll_opy_ (u"ࠢࡣࡣࡰࡦࡴࡵ࡟ࡴࡪࡲࡶࡹࡐ࡯ࡣࡐࡤࡱࡪࠨጤ")),
            bstack1l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢጥ"): env.get(bstack1l11ll_opy_ (u"ࠤࡥࡥࡲࡨ࡯ࡰࡡࡥࡹ࡮ࡲࡤࡏࡷࡰࡦࡪࡸࠢጦ"))
        }
    if env.get(bstack1l11ll_opy_ (u"࡛ࠥࡊࡘࡃࡌࡇࡕࠦጧ")) or env.get(bstack1l11ll_opy_ (u"ࠦ࡜ࡋࡒࡄࡍࡈࡖࡤࡓࡁࡊࡐࡢࡔࡎࡖࡅࡍࡋࡑࡉࡤ࡙ࡔࡂࡔࡗࡉࡉࠨጨ")):
        return {
            bstack1l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥጩ"): bstack1l11ll_opy_ (u"ࠨࡗࡦࡴࡦ࡯ࡪࡸࠢጪ"),
            bstack1l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥጫ"): env.get(bstack1l11ll_opy_ (u"࡙ࠣࡈࡖࡈࡑࡅࡓࡡࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠧጬ")),
            bstack1l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦጭ"): bstack1l11ll_opy_ (u"ࠥࡑࡦ࡯࡮ࠡࡒ࡬ࡴࡪࡲࡩ࡯ࡧࠥጮ") if env.get(bstack1l11ll_opy_ (u"ࠦ࡜ࡋࡒࡄࡍࡈࡖࡤࡓࡁࡊࡐࡢࡔࡎࡖࡅࡍࡋࡑࡉࡤ࡙ࡔࡂࡔࡗࡉࡉࠨጯ")) else None,
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦጰ"): env.get(bstack1l11ll_opy_ (u"ࠨࡗࡆࡔࡆࡏࡊࡘ࡟ࡈࡋࡗࡣࡈࡕࡍࡎࡋࡗࠦጱ"))
        }
    if any([env.get(bstack1l11ll_opy_ (u"ࠢࡈࡅࡓࡣࡕࡘࡏࡋࡇࡆࡘࠧጲ")), env.get(bstack1l11ll_opy_ (u"ࠣࡉࡆࡐࡔ࡛ࡄࡠࡒࡕࡓࡏࡋࡃࡕࠤጳ")), env.get(bstack1l11ll_opy_ (u"ࠤࡊࡓࡔࡍࡌࡆࡡࡆࡐࡔ࡛ࡄࡠࡒࡕࡓࡏࡋࡃࡕࠤጴ"))]):
        return {
            bstack1l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣጵ"): bstack1l11ll_opy_ (u"ࠦࡌࡵ࡯ࡨ࡮ࡨࠤࡈࡲ࡯ࡶࡦࠥጶ"),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣጷ"): None,
            bstack1l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣጸ"): env.get(bstack1l11ll_opy_ (u"ࠢࡑࡔࡒࡎࡊࡉࡔࡠࡋࡇࠦጹ")),
            bstack1l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢጺ"): env.get(bstack1l11ll_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡋࡇࠦጻ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠥࡗࡍࡏࡐࡑࡃࡅࡐࡊࠨጼ")):
        return {
            bstack1l11ll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤጽ"): bstack1l11ll_opy_ (u"࡙ࠧࡨࡪࡲࡳࡥࡧࡲࡥࠣጾ"),
            bstack1l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤጿ"): env.get(bstack1l11ll_opy_ (u"ࠢࡔࡊࡌࡔࡕࡇࡂࡍࡇࡢࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨፀ")),
            bstack1l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥፁ"): bstack1l11ll_opy_ (u"ࠤࡍࡳࡧࠦࠣࡼࡿࠥፂ").format(env.get(bstack1l11ll_opy_ (u"ࠪࡗࡍࡏࡐࡑࡃࡅࡐࡊࡥࡊࡐࡄࡢࡍࡉ࠭ፃ"))) if env.get(bstack1l11ll_opy_ (u"ࠦࡘࡎࡉࡑࡒࡄࡆࡑࡋ࡟ࡋࡑࡅࡣࡎࡊࠢፄ")) else None,
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦፅ"): env.get(bstack1l11ll_opy_ (u"ࠨࡓࡉࡋࡓࡔࡆࡈࡌࡆࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣፆ"))
        }
    if is_true(env.get(bstack1l11ll_opy_ (u"ࠢࡏࡇࡗࡐࡎࡌ࡙ࠣፇ"))):
        return {
            bstack1l11ll_opy_ (u"ࠣࡰࡤࡱࡪࠨፈ"): bstack1l11ll_opy_ (u"ࠤࡑࡩࡹࡲࡩࡧࡻࠥፉ"),
            bstack1l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨፊ"): env.get(bstack1l11ll_opy_ (u"ࠦࡉࡋࡐࡍࡑ࡜ࡣ࡚ࡘࡌࠣፋ")),
            bstack1l11ll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢፌ"): env.get(bstack1l11ll_opy_ (u"ࠨࡓࡊࡖࡈࡣࡓࡇࡍࡆࠤፍ")),
            bstack1l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨፎ"): env.get(bstack1l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡊࡆࠥፏ"))
        }
    if is_true(env.get(bstack1l11ll_opy_ (u"ࠤࡊࡍ࡙ࡎࡕࡃࡡࡄࡇ࡙ࡏࡏࡏࡕࠥፐ"))):
        return {
            bstack1l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣፑ"): bstack1l11ll_opy_ (u"ࠦࡌ࡯ࡴࡉࡷࡥࠤࡆࡩࡴࡪࡱࡱࡷࠧፒ"),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣፓ"): bstack1l11ll_opy_ (u"ࠨࡻࡾ࠱ࡾࢁ࠴ࡧࡣࡵ࡫ࡲࡲࡸ࠵ࡲࡶࡰࡶ࠳ࢀࢃࠢፔ").format(env.get(bstack1l11ll_opy_ (u"ࠧࡈࡋࡗࡌ࡚ࡈ࡟ࡔࡇࡕ࡚ࡊࡘ࡟ࡖࡔࡏࠫፕ")), env.get(bstack1l11ll_opy_ (u"ࠨࡉࡌࡘࡍ࡛ࡂࡠࡔࡈࡔࡔ࡙ࡉࡕࡑࡕ࡝ࠬፖ")), env.get(bstack1l11ll_opy_ (u"ࠩࡊࡍ࡙ࡎࡕࡃࡡࡕ࡙ࡓࡥࡉࡅࠩፗ"))),
            bstack1l11ll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧፘ"): env.get(bstack1l11ll_opy_ (u"ࠦࡌࡏࡔࡉࡗࡅࡣ࡜ࡕࡒࡌࡈࡏࡓ࡜ࠨፙ")),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦፚ"): env.get(bstack1l11ll_opy_ (u"ࠨࡇࡊࡖࡋ࡙ࡇࡥࡒࡖࡐࡢࡍࡉࠨ፛"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠢࡄࡋࠥ፜")) == bstack1l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨ፝") and env.get(bstack1l11ll_opy_ (u"ࠤ࡙ࡉࡗࡉࡅࡍࠤ፞")) == bstack1l11ll_opy_ (u"ࠥ࠵ࠧ፟"):
        return {
            bstack1l11ll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ፠"): bstack1l11ll_opy_ (u"ࠧ࡜ࡥࡳࡥࡨࡰࠧ፡"),
            bstack1l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ።"): bstack1l11ll_opy_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡼࡿࠥ፣").format(env.get(bstack1l11ll_opy_ (u"ࠨࡘࡈࡖࡈࡋࡌࡠࡗࡕࡐࠬ፤"))),
            bstack1l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦ፥"): None,
            bstack1l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤ፦"): None,
        }
    if env.get(bstack1l11ll_opy_ (u"࡙ࠦࡋࡁࡎࡅࡌࡘ࡞ࡥࡖࡆࡔࡖࡍࡔࡔࠢ፧")):
        return {
            bstack1l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥ፨"): bstack1l11ll_opy_ (u"ࠨࡔࡦࡣࡰࡧ࡮ࡺࡹࠣ፩"),
            bstack1l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥ፪"): None,
            bstack1l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥ፫"): env.get(bstack1l11ll_opy_ (u"ࠤࡗࡉࡆࡓࡃࡊࡖ࡜ࡣࡕࡘࡏࡋࡇࡆࡘࡤࡔࡁࡎࡇࠥ፬")),
            bstack1l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤ፭"): env.get(bstack1l11ll_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥ፮"))
        }
    if any([env.get(bstack1l11ll_opy_ (u"ࠧࡉࡏࡏࡅࡒ࡙ࡗ࡙ࡅࠣ፯")), env.get(bstack1l11ll_opy_ (u"ࠨࡃࡐࡐࡆࡓ࡚ࡘࡓࡆࡡࡘࡖࡑࠨ፰")), env.get(bstack1l11ll_opy_ (u"ࠢࡄࡑࡑࡇࡔ࡛ࡒࡔࡇࡢ࡙ࡘࡋࡒࡏࡃࡐࡉࠧ፱")), env.get(bstack1l11ll_opy_ (u"ࠣࡅࡒࡒࡈࡕࡕࡓࡕࡈࡣ࡙ࡋࡁࡎࠤ፲"))]):
        return {
            bstack1l11ll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢ፳"): bstack1l11ll_opy_ (u"ࠥࡇࡴࡴࡣࡰࡷࡵࡷࡪࠨ፴"),
            bstack1l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢ፵"): None,
            bstack1l11ll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢ፶"): env.get(bstack1l11ll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢ፷")) or None,
            bstack1l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨ፸"): env.get(bstack1l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡊࡆࠥ፹"), 0)
        }
    if env.get(bstack1l11ll_opy_ (u"ࠤࡊࡓࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢ፺")):
        return {
            bstack1l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣ፻"): bstack1l11ll_opy_ (u"ࠦࡌࡵࡃࡅࠤ፼"),
            bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ፽"): None,
            bstack1l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣ፾"): env.get(bstack1l11ll_opy_ (u"ࠢࡈࡑࡢࡎࡔࡈ࡟ࡏࡃࡐࡉࠧ፿")),
            bstack1l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᎀ"): env.get(bstack1l11ll_opy_ (u"ࠤࡊࡓࡤࡖࡉࡑࡇࡏࡍࡓࡋ࡟ࡄࡑࡘࡒ࡙ࡋࡒࠣᎁ"))
        }
    if env.get(bstack1l11ll_opy_ (u"ࠥࡇࡋࡥࡂࡖࡋࡏࡈࡤࡏࡄࠣᎂ")):
        return {
            bstack1l11ll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᎃ"): bstack1l11ll_opy_ (u"ࠧࡉ࡯ࡥࡧࡉࡶࡪࡹࡨࠣᎄ"),
            bstack1l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᎅ"): env.get(bstack1l11ll_opy_ (u"ࠢࡄࡈࡢࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨᎆ")),
            bstack1l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᎇ"): env.get(bstack1l11ll_opy_ (u"ࠤࡆࡊࡤࡖࡉࡑࡇࡏࡍࡓࡋ࡟ࡏࡃࡐࡉࠧᎈ")),
            bstack1l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᎉ"): env.get(bstack1l11ll_opy_ (u"ࠦࡈࡌ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠤᎊ"))
        }
    return {bstack1l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᎋ"): None}
def get_host_info():
    return {
        bstack1l11ll_opy_ (u"ࠨࡨࡰࡵࡷࡲࡦࡳࡥࠣᎌ"): platform.node(),
        bstack1l11ll_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠤᎍ"): platform.system(),
        bstack1l11ll_opy_ (u"ࠣࡶࡼࡴࡪࠨᎎ"): platform.machine(),
        bstack1l11ll_opy_ (u"ࠤࡹࡩࡷࡹࡩࡰࡰࠥᎏ"): platform.version(),
        bstack1l11ll_opy_ (u"ࠥࡥࡷࡩࡨࠣ᎐"): platform.architecture()[0]
    }
def bstack1l1lll1l1_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack11ll1lll11_opy_():
    if bstack1llll1ll_opy_.get_property(bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ᎑")):
        return bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ᎒")
    return bstack1l11ll_opy_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴ࡟ࡨࡴ࡬ࡨࠬ᎓")
def bstack11lll11l11_opy_(driver):
    info = {
        bstack1l11ll_opy_ (u"ࠧࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭᎔"): driver.capabilities,
        bstack1l11ll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡡ࡬ࡨࠬ᎕"): driver.session_id,
        bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪ᎖"): driver.capabilities.get(bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨ᎗"), None),
        bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭᎘"): driver.capabilities.get(bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭᎙"), None),
        bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠨ᎚"): driver.capabilities.get(bstack1l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪ࠭᎛"), None),
    }
    if bstack11ll1lll11_opy_() == bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ᎜"):
        info[bstack1l11ll_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࠪ᎝")] = bstack1l11ll_opy_ (u"ࠪࡥࡵࡶ࠭ࡢࡷࡷࡳࡲࡧࡴࡦࠩ᎞") if bstack11l1l1l11_opy_() else bstack1l11ll_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭᎟")
    return info
def bstack11l1l1l11_opy_():
    if bstack1llll1ll_opy_.get_property(bstack1l11ll_opy_ (u"ࠬࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠫᎠ")):
        return True
    if is_true(os.environ.get(bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧᎡ"), None)):
        return True
    return False
def bstack1l111ll11_opy_(bstack11l11111ll_opy_, url, data, config):
    headers = config.get(bstack1l11ll_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨᎢ"), None)
    proxies = bstack1111l1111_opy_(config, url)
    auth = config.get(bstack1l11ll_opy_ (u"ࠨࡣࡸࡸ࡭࠭Ꭳ"), None)
    response = requests.request(
            bstack11l11111ll_opy_,
            url=url,
            headers=headers,
            auth=auth,
            json=data,
            proxies=proxies
        )
    return response
def bstack1l11l11lll_opy_(bstack1l1l111l_opy_, size):
    bstack11ll111l1_opy_ = []
    while len(bstack1l1l111l_opy_) > size:
        bstack1l1ll1111l_opy_ = bstack1l1l111l_opy_[:size]
        bstack11ll111l1_opy_.append(bstack1l1ll1111l_opy_)
        bstack1l1l111l_opy_ = bstack1l1l111l_opy_[size:]
    bstack11ll111l1_opy_.append(bstack1l1l111l_opy_)
    return bstack11ll111l1_opy_
def bstack11ll11lll1_opy_(message, bstack111llll11l_opy_=False):
    os.write(1, bytes(message, bstack1l11ll_opy_ (u"ࠩࡸࡸ࡫࠳࠸ࠨᎤ")))
    os.write(1, bytes(bstack1l11ll_opy_ (u"ࠪࡠࡳ࠭Ꭵ"), bstack1l11ll_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᎦ")))
    if bstack111llll11l_opy_:
        with open(bstack1l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠲ࡵ࠱࠲ࡻ࠰ࠫᎧ") + os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡋࡅࡘࡎࡅࡅࡡࡌࡈࠬᎨ")] + bstack1l11ll_opy_ (u"ࠧ࠯࡮ࡲ࡫ࠬᎩ"), bstack1l11ll_opy_ (u"ࠨࡣࠪᎪ")) as f:
            f.write(message + bstack1l11ll_opy_ (u"ࠩ࡟ࡲࠬᎫ"))
def bstack111lllll11_opy_():
    return os.environ[bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡄ࡙࡙ࡕࡍࡂࡖࡌࡓࡓ࠭Ꭼ")].lower() == bstack1l11ll_opy_ (u"ࠫࡹࡸࡵࡦࠩᎭ")
def bstack1111ll1ll_opy_(bstack11ll1l1111_opy_):
    return bstack1l11ll_opy_ (u"ࠬࢁࡽ࠰ࡽࢀࠫᎮ").format(bstack11lll1lll1_opy_, bstack11ll1l1111_opy_)
def current_time():
    return datetime.datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"࡚࠭ࠨᎯ")
def bstack11l11111l1_opy_(start, finish):
    return (datetime.datetime.fromisoformat(finish.rstrip(bstack1l11ll_opy_ (u"࡛ࠧࠩᎰ"))) - datetime.datetime.fromisoformat(start.rstrip(bstack1l11ll_opy_ (u"ࠨ࡜ࠪᎱ")))).total_seconds() * 1000
def bstack11l111ll1l_opy_(timestamp):
    return datetime.datetime.utcfromtimestamp(timestamp).isoformat() + bstack1l11ll_opy_ (u"ࠩ࡝ࠫᎲ")
def bstack11l11l1ll1_opy_(bstack11l11l11ll_opy_):
    date_format = bstack1l11ll_opy_ (u"ࠪࠩ࡞ࠫ࡭ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗ࠳ࠫࡦࠨᎳ")
    bstack11l11lll11_opy_ = datetime.datetime.strptime(bstack11l11l11ll_opy_, date_format)
    return bstack11l11lll11_opy_.isoformat() + bstack1l11ll_opy_ (u"ࠫ࡟࠭Ꮄ")
def bstack11l11l11l1_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᎵ")
    else:
        return bstack1l11ll_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭Ꮆ")
def is_true(val):
    if val is None:
        return False
    return val.__str__().lower() == bstack1l11ll_opy_ (u"ࠧࡵࡴࡸࡩࠬᎷ")
def bstack11l111111l_opy_(val):
    return val.__str__().lower() == bstack1l11ll_opy_ (u"ࠨࡨࡤࡰࡸ࡫ࠧᎸ")
def bstack1lll1l1_opy_(bstack11l1111ll1_opy_=Exception, bstack11ll1l1_opy_=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack11l1111ll1_opy_ as e:
                print(bstack1l11ll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࡿࢂࠦ࠭࠿ࠢࡾࢁ࠿ࠦࡻࡾࠤᎹ").format(func.__name__, bstack11l1111ll1_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack11l11l111l_opy_(bstack11l11l1l1l_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack11l11l1l1l_opy_(cls, *args, **kwargs)
            except bstack11l1111ll1_opy_ as e:
                print(bstack1l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࢀࢃࠠ࠮ࡀࠣࡿࢂࡀࠠࡼࡿࠥᎺ").format(bstack11l11l1l1l_opy_.__name__, bstack11l1111ll1_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if bstack11ll1l1_opy_:
        return bstack11l11l111l_opy_
    else:
        return decorator
def bstack11l1l1111_opy_(bstack1ll11lll_opy_):
    if bstack1l11ll_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨᎻ") in bstack1ll11lll_opy_ and bstack11l111111l_opy_(bstack1ll11lll_opy_[bstack1l11ll_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠩᎼ")]):
        return False
    if bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨᎽ") in bstack1ll11lll_opy_ and bstack11l111111l_opy_(bstack1ll11lll_opy_[bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠩᎾ")]):
        return False
    return True
def bstack1l111l1l_opy_():
    try:
        from pytest_bdd import reporting
        return True
    except Exception as e:
        return False
def bstack1llllll11l_opy_(hub_url):
    if bstack1ll11lll11_opy_() <= version.parse(bstack1l11ll_opy_ (u"ࠨ࠵࠱࠵࠸࠴࠰ࠨᎿ")):
        if hub_url != bstack1l11ll_opy_ (u"ࠩࠪᏀ"):
            return bstack1l11ll_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࠦᏁ") + hub_url + bstack1l11ll_opy_ (u"ࠦ࠿࠾࠰࠰ࡹࡧ࠳࡭ࡻࡢࠣᏂ")
        return bstack1lll1l1l1_opy_
    if hub_url != bstack1l11ll_opy_ (u"ࠬ࠭Ꮓ"):
        return bstack1l11ll_opy_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࠣᏄ") + hub_url + bstack1l11ll_opy_ (u"ࠢ࠰ࡹࡧ࠳࡭ࡻࡢࠣᏅ")
    return bstack1l11ll11ll_opy_
def bstack11l11ll11l_opy_():
    return isinstance(os.getenv(bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑ࡛ࡗࡉࡘ࡚࡟ࡑࡎࡘࡋࡎࡔࠧᏆ")), str)
def bstack11ll1llll_opy_(url):
    return urlparse(url).hostname
def bstack1ll1llllll_opy_(hostname):
    for bstack11l1111ll_opy_ in bstack11llll11_opy_:
        regex = re.compile(bstack11l1111ll_opy_)
        if regex.match(hostname):
            return True
    return False
def bstack1l111l1l11_opy_(directory_name, file_name, logger):
    bstack1ll11ll11_opy_ = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠩࢁࠫᏇ")), directory_name)
    try:
        if not os.path.exists(bstack1ll11ll11_opy_):
            os.makedirs(bstack1ll11ll11_opy_)
        file_path = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠪࢂࠬᏈ")), directory_name, file_name)
        if not os.path.isfile(file_path):
            with open(file_path, bstack1l11ll_opy_ (u"ࠫࡼ࠭Ꮙ")):
                pass
            with open(file_path, bstack1l11ll_opy_ (u"ࠧࡽࠫࠣᏊ")) as outfile:
                json.dump({}, outfile)
        return file_path
    except Exception as e:
        logger.debug(bstack1lll1lll1_opy_.format(str(e)))
def bstack1l111l11ll_opy_(file_name, key, value, logger):
    file_path = bstack1l111l1l11_opy_(bstack1l11ll_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭Ꮛ"), file_name, logger)
    if file_path != None:
        if os.path.exists(file_path):
            bstack1l1l1ll1ll_opy_ = json.load(open(file_path, bstack1l11ll_opy_ (u"ࠧࡳࡤࠪᏌ")))
        else:
            bstack1l1l1ll1ll_opy_ = {}
        bstack1l1l1ll1ll_opy_[key] = value
        with open(file_path, bstack1l11ll_opy_ (u"ࠣࡹ࠮ࠦᏍ")) as outfile:
            json.dump(bstack1l1l1ll1ll_opy_, outfile)
def bstack1llllllll_opy_(file_name, logger):
    file_path = bstack1l111l1l11_opy_(bstack1l11ll_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩᏎ"), file_name, logger)
    bstack1l1l1ll1ll_opy_ = {}
    if file_path != None and os.path.exists(file_path):
        with open(file_path, bstack1l11ll_opy_ (u"ࠪࡶࠬᏏ")) as bstack1ll111111_opy_:
            bstack1l1l1ll1ll_opy_ = json.load(bstack1ll111111_opy_)
    return bstack1l1l1ll1ll_opy_
def bstack1llll1lll1_opy_(file_path, logger):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡤࡦ࡮ࡨࡸ࡮ࡴࡧࠡࡨ࡬ࡰࡪࡀࠠࠨᏐ") + file_path + bstack1l11ll_opy_ (u"ࠬࠦࠧᏑ") + str(e))
def bstack1ll11lll11_opy_():
    from selenium import webdriver
    return version.parse(webdriver.__version__)
class Notset:
    def __repr__(self):
        return bstack1l11ll_opy_ (u"ࠨ࠼ࡏࡑࡗࡗࡊ࡚࠾ࠣᏒ")
def bstack1l11ll1l11_opy_(config):
    if bstack1l11ll_opy_ (u"ࠧࡪࡵࡓࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠭Ꮣ") in config:
        del (config[bstack1l11ll_opy_ (u"ࠨ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠧᏔ")])
        return False
    if bstack1ll11lll11_opy_() < version.parse(bstack1l11ll_opy_ (u"ࠩ࠶࠲࠹࠴࠰ࠨᏕ")):
        return False
    if bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠪ࠸࠳࠷࠮࠶ࠩᏖ")):
        return True
    if bstack1l11ll_opy_ (u"ࠫࡺࡹࡥࡘ࠵ࡆࠫᏗ") in config and config[bstack1l11ll_opy_ (u"ࠬࡻࡳࡦ࡙࠶ࡇࠬᏘ")] is False:
        return False
    else:
        return True
def bstack111lllll1_opy_(args_list, bstack11l111l111_opy_):
    index = -1
    for value in bstack11l111l111_opy_:
        try:
            index = args_list.index(value)
            return index
        except Exception as e:
            return index
    return index
class Result:
    def __init__(self, result=None, duration=None, exception=None, bstack1l111ll_opy_=None):
        self.result = result
        self.duration = duration
        self.exception = exception
        self.exception_type = type(self.exception).__name__ if exception else None
        self.bstack1l111ll_opy_ = bstack1l111ll_opy_
    @classmethod
    def passed(cls):
        return Result(result=bstack1l11ll_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭Ꮩ"))
    @classmethod
    def failed(cls, exception=None):
        return Result(result=bstack1l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧᏚ"), exception=exception)
    def bstack1l111lll1l_opy_(self):
        if self.result != bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᏛ"):
            return None
        if bstack1l11ll_opy_ (u"ࠤࡄࡷࡸ࡫ࡲࡵ࡫ࡲࡲࠧᏜ") in self.exception_type:
            return bstack1l11ll_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࡋࡲࡳࡱࡵࠦᏝ")
        return bstack1l11ll_opy_ (u"࡚ࠦࡴࡨࡢࡰࡧࡰࡪࡪࡅࡳࡴࡲࡶࠧᏞ")
    def bstack11l11ll1ll_opy_(self):
        if self.result != bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᏟ"):
            return None
        if self.bstack1l111ll_opy_:
            return self.bstack1l111ll_opy_
        return bstack111llllll1_opy_(self.exception)
def bstack111llllll1_opy_(exc):
    return [traceback.format_exception(exc)]
def bstack111lllll1l_opy_(message):
    if isinstance(message, str):
        return not bool(message and message.strip())
    return True
def bstack1111111_opy_(object, key, default_value):
    if not object or not object.__dict__:
        return default_value
    if key in object.__dict__.keys():
        return object.__dict__.get(key)
    return default_value
def bstack1ll1lll11l_opy_(config, logger):
    try:
        import playwright
        bstack11l11lll1l_opy_ = playwright.__file__
        bstack111ll1ll1l_opy_ = os.path.split(bstack11l11lll1l_opy_)
        bstack11l111llll_opy_ = bstack111ll1ll1l_opy_[0] + bstack1l11ll_opy_ (u"࠭࠯ࡥࡴ࡬ࡺࡪࡸ࠯ࡱࡣࡦ࡯ࡦ࡭ࡥ࠰࡮࡬ࡦ࠴ࡩ࡬ࡪ࠱ࡦࡰ࡮࠴ࡪࡴࠩᏠ")
        os.environ[bstack1l11ll_opy_ (u"ࠧࡈࡎࡒࡆࡆࡒ࡟ࡂࡉࡈࡒ࡙ࡥࡈࡕࡖࡓࡣࡕࡘࡏ࡙࡛ࠪᏡ")] = bstack11ll1ll1_opy_(config)
        with open(bstack11l111llll_opy_, bstack1l11ll_opy_ (u"ࠨࡴࠪᏢ")) as f:
            bstack1lllll11ll_opy_ = f.read()
            bstack111lll11ll_opy_ = bstack1l11ll_opy_ (u"ࠩࡪࡰࡴࡨࡡ࡭࠯ࡤ࡫ࡪࡴࡴࠨᏣ")
            bstack111ll1llll_opy_ = bstack1lllll11ll_opy_.find(bstack111lll11ll_opy_)
            if bstack111ll1llll_opy_ == -1:
              process = subprocess.Popen(bstack1l11ll_opy_ (u"ࠥࡲࡵࡳࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡩ࡯ࡳࡧࡧ࡬࠮ࡣࡪࡩࡳࡺࠢᏤ"), shell=True, cwd=bstack111ll1ll1l_opy_[0])
              process.wait()
              bstack11l1111lll_opy_ = bstack1l11ll_opy_ (u"ࠫࠧࡻࡳࡦࠢࡶࡸࡷ࡯ࡣࡵࠤ࠾ࠫᏥ")
              bstack11l11l1111_opy_ = bstack1l11ll_opy_ (u"ࠧࠨࠢࠡ࡞ࠥࡹࡸ࡫ࠠࡴࡶࡵ࡭ࡨࡺ࡜ࠣ࠽ࠣࡧࡴࡴࡳࡵࠢࡾࠤࡧࡵ࡯ࡵࡵࡷࡶࡦࡶࠠࡾࠢࡀࠤࡷ࡫ࡱࡶ࡫ࡵࡩ࠭࠭ࡧ࡭ࡱࡥࡥࡱ࠳ࡡࡨࡧࡱࡸࠬ࠯࠻ࠡ࡫ࡩࠤ࠭ࡶࡲࡰࡥࡨࡷࡸ࠴ࡥ࡯ࡸ࠱ࡋࡑࡕࡂࡂࡎࡢࡅࡌࡋࡎࡕࡡࡋࡘ࡙ࡖ࡟ࡑࡔࡒ࡜࡞࠯ࠠࡣࡱࡲࡸࡸࡺࡲࡢࡲࠫ࠭ࡀࠦࠢࠣࠤᏦ")
              bstack111lll1111_opy_ = bstack1lllll11ll_opy_.replace(bstack11l1111lll_opy_, bstack11l11l1111_opy_)
              with open(bstack11l111llll_opy_, bstack1l11ll_opy_ (u"࠭ࡷࠨᏧ")) as f:
                f.write(bstack111lll1111_opy_)
    except Exception as e:
        logger.error(bstack1l1111l1_opy_.format(str(e)))
def bstack1l1lllll1l_opy_():
  try:
    bstack11l111l1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"ࠧࡰࡲࡷ࡭ࡲࡧ࡬ࡠࡪࡸࡦࡤࡻࡲ࡭࠰࡭ࡷࡴࡴࠧᏨ"))
    bstack11l11l1l11_opy_ = []
    if os.path.exists(bstack11l111l1l1_opy_):
      with open(bstack11l111l1l1_opy_) as f:
        bstack11l11l1l11_opy_ = json.load(f)
      os.remove(bstack11l111l1l1_opy_)
    return bstack11l11l1l11_opy_
  except:
    pass
  return []
def bstack1lll1l1ll_opy_(bstack1lll111ll_opy_):
  try:
    bstack11l11l1l11_opy_ = []
    bstack11l111l1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"ࠨࡱࡳࡸ࡮ࡳࡡ࡭ࡡ࡫ࡹࡧࡥࡵࡳ࡮࠱࡮ࡸࡵ࡮ࠨᏩ"))
    if os.path.exists(bstack11l111l1l1_opy_):
      with open(bstack11l111l1l1_opy_) as f:
        bstack11l11l1l11_opy_ = json.load(f)
    bstack11l11l1l11_opy_.append(bstack1lll111ll_opy_)
    with open(bstack11l111l1l1_opy_, bstack1l11ll_opy_ (u"ࠩࡺࠫᏪ")) as f:
        json.dump(bstack11l11l1l11_opy_, f)
  except:
    pass
def bstack1l111111l_opy_(logger, bstack11l1111l11_opy_ = False):
  try:
    test_name = os.environ.get(bstack1l11ll_opy_ (u"ࠪࡔ࡞࡚ࡅࡔࡖࡢࡘࡊ࡙ࡔࡠࡐࡄࡑࡊ࠭Ꮻ"), bstack1l11ll_opy_ (u"ࠫࠬᏬ"))
    if test_name == bstack1l11ll_opy_ (u"ࠬ࠭Ꮽ"):
        test_name = threading.current_thread().__dict__.get(bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹࡈࡤࡥࡡࡷࡩࡸࡺ࡟࡯ࡣࡰࡩࠬᏮ"), bstack1l11ll_opy_ (u"ࠧࠨᏯ"))
    bstack111lll1lll_opy_ = bstack1l11ll_opy_ (u"ࠨ࠮ࠣࠫᏰ").join(threading.current_thread().bstackTestErrorMessages)
    if bstack11l1111l11_opy_:
        bstack111l1llll_opy_ = os.environ.get(bstack1l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒࡏࡅ࡙ࡌࡏࡓࡏࡢࡍࡓࡊࡅ࡙ࠩᏱ"), bstack1l11ll_opy_ (u"ࠪ࠴ࠬᏲ"))
        bstack111lll11l_opy_ = {bstack1l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩᏳ"): test_name, bstack1l11ll_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫᏴ"): bstack111lll1lll_opy_, bstack1l11ll_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬᏵ"): bstack111l1llll_opy_}
        bstack111lll11l1_opy_ = []
        bstack11l11ll111_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺ࡟ࡱࡲࡳࡣࡪࡸࡲࡰࡴࡢࡰ࡮ࡹࡴ࠯࡬ࡶࡳࡳ࠭᏶"))
        if os.path.exists(bstack11l11ll111_opy_):
            with open(bstack11l11ll111_opy_) as f:
                bstack111lll11l1_opy_ = json.load(f)
        bstack111lll11l1_opy_.append(bstack111lll11l_opy_)
        with open(bstack11l11ll111_opy_, bstack1l11ll_opy_ (u"ࠨࡹࠪ᏷")) as f:
            json.dump(bstack111lll11l1_opy_, f)
    else:
        bstack111lll11l_opy_ = {bstack1l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧᏸ"): test_name, bstack1l11ll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩᏹ"): bstack111lll1lll_opy_, bstack1l11ll_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪᏺ"): str(multiprocessing.current_process().name)}
        if bstack1l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤ࡫ࡲࡳࡱࡵࡣࡱ࡯ࡳࡵࠩᏻ") not in multiprocessing.current_process().__dict__.keys():
            multiprocessing.current_process().bstack_error_list = []
        multiprocessing.current_process().bstack_error_list.append(bstack111lll11l_opy_)
  except Exception as e:
      logger.warn(bstack1l11ll_opy_ (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡶࡸࡴࡸࡥࠡࡲࡼࡸࡪࡹࡴࠡࡨࡸࡲࡳ࡫࡬ࠡࡦࡤࡸࡦࡀࠠࡼࡿࠥᏼ").format(e))
def bstack1lllll11l1_opy_(error_message, test_name, index, logger):
  try:
    bstack111lllllll_opy_ = []
    bstack111lll11l_opy_ = {bstack1l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᏽ"): test_name, bstack1l11ll_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧ᏾"): error_message, bstack1l11ll_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ᏿"): index}
    bstack11l11ll1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠴ࡪࡴࡱࡱࠫ᐀"))
    if os.path.exists(bstack11l11ll1l1_opy_):
        with open(bstack11l11ll1l1_opy_) as f:
            bstack111lllllll_opy_ = json.load(f)
    bstack111lllllll_opy_.append(bstack111lll11l_opy_)
    with open(bstack11l11ll1l1_opy_, bstack1l11ll_opy_ (u"ࠫࡼ࠭ᐁ")) as f:
        json.dump(bstack111lllllll_opy_, f)
  except Exception as e:
    logger.warn(bstack1l11ll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡵࡷࡳࡷ࡫ࠠࡳࡱࡥࡳࡹࠦࡦࡶࡰࡱࡩࡱࠦࡤࡢࡶࡤ࠾ࠥࢁࡽࠣᐂ").format(e))
def bstack1lllll1lll_opy_(bstack1l1llll1ll_opy_, name, logger):
  try:
    bstack111lll11l_opy_ = {bstack1l11ll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫᐃ"): name, bstack1l11ll_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ᐄ"): bstack1l1llll1ll_opy_, bstack1l11ll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧᐅ"): str(threading.current_thread()._name)}
    return bstack111lll11l_opy_
  except Exception as e:
    logger.warn(bstack1l11ll_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡹࡴࡰࡴࡨࠤࡧ࡫ࡨࡢࡸࡨࠤ࡫ࡻ࡮࡯ࡧ࡯ࠤࡩࡧࡴࡢ࠼ࠣࡿࢂࠨᐆ").format(e))
  return
def bstack11l11l1lll_opy_():
    return platform.system() == bstack1l11ll_opy_ (u"࡛ࠪ࡮ࡴࡤࡰࡹࡶࠫᐇ")
def bstack111l111l1_opy_(bstack111lll111l_opy_, config, logger):
    bstack11l111lll1_opy_ = {}
    try:
        return {key: config[key] for key in config if bstack111lll111l_opy_.match(key)}
    except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡧ࡫࡯ࡸࡪࡸࠠࡤࡱࡱࡪ࡮࡭ࠠ࡬ࡧࡼࡷࠥࡨࡹࠡࡴࡨ࡫ࡪࡾࠠ࡮ࡣࡷࡧ࡭ࡀࠠࡼࡿࠥᐈ").format(e))
    return bstack11l111lll1_opy_
def bstack1l1111l111_opy_(bstack11l1111111_opy_, bstack111lll1l1l_opy_):
    bstack111llll1l1_opy_ = version.parse(bstack11l1111111_opy_)
    bstack111ll1lll1_opy_ = version.parse(bstack111lll1l1l_opy_)
    if bstack111llll1l1_opy_ > bstack111ll1lll1_opy_:
        return 1
    elif bstack111llll1l1_opy_ < bstack111ll1lll1_opy_:
        return -1
    else:
        return 0
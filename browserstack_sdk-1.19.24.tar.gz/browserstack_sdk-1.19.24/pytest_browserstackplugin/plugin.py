# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import atexit
import datetime
import inspect
import logging
import os
import signal
import sys
import threading
from uuid import uuid4
from bstack_utils.percy_sdk import PercySDK
import tempfile
import pytest
from packaging import version
from browserstack_sdk.__init__ import (bstack111ll11l1_opy_, bstack111l111l_opy_, update, bstack1ll1ll111_opy_,
                                       bstack11l1l11l_opy_, bstack1l11l111l_opy_, bstack1l11ll11l_opy_, bstack11111l11l_opy_,
                                       bstack111l11111_opy_, bstack11lllllll_opy_, bstack1llllll1l1_opy_, bstack1llll11111_opy_,
                                       bstack11llll11l_opy_, getAccessibilityResults, getAccessibilityResultsSummary, perform_scan, bstack1lllllll1l_opy_)
from browserstack_sdk.bstack1lll111l_opy_ import bstack1lll1l1l_opy_
from browserstack_sdk._version import __version__
from bstack_utils import bstack1ll1l1111l_opy_
from bstack_utils.capture import bstack11l11l1_opy_
from bstack_utils.config import Config
from bstack_utils.constants import bstack1llll11l1_opy_, bstack1ll1l1l1l_opy_, bstack1lll1ll1l_opy_, \
    bstack1llll1ll1l_opy_
from bstack_utils.helper import bstack1111111_opy_, bstack1l1lll1l1_opy_, bstack111lllll11_opy_, current_time, \
    bstack11l11l11l1_opy_, \
    bstack111lll1ll1_opy_, bstack1ll11lll11_opy_, bstack1llllll11l_opy_, bstack11l11ll11l_opy_, bstack1l111l1l_opy_, Notset, \
    bstack1l11ll1l11_opy_, bstack11l11111l1_opy_, bstack111llllll1_opy_, Result, bstack11l111ll1l_opy_, bstack111lllll1l_opy_, bstack1lll1l1_opy_, \
    bstack1lll1l1ll_opy_, bstack1l111111l_opy_, is_true, bstack11l11l1lll_opy_
from bstack_utils.bstack1l11111lll_opy_ import bstack11llllll1l_opy_
from bstack_utils.messages import bstack1l1lllll11_opy_, bstack11ll1l111_opy_, bstack1l1l11l11_opy_, bstack11lll111_opy_, bstack1ll1l1ll_opy_, \
    bstack1l1111l1_opy_, bstack111ll111_opy_, bstack1ll11l1lll_opy_, bstack1ll11l1l1l_opy_, bstack111llll1l_opy_, \
    bstack1l1lll1ll1_opy_, bstack1l1llll1l1_opy_
from bstack_utils.proxy import bstack11ll1ll1_opy_, bstack1ll111ll11_opy_
from bstack_utils.bstack111ll111l_opy_ import bstack11l1lll1l1_opy_, bstack11l1llllll_opy_, bstack11ll111ll1_opy_, bstack11ll111l11_opy_, \
    bstack11ll111l1l_opy_, bstack11l1llll1l_opy_, bstack11ll111111_opy_, bstack1ll1lll1l1_opy_, bstack11ll1111ll_opy_
from bstack_utils.bstack1l1111ll_opy_ import bstack11lll1l1l_opy_
from bstack_utils.bstack1ll1llll11_opy_ import bstack1111l111_opy_, bstack1l11l1ll1_opy_, bstack1llll111l1_opy_, \
    bstack1l11lll1l_opy_, bstack1l1111l11_opy_
from bstack_utils.bstack1lll1ll_opy_ import bstack1l1ll1l_opy_
from bstack_utils.bstack11l1l11_opy_ import bstack111lll1_opy_
import bstack_utils.bstack1lll11l1_opy_ as bstack1lll1ll1_opy_
from bstack_utils.bstack1lll1ll1l1_opy_ import bstack1lll1ll1l1_opy_
bstack111111111_opy_ = None
bstack1111l11l_opy_ = None
bstack111111ll1_opy_ = None
bstack1l11ll1ll1_opy_ = None
bstack1l1l111l1l_opy_ = None
bstack11l11lll_opy_ = None
bstack1l11l11l1l_opy_ = None
bstack1llll111l_opy_ = None
bstack1l11l1l11l_opy_ = None
bstack1lll11ll11_opy_ = None
bstack1lll11l11l_opy_ = None
bstack1llll11lll_opy_ = None
bstack1lll11lll_opy_ = None
bstack1ll1l1l1ll_opy_ = bstack1l11ll_opy_ (u"ࠨࠩᗚ")
CONFIG = {}
bstack1llllll111_opy_ = False
bstack1ll1l1l1l1_opy_ = bstack1l11ll_opy_ (u"ࠩࠪᗛ")
bstack1llll11l11_opy_ = bstack1l11ll_opy_ (u"ࠪࠫᗜ")
bstack1llll1ll11_opy_ = False
bstack1l1111l1l_opy_ = []
bstack111l1lll_opy_ = bstack1llll11l1_opy_
bstack1lllllll111_opy_ = bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫᗝ")
bstack1lllll1ll11_opy_ = False
bstack1ll111lll_opy_ = {}
bstack1lll11l1l_opy_ = False
logger = bstack1ll1l1111l_opy_.get_logger(__name__, bstack111l1lll_opy_)
store = {
    bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡨࡰࡱ࡮ࡣࡺࡻࡩࡥࠩᗞ"): []
}
bstack1lllll11111_opy_ = False
try:
    from playwright.sync_api import (
        BrowserContext,
        Page
    )
except:
    pass
import json
_11lll11_opy_ = {}
current_test_uuid = None
def bstack1ll1111111_opy_(page, bstack1l1lll1111_opy_):
    try:
        page.evaluate(bstack1l11ll_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢᗟ"),
                      bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠫᗠ") + json.dumps(
                          bstack1l1lll1111_opy_) + bstack1l11ll_opy_ (u"ࠣࡿࢀࠦᗡ"))
    except Exception as e:
        print(bstack1l11ll_opy_ (u"ࠤࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠤࢀࢃࠢᗢ"), e)
def bstack11l111111_opy_(page, message, level):
    try:
        page.evaluate(bstack1l11ll_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦᗣ"), bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩᗤ") + json.dumps(
            message) + bstack1l11ll_opy_ (u"ࠬ࠲ࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠨᗥ") + json.dumps(level) + bstack1l11ll_opy_ (u"࠭ࡽࡾࠩᗦ"))
    except Exception as e:
        print(bstack1l11ll_opy_ (u"ࠢࡦࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠣࡥࡳࡴ࡯ࡵࡣࡷ࡭ࡴࡴࠠࡼࡿࠥᗧ"), e)
def pytest_configure(config):
    bstack1llll1ll_opy_ = Config.get_instance()
    config.args = bstack111lll1_opy_.bstack11ll1l1l11_opy_(config.args)
    bstack1llll1ll_opy_.bstack1l1llllll1_opy_(is_true(config.getoption(bstack1l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠬᗨ"))))
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    bstack1lllll1ll1l_opy_ = item.config.getoption(bstack1l11ll_opy_ (u"ࠩࡶ࡯࡮ࡶࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫᗩ"))
    plugins = item.config.getoption(bstack1l11ll_opy_ (u"ࠥࡴࡱࡻࡧࡪࡰࡶࠦᗪ"))
    report = outcome.get_result()
    bstack1llll1ll111_opy_(item, call, report)
    if bstack1l11ll_opy_ (u"ࠦࡵࡿࡴࡦࡵࡷࡣࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡳࡰࡺ࡭ࡩ࡯ࠤᗫ") not in plugins or bstack1l111l1l_opy_():
        return
    summary = []
    driver = getattr(item, bstack1l11ll_opy_ (u"ࠧࡥࡤࡳ࡫ࡹࡩࡷࠨᗬ"), None)
    page = getattr(item, bstack1l11ll_opy_ (u"ࠨ࡟ࡱࡣࡪࡩࠧᗭ"), None)
    try:
        if (driver == None):
            driver = threading.current_thread().bstackSessionDriver
    except:
        pass
    item._driver = driver
    if (driver is not None):
        bstack1llll1l1ll1_opy_(item, report, summary, bstack1lllll1ll1l_opy_)
    if (page is not None):
        bstack1lllll11l11_opy_(item, report, summary, bstack1lllll1ll1l_opy_)
def bstack1llll1l1ll1_opy_(item, report, summary, bstack1lllll1ll1l_opy_):
    if report.when == bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠭ᗮ") and report.skipped:
        bstack11ll1111ll_opy_(report)
    if report.when in [bstack1l11ll_opy_ (u"ࠣࡵࡨࡸࡺࡶࠢᗯ"), bstack1l11ll_opy_ (u"ࠤࡷࡩࡦࡸࡤࡰࡹࡱࠦᗰ")]:
        return
    if not bstack111lllll11_opy_():
        return
    try:
        if (str(bstack1lllll1ll1l_opy_).lower() != bstack1l11ll_opy_ (u"ࠪࡸࡷࡻࡥࠨᗱ")):
            item._driver.execute_script(
                bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡰࡤࡱࡪࠨ࠺ࠡࠩᗲ") + json.dumps(
                    report.nodeid) + bstack1l11ll_opy_ (u"ࠬࢃࡽࠨᗳ"))
        os.environ[bstack1l11ll_opy_ (u"࠭ࡐ࡚ࡖࡈࡗ࡙ࡥࡔࡆࡕࡗࡣࡓࡇࡍࡆࠩᗴ")] = report.nodeid
    except Exception as e:
        summary.append(
            bstack1l11ll_opy_ (u"ࠢࡘࡃࡕࡒࡎࡔࡇ࠻ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡳࡡࡳ࡭ࠣࡷࡪࡹࡳࡪࡱࡱࠤࡳࡧ࡭ࡦ࠼ࠣࡿ࠵ࢃࠢᗵ").format(e)
        )
    passed = report.passed or report.skipped or (report.failed and hasattr(report, bstack1l11ll_opy_ (u"ࠣࡹࡤࡷࡽ࡬ࡡࡪ࡮ࠥᗶ")))
    bstack1l1llll111_opy_ = bstack1l11ll_opy_ (u"ࠤࠥᗷ")
    bstack11ll1111ll_opy_(report)
    if not passed:
        try:
            bstack1l1llll111_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack1l11ll_opy_ (u"࡛ࠥࡆࡘࡎࡊࡐࡊ࠾ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤ࡫ࡧࡩ࡭ࡷࡵࡩࠥࡸࡥࡢࡵࡲࡲ࠿ࠦࡻ࠱ࡿࠥᗸ").format(e)
            )
        try:
            if (threading.current_thread().bstackTestErrorMessages == None):
                threading.current_thread().bstackTestErrorMessages = []
        except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
        threading.current_thread().bstackTestErrorMessages.append(str(bstack1l1llll111_opy_))
    if not report.skipped:
        passed = report.passed or (report.failed and hasattr(report, bstack1l11ll_opy_ (u"ࠦࡼࡧࡳࡹࡨࡤ࡭ࡱࠨᗹ")))
        bstack1l1llll111_opy_ = bstack1l11ll_opy_ (u"ࠧࠨᗺ")
        if not passed:
            try:
                bstack1l1llll111_opy_ = report.longrepr.reprcrash
            except Exception as e:
                summary.append(
                    bstack1l11ll_opy_ (u"ࠨࡗࡂࡔࡑࡍࡓࡍ࠺ࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩ࡫ࡴࡦࡴࡰ࡭ࡳ࡫ࠠࡧࡣ࡬ࡰࡺࡸࡥࠡࡴࡨࡥࡸࡵ࡮࠻ࠢࡾ࠴ࢂࠨᗻ").format(e)
                )
            try:
                if (threading.current_thread().bstackTestErrorMessages == None):
                    threading.current_thread().bstackTestErrorMessages = []
            except Exception as e:
                threading.current_thread().bstackTestErrorMessages = []
            threading.current_thread().bstackTestErrorMessages.append(str(bstack1l1llll111_opy_))
        try:
            if passed:
                item._driver.execute_script(
                    bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡤࡲࡳࡵࡴࡢࡶࡨࠦ࠱ࠦ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠢࠥ࡭ࡳ࡬࡯ࠣ࠮ࠣࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡨࡦࡺࡡࠣ࠼ࠣࠫᗼ")
                    + json.dumps(bstack1l11ll_opy_ (u"ࠣࡲࡤࡷࡸ࡫ࡤࠢࠤᗽ"))
                    + bstack1l11ll_opy_ (u"ࠤ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࢂࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࢁࠧᗾ")
                )
            else:
                item._driver.execute_script(
                    bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡥࡳࡴࡲࡶࠧ࠲ࠠ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢࡥࡣࡷࡥࠧࡀࠠࠨᗿ")
                    + json.dumps(str(bstack1l1llll111_opy_))
                    + bstack1l11ll_opy_ (u"ࠦࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡽ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃࠢᘀ")
                )
        except Exception as e:
            summary.append(bstack1l11ll_opy_ (u"ࠧ࡝ࡁࡓࡐࡌࡒࡌࡀࠠࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡥࡳࡴ࡯ࡵࡣࡷࡩ࠿ࠦࡻ࠱ࡿࠥᘁ").format(e))
def bstack1llll1llll1_opy_(test_name, error_message):
    try:
        bstack1llllll111l_opy_ = []
        bstack111l1llll_opy_ = os.environ.get(bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖࡌࡂࡖࡉࡓࡗࡓ࡟ࡊࡐࡇࡉ࡝࠭ᘂ"), bstack1l11ll_opy_ (u"ࠧ࠱ࠩᘃ"))
        bstack111lll11l_opy_ = {bstack1l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ᘄ"): test_name, bstack1l11ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨᘅ"): error_message, bstack1l11ll_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩᘆ"): bstack111l1llll_opy_}
        bstack1lllll111ll_opy_ = os.path.join(tempfile.gettempdir(), bstack1l11ll_opy_ (u"ࠫࡵࡽ࡟ࡱࡻࡷࡩࡸࡺ࡟ࡦࡴࡵࡳࡷࡥ࡬ࡪࡵࡷ࠲࡯ࡹ࡯࡯ࠩᘇ"))
        if os.path.exists(bstack1lllll111ll_opy_):
            with open(bstack1lllll111ll_opy_) as f:
                bstack1llllll111l_opy_ = json.load(f)
        bstack1llllll111l_opy_.append(bstack111lll11l_opy_)
        with open(bstack1lllll111ll_opy_, bstack1l11ll_opy_ (u"ࠬࡽࠧᘈ")) as f:
            json.dump(bstack1llllll111l_opy_, f)
    except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡲࡨࡶࡸ࡯ࡳࡵ࡫ࡱ࡫ࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡳࡽࡹ࡫ࡳࡵࠢࡨࡶࡷࡵࡲࡴ࠼ࠣࠫᘉ") + str(e))
def bstack1lllll11l11_opy_(item, report, summary, bstack1lllll1ll1l_opy_):
    if report.when in [bstack1l11ll_opy_ (u"ࠢࡴࡧࡷࡹࡵࠨᘊ"), bstack1l11ll_opy_ (u"ࠣࡶࡨࡥࡷࡪ࡯ࡸࡰࠥᘋ")]:
        return
    if (str(bstack1lllll1ll1l_opy_).lower() != bstack1l11ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧᘌ")):
        bstack1ll1111111_opy_(item._page, report.nodeid)
    passed = report.passed or report.skipped or (report.failed and hasattr(report, bstack1l11ll_opy_ (u"ࠥࡻࡦࡹࡸࡧࡣ࡬ࡰࠧᘍ")))
    bstack1l1llll111_opy_ = bstack1l11ll_opy_ (u"ࠦࠧᘎ")
    bstack11ll1111ll_opy_(report)
    if not report.skipped:
        if not passed:
            try:
                bstack1l1llll111_opy_ = report.longrepr.reprcrash
            except Exception as e:
                summary.append(
                    bstack1l11ll_opy_ (u"ࠧ࡝ࡁࡓࡐࡌࡒࡌࡀࠠࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡦࡢ࡫࡯ࡹࡷ࡫ࠠࡳࡧࡤࡷࡴࡴ࠺ࠡࡽ࠳ࢁࠧᘏ").format(e)
                )
        try:
            if passed:
                bstack1l1111l11_opy_(getattr(item, bstack1l11ll_opy_ (u"࠭࡟ࡱࡣࡪࡩࠬᘐ"), None), bstack1l11ll_opy_ (u"ࠢࡱࡣࡶࡷࡪࡪࠢᘑ"))
            else:
                error_message = bstack1l11ll_opy_ (u"ࠨࠩᘒ")
                if bstack1l1llll111_opy_:
                    bstack11l111111_opy_(item._page, str(bstack1l1llll111_opy_), bstack1l11ll_opy_ (u"ࠤࡨࡶࡷࡵࡲࠣᘓ"))
                    bstack1l1111l11_opy_(getattr(item, bstack1l11ll_opy_ (u"ࠪࡣࡵࡧࡧࡦࠩᘔ"), None), bstack1l11ll_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࠦᘕ"), str(bstack1l1llll111_opy_))
                    error_message = str(bstack1l1llll111_opy_)
                else:
                    bstack1l1111l11_opy_(getattr(item, bstack1l11ll_opy_ (u"ࠬࡥࡰࡢࡩࡨࠫᘖ"), None), bstack1l11ll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨᘗ"))
                bstack1llll1llll1_opy_(report.nodeid, error_message)
        except Exception as e:
            summary.append(bstack1l11ll_opy_ (u"ࠢࡘࡃࡕࡒࡎࡔࡇ࠻ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡻࡰࡥࡣࡷࡩࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡳࡵࡣࡷࡹࡸࡀࠠࡼ࠲ࢀࠦᘘ").format(e))
try:
    from typing import Generator
    import pytest_playwright.pytest_playwright as p
    @pytest.fixture
    def page(context: BrowserContext, request: pytest.FixtureRequest) -> Generator[Page, None, None]:
        page = context.new_page()
        request.node._page = page
        yield page
except:
    pass
def pytest_addoption(parser):
    parser.addoption(bstack1l11ll_opy_ (u"ࠣ࠯࠰ࡷࡰ࡯ࡰࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧᘙ"), default=bstack1l11ll_opy_ (u"ࠤࡉࡥࡱࡹࡥࠣᘚ"), help=bstack1l11ll_opy_ (u"ࠥࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡨࠦࡳࡦࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡳࡧ࡭ࡦࠤᘛ"))
    parser.addoption(bstack1l11ll_opy_ (u"ࠦ࠲࠳ࡳ࡬࡫ࡳࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠥᘜ"), default=bstack1l11ll_opy_ (u"ࠧࡌࡡ࡭ࡵࡨࠦᘝ"), help=bstack1l11ll_opy_ (u"ࠨࡁࡶࡶࡲࡱࡦࡺࡩࡤࠢࡶࡩࡹࠦࡳࡦࡵࡶ࡭ࡴࡴࠠ࡯ࡣࡰࡩࠧᘞ"))
    try:
        import pytest_selenium.pytest_selenium
    except:
        parser.addoption(bstack1l11ll_opy_ (u"ࠢ࠮࠯ࡧࡶ࡮ࡼࡥࡳࠤᘟ"), action=bstack1l11ll_opy_ (u"ࠣࡵࡷࡳࡷ࡫ࠢᘠ"), default=bstack1l11ll_opy_ (u"ࠤࡦ࡬ࡷࡵ࡭ࡦࠤᘡ"),
                         help=bstack1l11ll_opy_ (u"ࠥࡈࡷ࡯ࡶࡦࡴࠣࡸࡴࠦࡲࡶࡰࠣࡸࡪࡹࡴࡴࠤᘢ"))
def bstack111111_opy_(log):
    if not (log[bstack1l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᘣ")] and log[bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᘤ")].strip()):
        return
    active = bstack1lll111_opy_()
    log = {
        bstack1l11ll_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬᘥ"): log[bstack1l11ll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ᘦ")],
        bstack1l11ll_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫᘧ"): datetime.datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"ࠩ࡝ࠫᘨ"),
        bstack1l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᘩ"): log[bstack1l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᘪ")],
    }
    if active:
        if active[bstack1l11ll_opy_ (u"ࠬࡺࡹࡱࡧࠪᘫ")] == bstack1l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࠫᘬ"):
            log[bstack1l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᘭ")] = active[bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᘮ")]
        elif active[bstack1l11ll_opy_ (u"ࠩࡷࡽࡵ࡫ࠧᘯ")] == bstack1l11ll_opy_ (u"ࠪࡸࡪࡹࡴࠨᘰ"):
            log[bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫᘱ")] = active[bstack1l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᘲ")]
    bstack111lll1_opy_.bstack1l1l1l1_opy_([log])
def bstack1lll111_opy_():
    if len(store[bstack1l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡩࡱࡲ࡯ࡤࡻࡵࡪࡦࠪᘳ")]) > 0 and store[bstack1l11ll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡪࡲࡳࡰࡥࡵࡶ࡫ࡧࠫᘴ")][-1]:
        return {
            bstack1l11ll_opy_ (u"ࠨࡶࡼࡴࡪ࠭ᘵ"): bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱࠧᘶ"),
            bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᘷ"): store[bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤ࡮࡯ࡰ࡭ࡢࡹࡺ࡯ࡤࠨᘸ")][-1]
        }
    if store.get(bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩᘹ"), None):
        return {
            bstack1l11ll_opy_ (u"࠭ࡴࡺࡲࡨࠫᘺ"): bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࠬᘻ"),
            bstack1l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᘼ"): store[bstack1l11ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭ᘽ")]
        }
    return None
bstack1l1lll1_opy_ = bstack11l11l1_opy_(bstack111111_opy_)
def pytest_runtest_call(item):
    try:
        global CONFIG
        global bstack1lllll1ll11_opy_
        item._1lllll111l1_opy_ = True
        bstack11l1llll1_opy_ = bstack1lll1ll1_opy_.bstack1l1l1ll11_opy_(CONFIG, bstack111lll1ll1_opy_(item.own_markers))
        item._a11y_test_case = bstack11l1llll1_opy_
        if bstack1lllll1ll11_opy_:
            driver = getattr(item, bstack1l11ll_opy_ (u"ࠪࡣࡩࡸࡩࡷࡧࡵࠫᘾ"), None)
            item._a11y_started = bstack1lll1ll1_opy_.bstack1lll1llll1_opy_(driver, bstack11l1llll1_opy_)
        if not bstack111lll1_opy_.on() or bstack1lllllll111_opy_ != bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫᘿ"):
            return
        global current_test_uuid, bstack1l1lll1_opy_
        bstack1l1lll1_opy_.start()
        bstack1lll11l_opy_ = {
            bstack1l11ll_opy_ (u"ࠬࡻࡵࡪࡦࠪᙀ"): uuid4().__str__(),
            bstack1l11ll_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᙁ"): datetime.datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"࡛ࠧࠩᙂ")
        }
        current_test_uuid = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᙃ")]
        store[bstack1l11ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭ᙄ")] = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᙅ")]
        threading.current_thread().current_test_uuid = current_test_uuid
        _11lll11_opy_[item.nodeid] = {**_11lll11_opy_[item.nodeid], **bstack1lll11l_opy_}
        bstack1lllll1111l_opy_(item, _11lll11_opy_[item.nodeid], bstack1l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡺࡡࡳࡶࡨࡨࠬᙆ"))
    except Exception as err:
        print(bstack1l11ll_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡿࡴࡦࡵࡷࡣࡷࡻ࡮ࡵࡧࡶࡸࡤࡩࡡ࡭࡮࠽ࠤࢀࢃࠧᙇ"), str(err))
def pytest_runtest_setup(item):
    global bstack1lllll11111_opy_
    threading.current_thread().percySessionName = item.nodeid
    if bstack11l11ll11l_opy_():
        atexit.register(bstack1l11l1l1l1_opy_)
        if not bstack1lllll11111_opy_:
            try:
                bstack1llll1ll1ll_opy_ = [signal.SIGINT, signal.SIGTERM]
                if not bstack11l11l1lll_opy_():
                    bstack1llll1ll1ll_opy_.extend([signal.SIGHUP, signal.SIGQUIT])
                for s in bstack1llll1ll1ll_opy_:
                    signal.signal(s, bstack1llllll11l1_opy_)
                bstack1lllll11111_opy_ = True
            except Exception as e:
                logger.debug(
                    bstack1l11ll_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡴࡨ࡫࡮ࡹࡴࡦࡴࠣࡷ࡮࡭࡮ࡢ࡮ࠣ࡬ࡦࡴࡤ࡭ࡧࡵࡷ࠿ࠦࠢᙈ") + str(e))
        try:
            item.config.hook.pytest_selenium_runtest_makereport = bstack11l1lll1l1_opy_
        except Exception as err:
            threading.current_thread().testStatus = bstack1l11ll_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧᙉ")
    try:
        if not bstack111lll1_opy_.on():
            return
        bstack1l1lll1_opy_.start()
        uuid = uuid4().__str__()
        bstack1lll11l_opy_ = {
            bstack1l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᙊ"): uuid,
            bstack1l11ll_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᙋ"): datetime.datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"ࠪ࡞ࠬᙌ"),
            bstack1l11ll_opy_ (u"ࠫࡹࡿࡰࡦࠩᙍ"): bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࠪᙎ"),
            bstack1l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᙏ"): bstack1l11ll_opy_ (u"ࠧࡃࡇࡉࡓࡗࡋ࡟ࡆࡃࡆࡌࠬᙐ"),
            bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡥ࡮ࡢ࡯ࡨࠫᙑ"): bstack1l11ll_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨᙒ")
        }
        threading.current_thread().current_hook_uuid = uuid
        threading.current_thread().current_test_item = item
        store[bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡸࡪࡳࠧᙓ")] = item
        store[bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤ࡮࡯ࡰ࡭ࡢࡹࡺ࡯ࡤࠨᙔ")] = [uuid]
        if not _11lll11_opy_.get(item.nodeid, None):
            _11lll11_opy_[item.nodeid] = {bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᙕ"): [], bstack1l11ll_opy_ (u"࠭ࡦࡪࡺࡷࡹࡷ࡫ࡳࠨᙖ"): []}
        _11lll11_opy_[item.nodeid][bstack1l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡸ࠭ᙗ")].append(bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᙘ")])
        _11lll11_opy_[item.nodeid + bstack1l11ll_opy_ (u"ࠩ࠰ࡷࡪࡺࡵࡱࠩᙙ")] = bstack1lll11l_opy_
        bstack1lllll11ll1_opy_(item, bstack1lll11l_opy_, bstack1l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫᙚ"))
    except Exception as err:
        print(bstack1l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡾࡺࡥࡴࡶࡢࡶࡺࡴࡴࡦࡵࡷࡣࡸ࡫ࡴࡶࡲ࠽ࠤࢀࢃࠧᙛ"), str(err))
def pytest_runtest_teardown(item):
    try:
        global bstack1ll111lll_opy_
        if CONFIG.get(bstack1l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼࠫᙜ"), False):
            if CONFIG.get(bstack1l11ll_opy_ (u"࠭ࡰࡦࡴࡦࡽࡈࡧࡰࡵࡷࡵࡩࡒࡵࡤࡦࠩᙝ"), bstack1l11ll_opy_ (u"ࠢࡢࡷࡷࡳࠧᙞ")) == bstack1l11ll_opy_ (u"ࠣࡶࡨࡷࡹࡩࡡࡴࡧࠥᙟ"):
                bstack1llllll11ll_opy_ = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠩࡳࡩࡷࡩࡹࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬᙠ"), None)
                bstack11ll11l1_opy_ = bstack1llllll11ll_opy_ + bstack1l11ll_opy_ (u"ࠥ࠱ࡹ࡫ࡳࡵࡥࡤࡷࡪࠨᙡ")
                driver = getattr(item, bstack1l11ll_opy_ (u"ࠫࡤࡪࡲࡪࡸࡨࡶࠬᙢ"), None)
                PercySDK.screenshot(driver, bstack11ll11l1_opy_)
        if getattr(item, bstack1l11ll_opy_ (u"ࠬࡥࡡ࠲࠳ࡼࡣࡸࡺࡡࡳࡶࡨࡨࠬᙣ"), False):
            bstack1lll1l1l_opy_.bstack1lll1l11_opy_(getattr(item, bstack1l11ll_opy_ (u"࠭࡟ࡥࡴ࡬ࡺࡪࡸࠧᙤ"), None), bstack1ll111lll_opy_, logger, item)
        if not bstack111lll1_opy_.on():
            return
        bstack1lll11l_opy_ = {
            bstack1l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᙥ"): uuid4().__str__(),
            bstack1l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᙦ"): datetime.datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"ࠩ࡝ࠫᙧ"),
            bstack1l11ll_opy_ (u"ࠪࡸࡾࡶࡥࠨᙨ"): bstack1l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᙩ"),
            bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡸࡾࡶࡥࠨᙪ"): bstack1l11ll_opy_ (u"࠭ࡁࡇࡖࡈࡖࡤࡋࡁࡄࡊࠪᙫ"),
            bstack1l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡴࡡ࡮ࡧࠪᙬ"): bstack1l11ll_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࠪ᙭")
        }
        _11lll11_opy_[item.nodeid + bstack1l11ll_opy_ (u"ࠩ࠰ࡸࡪࡧࡲࡥࡱࡺࡲࠬ᙮")] = bstack1lll11l_opy_
        bstack1lllll11ll1_opy_(item, bstack1lll11l_opy_, bstack1l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫᙯ"))
    except Exception as err:
        print(bstack1l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡾࡺࡥࡴࡶࡢࡶࡺࡴࡴࡦࡵࡷࡣࡹ࡫ࡡࡳࡦࡲࡻࡳࡀࠠࡼࡿࠪᙰ"), str(err))
@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef, request):
    if not bstack111lll1_opy_.on():
        yield
        return
    start_time = datetime.datetime.now()
    if bstack11ll111l11_opy_(fixturedef.argname):
        store[bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥ࡭ࡰࡦࡸࡰࡪࡥࡩࡵࡧࡰࠫᙱ")] = request.node
    elif bstack11ll111l1l_opy_(fixturedef.argname):
        store[bstack1l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡤ࡮ࡤࡷࡸࡥࡩࡵࡧࡰࠫᙲ")] = request.node
    outcome = yield
    try:
        fixture = {
            bstack1l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᙳ"): fixturedef.argname,
            bstack1l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᙴ"): bstack11l11l11l1_opy_(outcome),
            bstack1l11ll_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫᙵ"): (datetime.datetime.now() - start_time).total_seconds() * 1000
        }
        current_test_item = store[bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡸࡪࡳࠧᙶ")]
        if not _11lll11_opy_.get(current_test_item.nodeid, None):
            _11lll11_opy_[current_test_item.nodeid] = {bstack1l11ll_opy_ (u"ࠫ࡫࡯ࡸࡵࡷࡵࡩࡸ࠭ᙷ"): []}
        _11lll11_opy_[current_test_item.nodeid][bstack1l11ll_opy_ (u"ࠬ࡬ࡩࡹࡶࡸࡶࡪࡹࠧᙸ")].append(fixture)
    except Exception as err:
        logger.debug(bstack1l11ll_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶࡹࡵࡧࡶࡸࡤ࡬ࡩࡹࡶࡸࡶࡪࡥࡳࡦࡶࡸࡴ࠿ࠦࡻࡾࠩᙹ"), str(err))
if bstack1l111l1l_opy_() and bstack111lll1_opy_.on():
    def pytest_bdd_before_step(request, step):
        try:
            _11lll11_opy_[request.node.nodeid][bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪᙺ")].bstack111l11l11l_opy_(id(step))
        except Exception as err:
            print(bstack1l11ll_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡣࡦࡧࡣࡧ࡫ࡦࡰࡴࡨࡣࡸࡺࡥࡱ࠼ࠣࡿࢂ࠭ᙻ"), str(err))
    def pytest_bdd_step_error(request, step, exception):
        try:
            _11lll11_opy_[request.node.nodeid][bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬᙼ")].bstack1l1l1ll_opy_(id(step), Result.failed(exception=exception))
        except Exception as err:
            print(bstack1l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵࡡࡥࡨࡩࡥࡳࡵࡧࡳࡣࡪࡸࡲࡰࡴ࠽ࠤࢀࢃࠧᙽ"), str(err))
    def pytest_bdd_after_step(request, step):
        try:
            bstack1lll1ll_opy_: bstack1l1ll1l_opy_ = _11lll11_opy_[request.node.nodeid][bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧᙾ")]
            bstack1lll1ll_opy_.bstack1l1l1ll_opy_(id(step), Result.passed())
        except Exception as err:
            print(bstack1l11ll_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡿࡴࡦࡵࡷࡣࡧࡪࡤࡠࡵࡷࡩࡵࡥࡥࡳࡴࡲࡶ࠿ࠦࡻࡾࠩᙿ"), str(err))
    def pytest_bdd_before_scenario(request, feature, scenario):
        global bstack1lllllll111_opy_
        try:
            if not bstack111lll1_opy_.on() or bstack1lllllll111_opy_ != bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠪ "):
                return
            global bstack1l1lll1_opy_
            bstack1l1lll1_opy_.start()
            driver = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱࡓࡦࡵࡶ࡭ࡴࡴࡄࡳ࡫ࡹࡩࡷ࠭ᚁ"), None)
            if not _11lll11_opy_.get(request.node.nodeid, None):
                _11lll11_opy_[request.node.nodeid] = {}
            bstack1lll1ll_opy_ = bstack1l1ll1l_opy_.bstack111l111lll_opy_(
                scenario, feature, request.node,
                name=bstack11l1llll1l_opy_(request.node, scenario),
                bstack111ll11_opy_=current_time(),
                file_path=feature.filename,
                scope=[feature.name],
                framework=bstack1l11ll_opy_ (u"ࠨࡒࡼࡸࡪࡹࡴ࠮ࡥࡸࡧࡺࡳࡢࡦࡴࠪᚂ"),
                tags=bstack11ll111111_opy_(feature, scenario),
                bstack11l1ll1_opy_=bstack111lll1_opy_.bstack1l1111l_opy_(driver) if driver and driver.session_id else {}
            )
            _11lll11_opy_[request.node.nodeid][bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬᚃ")] = bstack1lll1ll_opy_
            bstack1lllll1l1l1_opy_(bstack1lll1ll_opy_.uuid)
            bstack111lll1_opy_.bstack111l1ll_opy_(bstack1l11ll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫᚄ"), bstack1lll1ll_opy_)
        except Exception as err:
            print(bstack1l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡾࡺࡥࡴࡶࡢࡦࡩࡪ࡟ࡣࡧࡩࡳࡷ࡫࡟ࡴࡥࡨࡲࡦࡸࡩࡰ࠼ࠣࡿࢂ࠭ᚅ"), str(err))
def bstack1lllll1l11l_opy_(bstack1llll1lllll_opy_):
    if bstack1llll1lllll_opy_ in store[bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡨࡰࡱ࡮ࡣࡺࡻࡩࡥࠩᚆ")]:
        store[bstack1l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡩࡱࡲ࡯ࡤࡻࡵࡪࡦࠪᚇ")].remove(bstack1llll1lllll_opy_)
def bstack1lllll1l1l1_opy_(bstack1llll1ll1l1_opy_):
    store[bstack1l11ll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡶࡨࡷࡹࡥࡵࡶ࡫ࡧࠫᚈ")] = bstack1llll1ll1l1_opy_
    threading.current_thread().current_test_uuid = bstack1llll1ll1l1_opy_
@bstack111lll1_opy_.bstack11lll111ll_opy_
def bstack1llll1ll111_opy_(item, call, report):
    global bstack1lllllll111_opy_
    bstack11l1lll1_opy_ = current_time()
    if hasattr(report, bstack1l11ll_opy_ (u"ࠨࡵࡷࡳࡵ࠭ᚉ")):
        bstack11l1lll1_opy_ = bstack11l111ll1l_opy_(report.stop)
    elif hasattr(report, bstack1l11ll_opy_ (u"ࠩࡶࡸࡦࡸࡴࠨᚊ")):
        bstack11l1lll1_opy_ = bstack11l111ll1l_opy_(report.start)
    try:
        if getattr(report, bstack1l11ll_opy_ (u"ࠪࡻ࡭࡫࡮ࠨᚋ"), bstack1l11ll_opy_ (u"ࠫࠬᚌ")) == bstack1l11ll_opy_ (u"ࠬࡩࡡ࡭࡮ࠪᚍ"):
            bstack1l1lll1_opy_.reset()
        if getattr(report, bstack1l11ll_opy_ (u"࠭ࡷࡩࡧࡱࠫᚎ"), bstack1l11ll_opy_ (u"ࠧࠨᚏ")) == bstack1l11ll_opy_ (u"ࠨࡥࡤࡰࡱ࠭ᚐ"):
            if bstack1lllllll111_opy_ == bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩᚑ"):
                _11lll11_opy_[item.nodeid][bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᚒ")] = bstack11l1lll1_opy_
                bstack1lllll1111l_opy_(item, _11lll11_opy_[item.nodeid], bstack1l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭ᚓ"), report, call)
                store[bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩᚔ")] = None
            elif bstack1lllllll111_opy_ == bstack1l11ll_opy_ (u"ࠨࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠥᚕ"):
                bstack1lll1ll_opy_ = _11lll11_opy_[item.nodeid][bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪᚖ")]
                bstack1lll1ll_opy_.set(hooks=_11lll11_opy_[item.nodeid].get(bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧᚗ"), []))
                exception, bstack1l111ll_opy_ = None, None
                if call.excinfo:
                    exception = call.excinfo.value
                    bstack1l111ll_opy_ = [call.excinfo.exconly(), getattr(report, bstack1l11ll_opy_ (u"ࠩ࡯ࡳࡳ࡭ࡲࡦࡲࡵࡸࡪࡾࡴࠨᚘ"), bstack1l11ll_opy_ (u"ࠪࠫᚙ"))]
                bstack1lll1ll_opy_.stop(time=bstack11l1lll1_opy_, result=Result(result=getattr(report, bstack1l11ll_opy_ (u"ࠫࡴࡻࡴࡤࡱࡰࡩࠬᚚ"), bstack1l11ll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬ᚛")), exception=exception, bstack1l111ll_opy_=bstack1l111ll_opy_))
                bstack111lll1_opy_.bstack111l1ll_opy_(bstack1l11ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨ᚜"), _11lll11_opy_[item.nodeid][bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪ᚝")])
        elif getattr(report, bstack1l11ll_opy_ (u"ࠨࡹ࡫ࡩࡳ࠭᚞"), bstack1l11ll_opy_ (u"ࠩࠪ᚟")) in [bstack1l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࠩᚠ"), bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳ࠭ᚡ")]:
            bstack1llllll1_opy_ = item.nodeid + bstack1l11ll_opy_ (u"ࠬ࠳ࠧᚢ") + getattr(report, bstack1l11ll_opy_ (u"࠭ࡷࡩࡧࡱࠫᚣ"), bstack1l11ll_opy_ (u"ࠧࠨᚤ"))
            if getattr(report, bstack1l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩᚥ"), False):
                hook_type = bstack1l11ll_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡈࡅࡈࡎࠧᚦ") if getattr(report, bstack1l11ll_opy_ (u"ࠪࡻ࡭࡫࡮ࠨᚧ"), bstack1l11ll_opy_ (u"ࠫࠬᚨ")) == bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫᚩ") else bstack1l11ll_opy_ (u"࠭ࡁࡇࡖࡈࡖࡤࡋࡁࡄࡊࠪᚪ")
                _11lll11_opy_[bstack1llllll1_opy_] = {
                    bstack1l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᚫ"): uuid4().__str__(),
                    bstack1l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᚬ"): bstack11l1lll1_opy_,
                    bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᚭ"): hook_type
                }
            _11lll11_opy_[bstack1llllll1_opy_][bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᚮ")] = bstack11l1lll1_opy_
            bstack1lllll1l11l_opy_(_11lll11_opy_[bstack1llllll1_opy_][bstack1l11ll_opy_ (u"ࠫࡺࡻࡩࡥࠩᚯ")])
            bstack1lllll11ll1_opy_(item, _11lll11_opy_[bstack1llllll1_opy_], bstack1l11ll_opy_ (u"ࠬࡎ࡯ࡰ࡭ࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧᚰ"), report, call)
            if getattr(report, bstack1l11ll_opy_ (u"࠭ࡷࡩࡧࡱࠫᚱ"), bstack1l11ll_opy_ (u"ࠧࠨᚲ")) == bstack1l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧᚳ"):
                if getattr(report, bstack1l11ll_opy_ (u"ࠩࡲࡹࡹࡩ࡯࡮ࡧࠪᚴ"), bstack1l11ll_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪᚵ")) == bstack1l11ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᚶ"):
                    bstack1lll11l_opy_ = {
                        bstack1l11ll_opy_ (u"ࠬࡻࡵࡪࡦࠪᚷ"): uuid4().__str__(),
                        bstack1l11ll_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᚸ"): current_time(),
                        bstack1l11ll_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᚹ"): current_time()
                    }
                    _11lll11_opy_[item.nodeid] = {**_11lll11_opy_[item.nodeid], **bstack1lll11l_opy_}
                    bstack1lllll1111l_opy_(item, _11lll11_opy_[item.nodeid], bstack1l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡕࡷࡥࡷࡺࡥࡥࠩᚺ"))
                    bstack1lllll1111l_opy_(item, _11lll11_opy_[item.nodeid], bstack1l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫᚻ"), report, call)
    except Exception as err:
        print(bstack1l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢ࡫ࡥࡳࡪ࡬ࡦࡡࡲ࠵࠶ࡿ࡟ࡵࡧࡶࡸࡤ࡫ࡶࡦࡰࡷ࠾ࠥࢁࡽࠨᚼ"), str(err))
def bstack1llll1l1lll_opy_(test, bstack1lll11l_opy_, result=None, call=None, bstack111l11ll_opy_=None, outcome=None):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    bstack1lll1ll_opy_ = {
        bstack1l11ll_opy_ (u"ࠫࡺࡻࡩࡥࠩᚽ"): bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠬࡻࡵࡪࡦࠪᚾ")],
        bstack1l11ll_opy_ (u"࠭ࡴࡺࡲࡨࠫᚿ"): bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࠬᛀ"),
        bstack1l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ᛁ"): test.name,
        bstack1l11ll_opy_ (u"ࠩࡥࡳࡩࡿࠧᛂ"): {
            bstack1l11ll_opy_ (u"ࠪࡰࡦࡴࡧࠨᛃ"): bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫᛄ"),
            bstack1l11ll_opy_ (u"ࠬࡩ࡯ࡥࡧࠪᛅ"): inspect.getsource(test.obj)
        },
        bstack1l11ll_opy_ (u"࠭ࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪᛆ"): test.name,
        bstack1l11ll_opy_ (u"ࠧࡴࡥࡲࡴࡪ࠭ᛇ"): test.name,
        bstack1l11ll_opy_ (u"ࠨࡵࡦࡳࡵ࡫ࡳࠨᛈ"): bstack111lll1_opy_.bstack1l1l111_opy_(test),
        bstack1l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬᛉ"): file_path,
        bstack1l11ll_opy_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬᛊ"): file_path,
        bstack1l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᛋ"): bstack1l11ll_opy_ (u"ࠬࡶࡥ࡯ࡦ࡬ࡲ࡬࠭ᛌ"),
        bstack1l11ll_opy_ (u"࠭ࡶࡤࡡࡩ࡭ࡱ࡫ࡰࡢࡶ࡫ࠫᛍ"): file_path,
        bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠫᛎ"): bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᛏ")],
        bstack1l11ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬᛐ"): bstack1l11ll_opy_ (u"ࠪࡔࡾࡺࡥࡴࡶࠪᛑ"),
        bstack1l11ll_opy_ (u"ࠫࡨࡻࡳࡵࡱࡰࡖࡪࡸࡵ࡯ࡒࡤࡶࡦࡳࠧᛒ"): {
            bstack1l11ll_opy_ (u"ࠬࡸࡥࡳࡷࡱࡣࡳࡧ࡭ࡦࠩᛓ"): test.nodeid
        },
        bstack1l11ll_opy_ (u"࠭ࡴࡢࡩࡶࠫᛔ"): bstack111lll1ll1_opy_(test.own_markers)
    }
    if bstack111l11ll_opy_ in [bstack1l11ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔ࡭࡬ࡴࡵ࡫ࡤࠨᛕ"), bstack1l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᛖ")]:
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠩࡰࡩࡹࡧࠧᛗ")] = {
            bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡾࡴࡶࡴࡨࡷࠬᛘ"): bstack1lll11l_opy_.get(bstack1l11ll_opy_ (u"ࠫ࡫࡯ࡸࡵࡷࡵࡩࡸ࠭ᛙ"), [])
        }
    if bstack111l11ll_opy_ == bstack1l11ll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙࡫ࡪࡲࡳࡩࡩ࠭ᛚ"):
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᛛ")] = bstack1l11ll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨᛜ")
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧᛝ")] = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᛞ")]
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᛟ")] = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᛠ")]
    if result:
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᛡ")] = result.outcome
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࡠ࡫ࡱࡣࡲࡹࠧᛢ")] = result.duration * 1000
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᛣ")] = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᛤ")]
        if result.failed:
            bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨᛥ")] = bstack111lll1_opy_.bstack1l111lll1l_opy_(call.excinfo.typename)
            bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫᛦ")] = bstack111lll1_opy_.bstack11lll111l1_opy_(call.excinfo, result)
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡵࠪᛧ")] = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᛨ")]
    if outcome:
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᛩ")] = bstack11l11l11l1_opy_(outcome)
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨᛪ")] = 0
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭᛫")] = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧ᛬")]
        if bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ᛭")] == bstack1l11ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᛮ"):
            bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪࡥࡴࡺࡲࡨࠫᛯ")] = bstack1l11ll_opy_ (u"࠭ࡕ࡯ࡪࡤࡲࡩࡲࡥࡥࡇࡵࡶࡴࡸࠧᛰ")  # bstack1llllll1l1l_opy_
            bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡺࡸࡥࠨᛱ")] = [{bstack1l11ll_opy_ (u"ࠨࡤࡤࡧࡰࡺࡲࡢࡥࡨࠫᛲ"): [bstack1l11ll_opy_ (u"ࠩࡶࡳࡲ࡫ࠠࡦࡴࡵࡳࡷ࠭ᛳ")]}]
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩᛴ")] = bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡵࠪᛵ")]
    return bstack1lll1ll_opy_
def bstack1lllll11lll_opy_(test, bstack1111l11_opy_, bstack111l11ll_opy_, result, call, outcome, bstack1llllll1111_opy_):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    hook_type = bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡸࡾࡶࡥࠨᛶ")]
    hook_name = bstack1111l11_opy_[bstack1l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡳࡧ࡭ࡦࠩᛷ")]
    hook_data = {
        bstack1l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᛸ"): bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭᛹")],
        bstack1l11ll_opy_ (u"ࠩࡷࡽࡵ࡫ࠧ᛺"): bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࠨ᛻"),
        bstack1l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ᛼"): bstack1l11ll_opy_ (u"ࠬࢁࡽࠨ᛽").format(bstack11l1llllll_opy_(hook_name)),
        bstack1l11ll_opy_ (u"࠭ࡢࡰࡦࡼࠫ᛾"): {
            bstack1l11ll_opy_ (u"ࠧ࡭ࡣࡱ࡫ࠬ᛿"): bstack1l11ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨᜀ"),
            bstack1l11ll_opy_ (u"ࠩࡦࡳࡩ࡫ࠧᜁ"): None
        },
        bstack1l11ll_opy_ (u"ࠪࡷࡨࡵࡰࡦࠩᜂ"): test.name,
        bstack1l11ll_opy_ (u"ࠫࡸࡩ࡯ࡱࡧࡶࠫᜃ"): bstack111lll1_opy_.bstack1l1l111_opy_(test, hook_name),
        bstack1l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨᜄ"): file_path,
        bstack1l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨᜅ"): file_path,
        bstack1l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᜆ"): bstack1l11ll_opy_ (u"ࠨࡲࡨࡲࡩ࡯࡮ࡨࠩᜇ"),
        bstack1l11ll_opy_ (u"ࠩࡹࡧࡤ࡬ࡩ࡭ࡧࡳࡥࡹ࡮ࠧᜈ"): file_path,
        bstack1l11ll_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᜉ"): bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᜊ")],
        bstack1l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨᜋ"): bstack1l11ll_opy_ (u"࠭ࡐࡺࡶࡨࡷࡹ࠳ࡣࡶࡥࡸࡱࡧ࡫ࡲࠨᜌ") if bstack1lllllll111_opy_ == bstack1l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠫᜍ") else bstack1l11ll_opy_ (u"ࠨࡒࡼࡸࡪࡹࡴࠨᜎ"),
        bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᜏ"): hook_type
    }
    bstack1lllll11l1l_opy_ = bstack111111l_opy_(_11lll11_opy_.get(test.nodeid, None))
    if bstack1lllll11l1l_opy_:
        hook_data[bstack1l11ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤ࡯ࡤࠨᜐ")] = bstack1lllll11l1l_opy_
    if result:
        hook_data[bstack1l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᜑ")] = result.outcome
        hook_data[bstack1l11ll_opy_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴ࡟ࡪࡰࡢࡱࡸ࠭ᜒ")] = result.duration * 1000
        hook_data[bstack1l11ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᜓ")] = bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸ᜔ࠬ")]
        if result.failed:
            hook_data[bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࡡࡷࡽࡵ࡫᜕ࠧ")] = bstack111lll1_opy_.bstack1l111lll1l_opy_(call.excinfo.typename)
            hook_data[bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪ᜖")] = bstack111lll1_opy_.bstack11lll111l1_opy_(call.excinfo, result)
    if outcome:
        hook_data[bstack1l11ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ᜗")] = bstack11l11l11l1_opy_(outcome)
        hook_data[bstack1l11ll_opy_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳࡥࡩ࡯ࡡࡰࡷࠬ᜘")] = 100
        hook_data[bstack1l11ll_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪ᜙")] = bstack1111l11_opy_[bstack1l11ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫ᜚")]
        if hook_data[bstack1l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ᜛")] == bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ᜜"):
            hook_data[bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨ᜝")] = bstack1l11ll_opy_ (u"࡙ࠪࡳ࡮ࡡ࡯ࡦ࡯ࡩࡩࡋࡲࡳࡱࡵࠫ᜞")  # bstack1llllll1l1l_opy_
            hook_data[bstack1l11ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᜟ")] = [{bstack1l11ll_opy_ (u"ࠬࡨࡡࡤ࡭ࡷࡶࡦࡩࡥࠨᜠ"): [bstack1l11ll_opy_ (u"࠭ࡳࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠪᜡ")]}]
    if bstack1llllll1111_opy_:
        hook_data[bstack1l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᜢ")] = bstack1llllll1111_opy_.result
        hook_data[bstack1l11ll_opy_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࡢ࡭ࡳࡥ࡭ࡴࠩᜣ")] = bstack11l11111l1_opy_(bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᜤ")], bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᜥ")])
        hook_data[bstack1l11ll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᜦ")] = bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᜧ")]
        if hook_data[bstack1l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᜨ")] == bstack1l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧᜩ"):
            hook_data[bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࡡࡷࡽࡵ࡫ࠧᜪ")] = bstack111lll1_opy_.bstack1l111lll1l_opy_(bstack1llllll1111_opy_.exception_type)
            hook_data[bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪᜫ")] = [{bstack1l11ll_opy_ (u"ࠪࡦࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭ᜬ"): bstack111llllll1_opy_(bstack1llllll1111_opy_.exception)}]
    return hook_data
def bstack1lllll1111l_opy_(test, bstack1lll11l_opy_, bstack111l11ll_opy_, result=None, call=None, outcome=None):
    bstack1lll1ll_opy_ = bstack1llll1l1lll_opy_(test, bstack1lll11l_opy_, result, call, bstack111l11ll_opy_, outcome)
    driver = getattr(test, bstack1l11ll_opy_ (u"ࠫࡤࡪࡲࡪࡸࡨࡶࠬᜭ"), None)
    if bstack111l11ll_opy_ == bstack1l11ll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙ࡴࡢࡴࡷࡩࡩ࠭ᜮ") and driver:
        bstack1lll1ll_opy_[bstack1l11ll_opy_ (u"࠭ࡩ࡯ࡶࡨ࡫ࡷࡧࡴࡪࡱࡱࡷࠬᜯ")] = bstack111lll1_opy_.bstack1l1111l_opy_(driver)
    if bstack111l11ll_opy_ == bstack1l11ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔ࡭࡬ࡴࡵ࡫ࡤࠨᜰ"):
        bstack111l11ll_opy_ = bstack1l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᜱ")
    bstack1111l1l_opy_ = {
        bstack1l11ll_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ᜲ"): bstack111l11ll_opy_,
        bstack1l11ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࠬᜳ"): bstack1lll1ll_opy_
    }
    bstack111lll1_opy_.bstack1lllllll_opy_(bstack1111l1l_opy_)
def bstack1lllll11ll1_opy_(test, bstack1lll11l_opy_, bstack111l11ll_opy_, result=None, call=None, outcome=None, bstack1llllll1111_opy_=None):
    hook_data = bstack1lllll11lll_opy_(test, bstack1lll11l_opy_, bstack111l11ll_opy_, result, call, outcome, bstack1llllll1111_opy_)
    bstack1111l1l_opy_ = {
        bstack1l11ll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨ᜴"): bstack111l11ll_opy_,
        bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴࠧ᜵"): hook_data
    }
    bstack111lll1_opy_.bstack1lllllll_opy_(bstack1111l1l_opy_)
def bstack111111l_opy_(bstack1lll11l_opy_):
    if not bstack1lll11l_opy_:
        return None
    if bstack1lll11l_opy_.get(bstack1l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡩࡧࡴࡢࠩ᜶"), None):
        return getattr(bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪ᜷")], bstack1l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭᜸"), None)
    return bstack1lll11l_opy_.get(bstack1l11ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧ᜹"), None)
@pytest.fixture(autouse=True)
def second_fixture(caplog, request):
    yield
    try:
        if not bstack111lll1_opy_.on():
            return
        places = [bstack1l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࠩ᜺"), bstack1l11ll_opy_ (u"ࠫࡨࡧ࡬࡭ࠩ᜻"), bstack1l11ll_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴࠧ᜼")]
        bstack1lllll1_opy_ = []
        for bstack1lllll1l1ll_opy_ in places:
            records = caplog.get_records(bstack1lllll1l1ll_opy_)
            bstack1lllll1l111_opy_ = bstack1l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭᜽") if bstack1lllll1l1ll_opy_ == bstack1l11ll_opy_ (u"ࠧࡤࡣ࡯ࡰࠬ᜾") else bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ᜿")
            bstack1llllll1l11_opy_ = request.node.nodeid + (bstack1l11ll_opy_ (u"ࠩࠪᝀ") if bstack1lllll1l1ll_opy_ == bstack1l11ll_opy_ (u"ࠪࡧࡦࡲ࡬ࠨᝁ") else bstack1l11ll_opy_ (u"ࠫ࠲࠭ᝂ") + bstack1lllll1l1ll_opy_)
            bstack1llll1ll1l1_opy_ = bstack111111l_opy_(_11lll11_opy_.get(bstack1llllll1l11_opy_, None))
            if not bstack1llll1ll1l1_opy_:
                continue
            for record in records:
                if bstack111lllll1l_opy_(record.message):
                    continue
                bstack1lllll1_opy_.append({
                    bstack1l11ll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨᝃ"): datetime.datetime.utcfromtimestamp(record.created).isoformat() + bstack1l11ll_opy_ (u"࡚࠭ࠨᝄ"),
                    bstack1l11ll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ᝅ"): record.levelname,
                    bstack1l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᝆ"): record.message,
                    bstack1lllll1l111_opy_: bstack1llll1ll1l1_opy_
                })
        if len(bstack1lllll1_opy_) > 0:
            bstack111lll1_opy_.bstack1l1l1l1_opy_(bstack1lllll1_opy_)
    except Exception as err:
        print(bstack1l11ll_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡵࡨࡧࡴࡴࡤࡠࡨ࡬ࡼࡹࡻࡲࡦ࠼ࠣࡿࢂ࠭ᝇ"), str(err))
def bstack1l11lllll_opy_(sequence, driver_command, response=None, driver = None, args = None):
    global bstack1lll11l1l_opy_
    bstack1l1l11ll11_opy_ = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪ࡭ࡸࡇ࠱࠲ࡻࡗࡩࡸࡺࠧᝈ"), None) and bstack1111111_opy_(
            threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡦ࠷࠱ࡺࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪᝉ"), None)
    bstack1l11ll111_opy_ = getattr(driver, bstack1l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡆ࠷࠱ࡺࡕ࡫ࡳࡺࡲࡤࡔࡥࡤࡲࠬᝊ"), None) != None and getattr(driver, bstack1l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡇ࠱࠲ࡻࡖ࡬ࡴࡻ࡬ࡥࡕࡦࡥࡳ࠭ᝋ"), None) == True
    if sequence == bstack1l11ll_opy_ (u"ࠧࡣࡧࡩࡳࡷ࡫ࠧᝌ") and driver != None:
      if not bstack1lll11l1l_opy_ and bstack111lllll11_opy_() and bstack1l11ll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨᝍ") in CONFIG and CONFIG[bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩᝎ")] == True and bstack1lll1ll1l1_opy_.bstack1llllllll1_opy_(driver_command) and (bstack1l11ll111_opy_ or bstack1l1l11ll11_opy_) and not bstack1lllllll1l_opy_(args):
        try:
          bstack1lll11l1l_opy_ = True
          logger.debug(bstack1l11ll_opy_ (u"ࠪࡔࡪࡸࡦࡰࡴࡰ࡭ࡳ࡭ࠠࡴࡥࡤࡲࠥ࡬࡯ࡳࠢࡾࢁࠬᝏ").format(driver_command))
          logger.debug(perform_scan(driver, driver_command=driver_command))
        except Exception as err:
          logger.debug(bstack1l11ll_opy_ (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡱࡧࡵࡪࡴࡸ࡭ࠡࡵࡦࡥࡳࠦࡻࡾࠩᝐ").format(str(err)))
        bstack1lll11l1l_opy_ = False
    if sequence == bstack1l11ll_opy_ (u"ࠬࡧࡦࡵࡧࡵࠫᝑ"):
        if driver_command == bstack1l11ll_opy_ (u"࠭ࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࠪᝒ"):
            bstack111lll1_opy_.bstack1l1l111111_opy_({
                bstack1l11ll_opy_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ᝓ"): response[bstack1l11ll_opy_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ᝔")],
                bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ᝕"): store[bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡࡸࡹ࡮ࡪࠧ᝖")]
            })
def bstack1l11l1l1l1_opy_():
    global bstack1l1111l1l_opy_
    bstack1ll1l1111l_opy_.bstack1ll11l1ll1_opy_()
    logging.shutdown()
    bstack111lll1_opy_.bstack11l1111_opy_()
    for driver in bstack1l1111l1l_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack1llllll11l1_opy_(*args):
    global bstack1l1111l1l_opy_
    bstack111lll1_opy_.bstack11l1111_opy_()
    for driver in bstack1l1111l1l_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack111l1l1l1_opy_(self, *args, **kwargs):
    bstack111l1ll1l_opy_ = bstack111111111_opy_(self, *args, **kwargs)
    bstack111lll1_opy_.bstack11ll11lll_opy_(self)
    return bstack111l1ll1l_opy_
def bstack1l1l1l1ll1_opy_(framework_name):
    global bstack1ll1l1l1ll_opy_
    global bstack1l11l1l11_opy_
    bstack1ll1l1l1ll_opy_ = framework_name
    logger.info(bstack1l1llll1l1_opy_.format(bstack1ll1l1l1ll_opy_.split(bstack1l11ll_opy_ (u"ࠫ࠲࠭᝗"))[0]))
    try:
        from selenium import webdriver
        from selenium.webdriver.common.service import Service
        from selenium.webdriver.remote.webdriver import WebDriver
        if bstack111lllll11_opy_():
            Service.start = bstack1l11ll11l_opy_
            Service.stop = bstack11111l11l_opy_
            webdriver.Remote.__init__ = bstack1l1ll1llll_opy_
            webdriver.Remote.get = bstack1l1ll11l1_opy_
            if not isinstance(os.getenv(bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕ࡟ࡔࡆࡕࡗࡣࡕࡇࡒࡂࡎࡏࡉࡑ࠭᝘")), str):
                return
            WebDriver.close = bstack111l11111_opy_
            WebDriver.quit = bstack1l1111lll_opy_
            WebDriver.getAccessibilityResults = getAccessibilityResults
            WebDriver.get_accessibility_results = getAccessibilityResults
            WebDriver.getAccessibilityResultsSummary = getAccessibilityResultsSummary
            WebDriver.get_accessibility_results_summary = getAccessibilityResultsSummary
            WebDriver.performScan = perform_scan
            WebDriver.perform_scan = perform_scan
        if not bstack111lllll11_opy_() and bstack111lll1_opy_.on():
            webdriver.Remote.__init__ = bstack111l1l1l1_opy_
        bstack1l11l1l11_opy_ = True
    except Exception as e:
        pass
    bstack1ll1111ll1_opy_()
    if os.environ.get(bstack1l11ll_opy_ (u"࠭ࡓࡆࡎࡈࡒࡎ࡛ࡍࡠࡑࡕࡣࡕࡒࡁ࡚࡙ࡕࡍࡌࡎࡔࡠࡋࡑࡗ࡙ࡇࡌࡍࡇࡇࠫ᝙")):
        bstack1l11l1l11_opy_ = eval(os.environ.get(bstack1l11ll_opy_ (u"ࠧࡔࡇࡏࡉࡓࡏࡕࡎࡡࡒࡖࡤࡖࡌࡂ࡛࡚ࡖࡎࡍࡈࡕࡡࡌࡒࡘ࡚ࡁࡍࡎࡈࡈࠬ᝚")))
    if not bstack1l11l1l11_opy_:
        bstack1llllll1l1_opy_(bstack1l11ll_opy_ (u"ࠣࡒࡤࡧࡰࡧࡧࡦࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠥ᝛"), bstack1l1lll1ll1_opy_)
    if bstack1l1l1l111_opy_():
        try:
            from selenium.webdriver.remote.remote_connection import RemoteConnection
            RemoteConnection._get_proxy_url = bstack1l1l1lll1l_opy_
        except Exception as e:
            logger.error(bstack1l1111l1_opy_.format(str(e)))
    if bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ᝜") in str(framework_name).lower():
        if not bstack111lllll11_opy_():
            return
        try:
            from pytest_selenium import pytest_selenium
            from _pytest.config import Config
            pytest_selenium.pytest_report_header = bstack11l1l11l_opy_
            from pytest_selenium.drivers import browserstack
            browserstack.pytest_selenium_runtest_makereport = bstack1l11l111l_opy_
            Config.getoption = bstack1l1l1l11l_opy_
        except Exception as e:
            pass
        try:
            from pytest_bdd import reporting
            reporting.runtest_makereport = bstack111llllll_opy_
        except Exception as e:
            pass
def bstack1l1111lll_opy_(self):
    global bstack1ll1l1l1ll_opy_
    global bstack1l1l1lll11_opy_
    global bstack1111l11l_opy_
    try:
        if bstack1l11ll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪ᝝") in bstack1ll1l1l1ll_opy_ and self.session_id != None and bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡕࡷࡥࡹࡻࡳࠨ᝞"), bstack1l11ll_opy_ (u"ࠬ࠭᝟")) != bstack1l11ll_opy_ (u"࠭ࡳ࡬࡫ࡳࡴࡪࡪࠧᝠ"):
            bstack1l11llll1_opy_ = bstack1l11ll_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧᝡ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᝢ")
            bstack1l111111l_opy_(logger, True)
            if self != None:
                bstack1l11lll1l_opy_(self, bstack1l11llll1_opy_, bstack1l11ll_opy_ (u"ࠩ࠯ࠤࠬᝣ").join(threading.current_thread().bstackTestErrorMessages))
        item = store.get(bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡸࡪࡳࠧᝤ"), None)
        if item is not None and bstack1lllll1ll11_opy_:
            bstack1lll1l1l_opy_.bstack1lll1l11_opy_(self, bstack1ll111lll_opy_, logger, item)
        threading.current_thread().testStatus = bstack1l11ll_opy_ (u"ࠫࠬᝥ")
    except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡱࡦࡸ࡫ࡪࡰࡪࠤࡸࡺࡡࡵࡷࡶ࠾ࠥࠨᝦ") + str(e))
    bstack1111l11l_opy_(self)
    self.session_id = None
def bstack1l1ll1llll_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
    global CONFIG
    global bstack1l1l1lll11_opy_
    global bstack111l11l1_opy_
    global bstack1llll1ll11_opy_
    global bstack1ll1l1l1ll_opy_
    global bstack111111111_opy_
    global bstack1l1111l1l_opy_
    global bstack1ll1l1l1l1_opy_
    global bstack1llll11l11_opy_
    global bstack1lllll1ll11_opy_
    global bstack1ll111lll_opy_
    CONFIG[bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡘࡊࡋࠨᝧ")] = str(bstack1ll1l1l1ll_opy_) + str(__version__)
    command_executor = bstack1llllll11l_opy_(bstack1ll1l1l1l1_opy_)
    logger.debug(bstack11lll111_opy_.format(command_executor))
    proxy = bstack11llll11l_opy_(CONFIG, proxy)
    bstack111l1llll_opy_ = 0
    try:
        if bstack1llll1ll11_opy_ is True:
            bstack111l1llll_opy_ = int(os.environ.get(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧᝨ")))
    except:
        bstack111l1llll_opy_ = 0
    bstack1ll1l111l1_opy_ = bstack111ll11l1_opy_(CONFIG, bstack111l1llll_opy_)
    logger.debug(bstack1ll11l1lll_opy_.format(str(bstack1ll1l111l1_opy_)))
    bstack1ll111lll_opy_ = CONFIG.get(bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫᝩ"))[bstack111l1llll_opy_]
    if bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ᝪ") in CONFIG and CONFIG[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧᝫ")]:
        bstack1llll111l1_opy_(bstack1ll1l111l1_opy_, bstack1llll11l11_opy_)
    if bstack1lll1ll1_opy_.bstack1l1ll11ll_opy_(CONFIG, bstack111l1llll_opy_) and bstack1lll1ll1_opy_.bstack1l1l11l111_opy_(bstack1ll1l111l1_opy_, options):
        bstack1lllll1ll11_opy_ = True
        bstack1lll1ll1_opy_.set_capabilities(bstack1ll1l111l1_opy_, CONFIG)
    if desired_capabilities:
        bstack1l1l11ll1l_opy_ = bstack111l111l_opy_(desired_capabilities)
        bstack1l1l11ll1l_opy_[bstack1l11ll_opy_ (u"ࠫࡺࡹࡥࡘ࠵ࡆࠫᝬ")] = bstack1l11ll1l11_opy_(CONFIG)
        bstack1llll11l1l_opy_ = bstack111ll11l1_opy_(bstack1l1l11ll1l_opy_)
        if bstack1llll11l1l_opy_:
            bstack1ll1l111l1_opy_ = update(bstack1llll11l1l_opy_, bstack1ll1l111l1_opy_)
        desired_capabilities = None
    if options:
        bstack11lllllll_opy_(options, bstack1ll1l111l1_opy_)
    if not options:
        options = bstack1ll1ll111_opy_(bstack1ll1l111l1_opy_)
    if proxy and bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠬ࠺࠮࠲࠲࠱࠴ࠬ᝭")):
        options.proxy(proxy)
    if options and bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"࠭࠳࠯࠺࠱࠴ࠬᝮ")):
        desired_capabilities = None
    if (
            not options and not desired_capabilities
    ) or (
            bstack1ll11lll11_opy_() < version.parse(bstack1l11ll_opy_ (u"ࠧ࠴࠰࠻࠲࠵࠭ᝯ")) and not desired_capabilities
    ):
        desired_capabilities = {}
        desired_capabilities.update(bstack1ll1l111l1_opy_)
    logger.info(bstack1l1l11l11_opy_)
    if bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠨ࠶࠱࠵࠵࠴࠰ࠨᝰ")):
        bstack111111111_opy_(self, command_executor=command_executor,
                  options=options, keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠩ࠶࠲࠽࠴࠰ࠨ᝱")):
        bstack111111111_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities, options=options,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠪ࠶࠳࠻࠳࠯࠲ࠪᝲ")):
        bstack111111111_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    else:
        bstack111111111_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive)
    try:
        bstack1lll111ll_opy_ = bstack1l11ll_opy_ (u"ࠫࠬᝳ")
        if bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠬ࠺࠮࠱࠰࠳ࡦ࠶࠭᝴")):
            bstack1lll111ll_opy_ = self.caps.get(bstack1l11ll_opy_ (u"ࠨ࡯ࡱࡶ࡬ࡱࡦࡲࡈࡶࡤࡘࡶࡱࠨ᝵"))
        else:
            bstack1lll111ll_opy_ = self.capabilities.get(bstack1l11ll_opy_ (u"ࠢࡰࡲࡷ࡭ࡲࡧ࡬ࡉࡷࡥ࡙ࡷࡲࠢ᝶"))
        if bstack1lll111ll_opy_:
            bstack1lll1l1ll_opy_(bstack1lll111ll_opy_)
            if bstack1ll11lll11_opy_() <= version.parse(bstack1l11ll_opy_ (u"ࠨ࠵࠱࠵࠸࠴࠰ࠨ᝷")):
                self.command_executor._url = bstack1l11ll_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥ᝸") + bstack1ll1l1l1l1_opy_ + bstack1l11ll_opy_ (u"ࠥ࠾࠽࠶࠯ࡸࡦ࠲࡬ࡺࡨࠢ᝹")
            else:
                self.command_executor._url = bstack1l11ll_opy_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࠨ᝺") + bstack1lll111ll_opy_ + bstack1l11ll_opy_ (u"ࠧ࠵ࡷࡥ࠱࡫ࡹࡧࠨ᝻")
            logger.debug(bstack11ll1l111_opy_.format(bstack1lll111ll_opy_))
        else:
            logger.debug(bstack1l1lllll11_opy_.format(bstack1l11ll_opy_ (u"ࠨࡏࡱࡶ࡬ࡱࡦࡲࠠࡉࡷࡥࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠢ᝼")))
    except Exception as e:
        logger.debug(bstack1l1lllll11_opy_.format(e))
    bstack1l1l1lll11_opy_ = self.session_id
    if bstack1l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ᝽") in bstack1ll1l1l1ll_opy_:
        threading.current_thread().bstackSessionId = self.session_id
        threading.current_thread().bstackSessionDriver = self
        threading.current_thread().bstackTestErrorMessages = []
        item = store.get(bstack1l11ll_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡪࡶࡨࡱࠬ᝾"), None)
        if item:
            bstack1lllll1lll1_opy_ = getattr(item, bstack1l11ll_opy_ (u"ࠩࡢࡸࡪࡹࡴࡠࡥࡤࡷࡪࡥࡳࡵࡣࡵࡸࡪࡪࠧ᝿"), False)
            if not getattr(item, bstack1l11ll_opy_ (u"ࠪࡣࡩࡸࡩࡷࡧࡵࠫក"), None) and bstack1lllll1lll1_opy_:
                setattr(store[bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢ࡭ࡹ࡫࡭ࠨខ")], bstack1l11ll_opy_ (u"ࠬࡥࡤࡳ࡫ࡹࡩࡷ࠭គ"), self)
        bstack111lll1_opy_.bstack11ll11lll_opy_(self)
    bstack1l1111l1l_opy_.append(self)
    if bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩឃ") in CONFIG and bstack1l11ll_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬង") in CONFIG[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫច")][bstack111l1llll_opy_]:
        bstack111l11l1_opy_ = CONFIG[bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬឆ")][bstack111l1llll_opy_][bstack1l11ll_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨជ")]
    logger.debug(bstack111llll1l_opy_.format(bstack1l1l1lll11_opy_))
def bstack1l1ll11l1_opy_(self, url):
    global bstack1l11l1l11l_opy_
    global CONFIG
    try:
        bstack1l11l1ll1_opy_(url, CONFIG, logger)
    except Exception as err:
        logger.debug(bstack1ll11l1l1l_opy_.format(str(err)))
    try:
        bstack1l11l1l11l_opy_(self, url)
    except Exception as e:
        try:
            bstack11111111_opy_ = str(e)
            if any(err_msg in bstack11111111_opy_ for err_msg in bstack1lll1ll1l_opy_):
                bstack1l11l1ll1_opy_(url, CONFIG, logger, True)
        except Exception as err:
            logger.debug(bstack1ll11l1l1l_opy_.format(str(err)))
        raise e
def bstack111lll1l1_opy_(item, when):
    global bstack1llll11lll_opy_
    try:
        bstack1llll11lll_opy_(item, when)
    except Exception as e:
        pass
def bstack111llllll_opy_(item, call, rep):
    global bstack1lll11lll_opy_
    global bstack1l1111l1l_opy_
    name = bstack1l11ll_opy_ (u"ࠫࠬឈ")
    try:
        if rep.when == bstack1l11ll_opy_ (u"ࠬࡩࡡ࡭࡮ࠪញ"):
            bstack1l1l1lll11_opy_ = threading.current_thread().bstackSessionId
            bstack1lllll1ll1l_opy_ = item.config.getoption(bstack1l11ll_opy_ (u"࠭ࡳ࡬࡫ࡳࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨដ"))
            try:
                if (str(bstack1lllll1ll1l_opy_).lower() != bstack1l11ll_opy_ (u"ࠧࡵࡴࡸࡩࠬឋ")):
                    name = str(rep.nodeid)
                    bstack1l1ll1ll11_opy_ = bstack1111l111_opy_(bstack1l11ll_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩឌ"), name, bstack1l11ll_opy_ (u"ࠩࠪឍ"), bstack1l11ll_opy_ (u"ࠪࠫណ"), bstack1l11ll_opy_ (u"ࠫࠬត"), bstack1l11ll_opy_ (u"ࠬ࠭ថ"))
                    os.environ[bstack1l11ll_opy_ (u"࠭ࡐ࡚ࡖࡈࡗ࡙ࡥࡔࡆࡕࡗࡣࡓࡇࡍࡆࠩទ")] = name
                    for driver in bstack1l1111l1l_opy_:
                        if bstack1l1l1lll11_opy_ == driver.session_id:
                            driver.execute_script(bstack1l1ll1ll11_opy_)
            except Exception as e:
                logger.debug(bstack1l11ll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࠣࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧធ").format(str(e)))
            try:
                bstack1ll1lll1l1_opy_(rep.outcome.lower())
                if rep.outcome.lower() != bstack1l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩន"):
                    status = bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩប") if rep.outcome.lower() == bstack1l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪផ") else bstack1l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫព")
                    reason = bstack1l11ll_opy_ (u"ࠬ࠭ភ")
                    if status == bstack1l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ម"):
                        reason = rep.longrepr.reprcrash.message
                        if (not threading.current_thread().bstackTestErrorMessages):
                            threading.current_thread().bstackTestErrorMessages = []
                        threading.current_thread().bstackTestErrorMessages.append(reason)
                    level = bstack1l11ll_opy_ (u"ࠧࡪࡰࡩࡳࠬយ") if status == bstack1l11ll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨរ") else bstack1l11ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨល")
                    data = name + bstack1l11ll_opy_ (u"ࠪࠤࡵࡧࡳࡴࡧࡧࠥࠬវ") if status == bstack1l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫឝ") else name + bstack1l11ll_opy_ (u"ࠬࠦࡦࡢ࡫࡯ࡩࡩࠧࠠࠨឞ") + reason
                    bstack1lll11llll_opy_ = bstack1111l111_opy_(bstack1l11ll_opy_ (u"࠭ࡡ࡯ࡰࡲࡸࡦࡺࡥࠨស"), bstack1l11ll_opy_ (u"ࠧࠨហ"), bstack1l11ll_opy_ (u"ࠨࠩឡ"), bstack1l11ll_opy_ (u"ࠩࠪអ"), level, data)
                    for driver in bstack1l1111l1l_opy_:
                        if bstack1l1l1lll11_opy_ == driver.session_id:
                            driver.execute_script(bstack1lll11llll_opy_)
            except Exception as e:
                logger.debug(bstack1l11ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡤࡱࡱࡸࡪࡾࡴࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧឣ").format(str(e)))
    except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡶࡤࡸࡪࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡦࡵࡷࠤࡸࡺࡡࡵࡷࡶ࠾ࠥࢁࡽࠨឤ").format(str(e)))
    bstack1lll11lll_opy_(item, call, rep)
notset = Notset()
def bstack1l1l1l11l_opy_(self, name: str, default=notset, skip: bool = False):
    global bstack1lll11l11l_opy_
    if str(name).lower() == bstack1l11ll_opy_ (u"ࠬࡪࡲࡪࡸࡨࡶࠬឥ"):
        return bstack1l11ll_opy_ (u"ࠨࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠧឦ")
    else:
        return bstack1lll11l11l_opy_(self, name, default, skip)
def bstack1l1l1lll1l_opy_(self):
    global CONFIG
    global bstack1l11l11l1l_opy_
    try:
        proxy = bstack11ll1ll1_opy_(CONFIG)
        if proxy:
            if proxy.endswith(bstack1l11ll_opy_ (u"ࠧ࠯ࡲࡤࡧࠬឧ")):
                proxies = bstack1ll111ll11_opy_(proxy, bstack1llllll11l_opy_())
                if len(proxies) > 0:
                    protocol, bstack1l11ll1l1l_opy_ = proxies.popitem()
                    if bstack1l11ll_opy_ (u"ࠣ࠼࠲࠳ࠧឨ") in bstack1l11ll1l1l_opy_:
                        return bstack1l11ll1l1l_opy_
                    else:
                        return bstack1l11ll_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥឩ") + bstack1l11ll1l1l_opy_
            else:
                return proxy
    except Exception as e:
        logger.error(bstack1l11ll_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡳࡱࡻࡽࠥࡻࡲ࡭ࠢ࠽ࠤࢀࢃࠢឪ").format(str(e)))
    return bstack1l11l11l1l_opy_(self)
def bstack1l1l1l111_opy_():
    return (bstack1l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡒࡵࡳࡽࡿࠧឫ") in CONFIG or bstack1l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩឬ") in CONFIG) and bstack1l1lll1l1_opy_() and bstack1ll11lll11_opy_() >= version.parse(
        bstack1ll1l1l1l_opy_)
def bstack11ll1111l_opy_(self,
               executablePath=None,
               channel=None,
               args=None,
               ignoreDefaultArgs=None,
               handleSIGINT=None,
               handleSIGTERM=None,
               handleSIGHUP=None,
               timeout=None,
               env=None,
               headless=None,
               devtools=None,
               proxy=None,
               downloadsPath=None,
               slowMo=None,
               tracesDir=None,
               chromiumSandbox=None,
               firefoxUserPrefs=None
               ):
    global CONFIG
    global bstack111l11l1_opy_
    global bstack1llll1ll11_opy_
    global bstack1ll1l1l1ll_opy_
    CONFIG[bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡘࡊࡋࠨឭ")] = str(bstack1ll1l1l1ll_opy_) + str(__version__)
    bstack111l1llll_opy_ = 0
    try:
        if bstack1llll1ll11_opy_ is True:
            bstack111l1llll_opy_ = int(os.environ.get(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧឮ")))
    except:
        bstack111l1llll_opy_ = 0
    CONFIG[bstack1l11ll_opy_ (u"ࠣ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢឯ")] = True
    bstack1ll1l111l1_opy_ = bstack111ll11l1_opy_(CONFIG, bstack111l1llll_opy_)
    logger.debug(bstack1ll11l1lll_opy_.format(str(bstack1ll1l111l1_opy_)))
    if CONFIG.get(bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ឰ")):
        bstack1llll111l1_opy_(bstack1ll1l111l1_opy_, bstack1llll11l11_opy_)
    if bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ឱ") in CONFIG and bstack1l11ll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩឲ") in CONFIG[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨឳ")][bstack111l1llll_opy_]:
        bstack111l11l1_opy_ = CONFIG[bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ឴")][bstack111l1llll_opy_][bstack1l11ll_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬ឵")]
    import urllib
    import json
    bstack1l1l1llll_opy_ = bstack1l11ll_opy_ (u"ࠨࡹࡶࡷ࠿࠵࠯ࡤࡦࡳ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࡃࡨࡧࡰࡴ࠿ࠪា") + urllib.parse.quote(json.dumps(bstack1ll1l111l1_opy_))
    browser = self.connect(bstack1l1l1llll_opy_)
    return browser
def bstack1ll1111ll1_opy_():
    global bstack1l11l1l11_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack11ll1111l_opy_
        bstack1l11l1l11_opy_ = True
    except Exception as e:
        pass
def bstack1llllll1lll_opy_():
    global CONFIG
    global bstack1llllll111_opy_
    global bstack1ll1l1l1l1_opy_
    global bstack1llll11l11_opy_
    global bstack1llll1ll11_opy_
    global bstack111l1lll_opy_
    CONFIG = json.loads(os.environ.get(bstack1l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡒࡒࡋࡏࡇࠨិ")))
    bstack1llllll111_opy_ = eval(os.environ.get(bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫី")))
    bstack1ll1l1l1l1_opy_ = os.environ.get(bstack1l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡌ࡚ࡈ࡟ࡖࡔࡏࠫឹ"))
    bstack1llll11111_opy_(CONFIG, bstack1llllll111_opy_)
    bstack111l1lll_opy_ = bstack1ll1l1111l_opy_.bstack1ll1ll111l_opy_(CONFIG, bstack111l1lll_opy_)
    global bstack111111111_opy_
    global bstack1111l11l_opy_
    global bstack111111ll1_opy_
    global bstack1l11ll1ll1_opy_
    global bstack1l1l111l1l_opy_
    global bstack11l11lll_opy_
    global bstack1llll111l_opy_
    global bstack1l11l1l11l_opy_
    global bstack1l11l11l1l_opy_
    global bstack1lll11l11l_opy_
    global bstack1llll11lll_opy_
    global bstack1lll11lll_opy_
    try:
        from selenium import webdriver
        from selenium.webdriver.remote.webdriver import WebDriver
        bstack111111111_opy_ = webdriver.Remote.__init__
        bstack1111l11l_opy_ = WebDriver.quit
        bstack1llll111l_opy_ = WebDriver.close
        bstack1l11l1l11l_opy_ = WebDriver.get
    except Exception as e:
        pass
    if (bstack1l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨឺ") in CONFIG or bstack1l11ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪុ") in CONFIG) and bstack1l1lll1l1_opy_():
        if bstack1ll11lll11_opy_() < version.parse(bstack1ll1l1l1l_opy_):
            logger.error(bstack111ll111_opy_.format(bstack1ll11lll11_opy_()))
        else:
            try:
                from selenium.webdriver.remote.remote_connection import RemoteConnection
                bstack1l11l11l1l_opy_ = RemoteConnection._get_proxy_url
            except Exception as e:
                logger.error(bstack1l1111l1_opy_.format(str(e)))
    try:
        from _pytest.config import Config
        bstack1lll11l11l_opy_ = Config.getoption
        from _pytest import runner
        bstack1llll11lll_opy_ = runner._update_current_test_var
    except Exception as e:
        logger.warn(e, bstack1ll1l1ll_opy_)
    try:
        from pytest_bdd import reporting
        bstack1lll11lll_opy_ = reporting.runtest_makereport
    except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡺ࡯ࠡࡴࡸࡲࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡷࡩࡸࡺࡳࠨូ"))
    bstack1llll11l11_opy_ = CONFIG.get(bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬួ"), {}).get(bstack1l11ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫើ"))
    bstack1llll1ll11_opy_ = True
    bstack1l1l1l1ll1_opy_(bstack1llll1ll1l_opy_)
if (bstack11l11ll11l_opy_()):
    bstack1llllll1lll_opy_()
@bstack1lll1l1_opy_(bstack11ll1l1_opy_=False)
def bstack1llll1lll1l_opy_(hook_name, event, bstack1llll1ll11l_opy_=None):
    if hook_name not in [bstack1l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࡡࡩࡹࡳࡩࡴࡪࡱࡱࠫឿ"), bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨៀ"), bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲࡵࡤࡶ࡮ࡨࠫេ"), bstack1l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࠨែ"), bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥࡣ࡭ࡣࡶࡷࠬៃ"), bstack1l11ll_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡧࡱࡧࡳࡴࠩោ"), bstack1l11ll_opy_ (u"ࠩࡶࡩࡹࡻࡰࡠ࡯ࡨࡸ࡭ࡵࡤࠨៅ"), bstack1l11ll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤࡳࡥࡵࡪࡲࡨࠬំ")]:
        return
    node = store[bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢ࡭ࡹ࡫࡭ࠨះ")]
    if hook_name in [bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲࡵࡤࡶ࡮ࡨࠫៈ"), bstack1l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࠨ៉")]:
        node = store[bstack1l11ll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠ࡯ࡲࡨࡺࡲࡥࡠ࡫ࡷࡩࡲ࠭៊")]
    elif hook_name in [bstack1l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟ࡤ࡮ࡤࡷࡸ࠭់"), bstack1l11ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࡣࡨࡲࡡࡴࡵࠪ៌")]:
        node = store[bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡨࡲࡡࡴࡵࡢ࡭ࡹ࡫࡭ࠨ៍")]
    if event == bstack1l11ll_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࠫ៎"):
        hook_type = bstack11ll111ll1_opy_(hook_name)
        uuid = uuid4().__str__()
        bstack1111l11_opy_ = {
            bstack1l11ll_opy_ (u"ࠬࡻࡵࡪࡦࠪ៏"): uuid,
            bstack1l11ll_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪ័"): current_time(),
            bstack1l11ll_opy_ (u"ࠧࡵࡻࡳࡩࠬ៑"): bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰ្࠭"),
            bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬ៓"): hook_type,
            bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡰࡤࡱࡪ࠭។"): hook_name
        }
        store[bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤ࡮࡯ࡰ࡭ࡢࡹࡺ࡯ࡤࠨ៕")].append(uuid)
        bstack1llllll1ll1_opy_ = node.nodeid
        if hook_type == bstack1l11ll_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡋࡁࡄࡊࠪ៖"):
            if not _11lll11_opy_.get(bstack1llllll1ll1_opy_, None):
                _11lll11_opy_[bstack1llllll1ll1_opy_] = {bstack1l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬៗ"): []}
            _11lll11_opy_[bstack1llllll1ll1_opy_][bstack1l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡸ࠭៘")].append(bstack1111l11_opy_[bstack1l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭៙")])
        _11lll11_opy_[bstack1llllll1ll1_opy_ + bstack1l11ll_opy_ (u"ࠩ࠰ࠫ៚") + hook_name] = bstack1111l11_opy_
        bstack1lllll11ll1_opy_(node, bstack1111l11_opy_, bstack1l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫ៛"))
    elif event == bstack1l11ll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࠪៜ"):
        bstack1llllll1_opy_ = node.nodeid + bstack1l11ll_opy_ (u"ࠬ࠳ࠧ៝") + hook_name
        _11lll11_opy_[bstack1llllll1_opy_][bstack1l11ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫ៞")] = current_time()
        bstack1lllll1l11l_opy_(_11lll11_opy_[bstack1llllll1_opy_][bstack1l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬ៟")])
        bstack1lllll11ll1_opy_(node, _11lll11_opy_[bstack1llllll1_opy_], bstack1l11ll_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪ០"), bstack1llllll1111_opy_=bstack1llll1ll11l_opy_)
def bstack1llll1lll11_opy_():
    global bstack1lllllll111_opy_
    if bstack1l111l1l_opy_():
        bstack1lllllll111_opy_ = bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩ࠭១")
    else:
        bstack1lllllll111_opy_ = bstack1l11ll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪ២")
@bstack111lll1_opy_.bstack11lll111ll_opy_
def bstack1lllll1llll_opy_():
    bstack1llll1lll11_opy_()
    if bstack1l1lll1l1_opy_():
        bstack11lll1l1l_opy_(bstack1l11lllll_opy_)
    try:
        bstack11llllll1l_opy_(bstack1llll1lll1l_opy_)
    except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣ࡬ࡴࡵ࡫ࡴࠢࡳࡥࡹࡩࡨ࠻ࠢࡾࢁࠧ៣").format(e))
bstack1lllll1llll_opy_()
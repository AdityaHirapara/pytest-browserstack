# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
import datetime
import threading
from uuid import uuid4
from itertools import zip_longest
from collections import OrderedDict
from robot.libraries.BuiltIn import BuiltIn
from browserstack_sdk.bstack1ll1ll1_opy_ import RobotHandler
from bstack_utils.capture import bstack11l11l1_opy_
from bstack_utils.bstack1lll1ll_opy_ import bstack1ll1lll_opy_, bstack1l11lll_opy_, bstack1l1ll1l_opy_
from bstack_utils.bstack11l1l11_opy_ import bstack111lll1_opy_
from bstack_utils.constants import *
from bstack_utils.helper import bstack1111111_opy_, current_time, Result, \
    bstack1lll1l1_opy_
class bstack_robot_listener:
    ROBOT_LISTENER_API_VERSION = 2
    store = {
        bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧࡶ"): [],
        bstack1l11ll_opy_ (u"ࠫ࡬ࡲ࡯ࡣࡣ࡯ࡣ࡭ࡵ࡯࡬ࡵࠪࡷ"): [],
        bstack1l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡢ࡬ࡴࡵ࡫ࡴࠩࡸ"): []
    }
    bstack1llll1l_opy_ = []
    bstack1111lll_opy_ = []
    @staticmethod
    def bstack111111_opy_(log):
        if not (log[bstack1l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧࡹ")] and log[bstack1l11ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨࡺ")].strip()):
            return
        active = bstack111lll1_opy_.bstack1lll111_opy_()
        log = {
            bstack1l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧࡻ"): log[bstack1l11ll_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨࡼ")],
            bstack1l11ll_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ࡽ"): datetime.datetime.utcnow().isoformat() + bstack1l11ll_opy_ (u"ࠫ࡟࠭ࡾ"),
            bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ࡿ"): log[bstack1l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧࢀ")],
        }
        if active:
            if active[bstack1l11ll_opy_ (u"ࠧࡵࡻࡳࡩࠬࢁ")] == bstack1l11ll_opy_ (u"ࠨࡪࡲࡳࡰ࠭ࢂ"):
                log[bstack1l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩࢃ")] = active[bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪࢄ")]
            elif active[bstack1l11ll_opy_ (u"ࠫࡹࡿࡰࡦࠩࢅ")] == bstack1l11ll_opy_ (u"ࠬࡺࡥࡴࡶࠪࢆ"):
                log[bstack1l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ࢇ")] = active[bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ࢈")]
        bstack111lll1_opy_.bstack1l1l1l1_opy_([log])
    def __init__(self):
        self.messages = Messages()
        self._1l1l11l_opy_ = None
        self._11lll1l_opy_ = None
        self._11lll11_opy_ = OrderedDict()
        self.bstack1l1lll1_opy_ = bstack11l11l1_opy_(self.bstack111111_opy_)
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def start_suite(self, name, attrs):
        self.messages.bstack1ll1111_opy_()
        if not self._11lll11_opy_.get(attrs.get(bstack1l11ll_opy_ (u"ࠨ࡫ࡧࠫࢉ")), None):
            self._11lll11_opy_[attrs.get(bstack1l11ll_opy_ (u"ࠩ࡬ࡨࠬࢊ"))] = {}
        bstack11l1l1l_opy_ = bstack1l1ll1l_opy_(
                bstack1lllll1l_opy_=attrs.get(bstack1l11ll_opy_ (u"ࠪ࡭ࡩ࠭ࢋ")),
                name=name,
                bstack111ll11_opy_=current_time(),
                file_path=os.path.relpath(attrs[bstack1l11ll_opy_ (u"ࠫࡸࡵࡵࡳࡥࡨࠫࢌ")], start=os.getcwd()) if attrs.get(bstack1l11ll_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬࢍ")) != bstack1l11ll_opy_ (u"࠭ࠧࢎ") else bstack1l11ll_opy_ (u"ࠧࠨ࢏"),
                framework=bstack1l11ll_opy_ (u"ࠨࡔࡲࡦࡴࡺࠧ࢐")
            )
        threading.current_thread().current_suite_id = attrs.get(bstack1l11ll_opy_ (u"ࠩ࡬ࡨࠬ࢑"), None)
        self._11lll11_opy_[attrs.get(bstack1l11ll_opy_ (u"ࠪ࡭ࡩ࠭࢒"))][bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧ࢓")] = bstack11l1l1l_opy_
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def end_suite(self, name, attrs):
        messages = self.messages.bstack1l1llll_opy_()
        self._11111l1_opy_(messages)
        for bstack11lllll_opy_ in self.bstack1llll1l_opy_:
            bstack11lllll_opy_[bstack1l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴࠧ࢔")][bstack1l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬ࢕")].extend(self.store[bstack1l11ll_opy_ (u"ࠧࡨ࡮ࡲࡦࡦࡲ࡟ࡩࡱࡲ࡯ࡸ࠭࢖")])
            bstack111lll1_opy_.bstack1lllllll_opy_(bstack11lllll_opy_)
        self.bstack1llll1l_opy_ = []
        self.store[bstack1l11ll_opy_ (u"ࠨࡩ࡯ࡳࡧࡧ࡬ࡠࡪࡲࡳࡰࡹࠧࢗ")] = []
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def start_test(self, name, attrs):
        self.bstack1l1lll1_opy_.start()
        if not self._11lll11_opy_.get(attrs.get(bstack1l11ll_opy_ (u"ࠩ࡬ࡨࠬ࢘")), None):
            self._11lll11_opy_[attrs.get(bstack1l11ll_opy_ (u"ࠪ࡭ࡩ࢙࠭"))] = {}
        driver = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴ࢚ࠪ"), None)
        bstack1lll1ll_opy_ = bstack1l1ll1l_opy_(
            bstack1lllll1l_opy_=attrs.get(bstack1l11ll_opy_ (u"ࠬ࡯ࡤࠨ࢛")),
            name=name,
            bstack111ll11_opy_=current_time(),
            file_path=os.path.relpath(attrs[bstack1l11ll_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭࢜")], start=os.getcwd()),
            scope=RobotHandler.bstack1l1l111_opy_(attrs.get(bstack1l11ll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧ࢝"), None)),
            framework=bstack1l11ll_opy_ (u"ࠨࡔࡲࡦࡴࡺࠧ࢞"),
            tags=attrs[bstack1l11ll_opy_ (u"ࠩࡷࡥ࡬ࡹࠧ࢟")],
            hooks=self.store[bstack1l11ll_opy_ (u"ࠪ࡫ࡱࡵࡢࡢ࡮ࡢ࡬ࡴࡵ࡫ࡴࠩࢠ")],
            bstack11l1ll1_opy_=bstack111lll1_opy_.bstack1l1111l_opy_(driver) if driver and driver.session_id else {},
            meta={},
            code=bstack1l11ll_opy_ (u"ࠦࢀࢃࠠ࡝ࡰࠣࡿࢂࠨࢡ").format(bstack1l11ll_opy_ (u"ࠧࠦࠢࢢ").join(attrs[bstack1l11ll_opy_ (u"࠭ࡴࡢࡩࡶࠫࢣ")]), name) if attrs[bstack1l11ll_opy_ (u"ࠧࡵࡣࡪࡷࠬࢤ")] else name
        )
        self._11lll11_opy_[attrs.get(bstack1l11ll_opy_ (u"ࠨ࡫ࡧࠫࢥ"))][bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬࢦ")] = bstack1lll1ll_opy_
        threading.current_thread().current_test_uuid = bstack1lll1ll_opy_.bstack1llll11_opy_()
        threading.current_thread().current_test_id = attrs.get(bstack1l11ll_opy_ (u"ࠪ࡭ࡩ࠭ࢧ"), None)
        self.bstack111l1ll_opy_(bstack1l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡺࡡࡳࡶࡨࡨࠬࢨ"), bstack1lll1ll_opy_)
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def end_test(self, name, attrs):
        self.bstack1l1lll1_opy_.reset()
        bstack11l11ll_opy_ = bstack1ll11l1_opy_.get(attrs.get(bstack1l11ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬࢩ")), bstack1l11ll_opy_ (u"࠭ࡳ࡬࡫ࡳࡴࡪࡪࠧࢪ"))
        self._11lll11_opy_[attrs.get(bstack1l11ll_opy_ (u"ࠧࡪࡦࠪࢫ"))][bstack1l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫࢬ")].stop(time=current_time(), duration=int(attrs.get(bstack1l11ll_opy_ (u"ࠩࡨࡰࡦࡶࡳࡦࡦࡷ࡭ࡲ࡫ࠧࢭ"), bstack1l11ll_opy_ (u"ࠪ࠴ࠬࢮ"))), result=Result(result=bstack11l11ll_opy_, exception=attrs.get(bstack1l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬࢯ")), bstack1l111ll_opy_=[attrs.get(bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ࢰ"))]))
        self.bstack111l1ll_opy_(bstack1l11ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨࢱ"), self._11lll11_opy_[attrs.get(bstack1l11ll_opy_ (u"ࠧࡪࡦࠪࢲ"))][bstack1l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫࢳ")], True)
        self.store[bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡩࡱࡲ࡯ࡸ࠭ࢴ")] = []
        threading.current_thread().current_test_uuid = None
        threading.current_thread().current_test_id = None
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def start_keyword(self, name, attrs):
        self.messages.bstack1ll1111_opy_()
        current_test_id = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡨࠬࢵ"), None)
        bstack11llll1_opy_ = current_test_id if bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢ࡭ࡩ࠭ࢶ"), None) else bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡳࡶ࡫ࡷࡩࡤ࡯ࡤࠨࢷ"), None)
        if attrs.get(bstack1l11ll_opy_ (u"࠭ࡴࡺࡲࡨࠫࢸ"), bstack1l11ll_opy_ (u"ࠧࠨࢹ")).lower() in [bstack1l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧࢺ"), bstack1l11ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࠫࢻ")]:
            hook_type = bstack111ll1l_opy_(attrs.get(bstack1l11ll_opy_ (u"ࠪࡸࡾࡶࡥࠨࢼ")), bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢࡹࡺ࡯ࡤࠨࢽ"), None))
            hook_name = bstack1l11ll_opy_ (u"ࠬࢁࡽࠨࢾ").format(attrs.get(bstack1l11ll_opy_ (u"࠭࡫ࡸࡰࡤࡱࡪ࠭ࢿ"), bstack1l11ll_opy_ (u"ࠧࠨࣀ")))
            if hook_type in [bstack1l11ll_opy_ (u"ࠨࡄࡈࡊࡔࡘࡅࡠࡃࡏࡐࠬࣁ"), bstack1l11ll_opy_ (u"ࠩࡄࡊ࡙ࡋࡒࡠࡃࡏࡐࠬࣂ")]:
                hook_name = bstack1l11ll_opy_ (u"ࠪ࡟ࢀࢃ࡝ࠡࡽࢀࠫࣃ").format(bstack1ll111l_opy_.get(hook_type), attrs.get(bstack1l11ll_opy_ (u"ࠫࡰࡽ࡮ࡢ࡯ࡨࠫࣄ"), bstack1l11ll_opy_ (u"ࠬ࠭ࣅ")))
            bstack1111l11_opy_ = bstack1l11lll_opy_(
                bstack1lllll1l_opy_=bstack11llll1_opy_ + bstack1l11ll_opy_ (u"࠭࠭ࠨࣆ") + attrs.get(bstack1l11ll_opy_ (u"ࠧࡵࡻࡳࡩࠬࣇ"), bstack1l11ll_opy_ (u"ࠨࠩࣈ")).lower(),
                name=hook_name,
                bstack111ll11_opy_=current_time(),
                file_path=os.path.relpath(attrs.get(bstack1l11ll_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩࣉ")), start=os.getcwd()),
                framework=bstack1l11ll_opy_ (u"ࠪࡖࡴࡨ࡯ࡵࠩ࣊"),
                tags=attrs[bstack1l11ll_opy_ (u"ࠫࡹࡧࡧࡴࠩ࣋")],
                scope=RobotHandler.bstack1l1l111_opy_(attrs.get(bstack1l11ll_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬ࣌"), None)),
                hook_type=hook_type,
                meta={}
            )
            threading.current_thread().current_hook_uuid = bstack1111l11_opy_.bstack1llll11_opy_()
            threading.current_thread().current_hook_id = bstack11llll1_opy_ + bstack1l11ll_opy_ (u"࠭࠭ࠨ࣍") + attrs.get(bstack1l11ll_opy_ (u"ࠧࡵࡻࡳࡩࠬ࣎"), bstack1l11ll_opy_ (u"ࠨ࣏ࠩ")).lower()
            self.store[bstack1l11ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢ࡬ࡴࡵ࡫ࡠࡷࡸ࡭ࡩ࣐࠭")] = [bstack1111l11_opy_.bstack1llll11_opy_()]
            if bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡࡸࡹ࡮ࡪ࣑ࠧ"), None):
                self.store[bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡ࡫ࡳࡴࡱࡳࠨ࣒")].append(bstack1111l11_opy_.bstack1llll11_opy_())
            else:
                self.store[bstack1l11ll_opy_ (u"ࠬ࡭࡬ࡰࡤࡤࡰࡤ࡮࡯ࡰ࡭ࡶ࣓ࠫ")].append(bstack1111l11_opy_.bstack1llll11_opy_())
            if bstack11llll1_opy_:
                self._11lll11_opy_[bstack11llll1_opy_ + bstack1l11ll_opy_ (u"࠭࠭ࠨࣔ") + attrs.get(bstack1l11ll_opy_ (u"ࠧࡵࡻࡳࡩࠬࣕ"), bstack1l11ll_opy_ (u"ࠨࠩࣖ")).lower()] = { bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬࣗ"): bstack1111l11_opy_ }
            bstack111lll1_opy_.bstack111l1ll_opy_(bstack1l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫࣘ"), bstack1111l11_opy_)
        else:
            bstack1l11l1l_opy_ = {
                bstack1l11ll_opy_ (u"ࠫ࡮ࡪࠧࣙ"): uuid4().__str__(),
                bstack1l11ll_opy_ (u"ࠬࡺࡥࡹࡶࠪࣚ"): bstack1l11ll_opy_ (u"࠭ࡻࡾࠢࡾࢁࠬࣛ").format(attrs.get(bstack1l11ll_opy_ (u"ࠧ࡬ࡹࡱࡥࡲ࡫ࠧࣜ")), attrs.get(bstack1l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ࣝ"), bstack1l11ll_opy_ (u"ࠩࠪࣞ"))) if attrs.get(bstack1l11ll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨࣟ"), []) else attrs.get(bstack1l11ll_opy_ (u"ࠫࡰࡽ࡮ࡢ࡯ࡨࠫ࣠")),
                bstack1l11ll_opy_ (u"ࠬࡹࡴࡦࡲࡢࡥࡷ࡭ࡵ࡮ࡧࡱࡸࠬ࣡"): attrs.get(bstack1l11ll_opy_ (u"࠭ࡡࡳࡩࡶࠫ࣢"), []),
                bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࣣࠫ"): current_time(),
                bstack1l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨࣤ"): bstack1l11ll_opy_ (u"ࠩࡳࡩࡳࡪࡩ࡯ࡩࠪࣥ"),
                bstack1l11ll_opy_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨࣦ"): attrs.get(bstack1l11ll_opy_ (u"ࠫࡩࡵࡣࠨࣧ"), bstack1l11ll_opy_ (u"ࠬ࠭ࣨ"))
            }
            if attrs.get(bstack1l11ll_opy_ (u"࠭࡬ࡪࡤࡱࡥࡲ࡫ࣩࠧ"), bstack1l11ll_opy_ (u"ࠧࠨ࣪")) != bstack1l11ll_opy_ (u"ࠨࠩ࣫"):
                bstack1l11l1l_opy_[bstack1l11ll_opy_ (u"ࠩ࡮ࡩࡾࡽ࡯ࡳࡦࠪ࣬")] = attrs.get(bstack1l11ll_opy_ (u"ࠪࡰ࡮ࡨ࡮ࡢ࡯ࡨ࣭ࠫ"))
            if not self.bstack1111lll_opy_:
                self._11lll11_opy_[self._1llllll_opy_()][bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧ࣮ࠧ")].add_step(bstack1l11l1l_opy_)
                threading.current_thread().current_step_uuid = bstack1l11l1l_opy_[bstack1l11ll_opy_ (u"ࠬ࡯ࡤࠨ࣯")]
            self.bstack1111lll_opy_.append(bstack1l11l1l_opy_)
    @bstack1lll1l1_opy_(bstack11ll1l1_opy_=True)
    def end_keyword(self, name, attrs):
        messages = self.messages.bstack1l1llll_opy_()
        self._11111l1_opy_(messages)
        current_test_id = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡵࡧࡶࡸࡤ࡯ࡤࠨࣰ"), None)
        bstack11llll1_opy_ = current_test_id if current_test_id else bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡵࡸ࡭ࡹ࡫࡟ࡪࡦࣱࠪ"), None)
        bstack11l1lll_opy_ = bstack1ll11l1_opy_.get(attrs.get(bstack1l11ll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨࣲ")), bstack1l11ll_opy_ (u"ࠩࡶ࡯࡮ࡶࡰࡦࡦࠪࣳ"))
        bstack111l1l1_opy_ = attrs.get(bstack1l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫࣴ"))
        if bstack11l1lll_opy_ != bstack1l11ll_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬࣵ") and not attrs.get(bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࣶ࠭")) and self._1l1l11l_opy_:
            bstack111l1l1_opy_ = self._1l1l11l_opy_
        bstack1111ll1_opy_ = Result(result=bstack11l1lll_opy_, exception=bstack111l1l1_opy_, bstack1l111ll_opy_=[bstack111l1l1_opy_])
        if attrs.get(bstack1l11ll_opy_ (u"࠭ࡴࡺࡲࡨࠫࣷ"), bstack1l11ll_opy_ (u"ࠧࠨࣸ")).lower() in [bstack1l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶࣹࠧ"), bstack1l11ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࣺࠫ")]:
            bstack11llll1_opy_ = current_test_id if current_test_id else bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡸࡻࡩࡵࡧࡢ࡭ࡩ࠭ࣻ"), None)
            if bstack11llll1_opy_:
                bstack1llllll1_opy_ = bstack11llll1_opy_ + bstack1l11ll_opy_ (u"ࠦ࠲ࠨࣼ") + attrs.get(bstack1l11ll_opy_ (u"ࠬࡺࡹࡱࡧࠪࣽ"), bstack1l11ll_opy_ (u"࠭ࠧࣾ")).lower()
                self._11lll11_opy_[bstack1llllll1_opy_][bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪࣿ")].stop(time=current_time(), duration=int(attrs.get(bstack1l11ll_opy_ (u"ࠨࡧ࡯ࡥࡵࡹࡥࡥࡶ࡬ࡱࡪ࠭ऀ"), bstack1l11ll_opy_ (u"ࠩ࠳ࠫँ"))), result=bstack1111ll1_opy_)
                bstack111lll1_opy_.bstack111l1ll_opy_(bstack1l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬं"), self._11lll11_opy_[bstack1llllll1_opy_][bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧः")])
        else:
            bstack11llll1_opy_ = current_test_id if current_test_id else bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡨࡰࡱ࡮ࡣ࡮ࡪࠧऄ"), None)
            if bstack11llll1_opy_ and len(self.bstack1111lll_opy_) == 1:
                current_step_uuid = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡴࡶࡨࡴࡤࡻࡵࡪࡦࠪअ"), None)
                self._11lll11_opy_[bstack11llll1_opy_][bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪआ")].bstack1l1l1ll_opy_(current_step_uuid, duration=int(attrs.get(bstack1l11ll_opy_ (u"ࠨࡧ࡯ࡥࡵࡹࡥࡥࡶ࡬ࡱࡪ࠭इ"), bstack1l11ll_opy_ (u"ࠩ࠳ࠫई"))), result=bstack1111ll1_opy_)
            else:
                self.bstack111l111_opy_(attrs)
            self.bstack1111lll_opy_.pop()
    def log_message(self, message):
        try:
            if message.get(bstack1l11ll_opy_ (u"ࠪ࡬ࡹࡳ࡬ࠨउ"), bstack1l11ll_opy_ (u"ࠫࡳࡵࠧऊ")) == bstack1l11ll_opy_ (u"ࠬࡿࡥࡴࠩऋ"):
                return
            self.messages.push(message)
            bstack1lllll1_opy_ = []
            if bstack111lll1_opy_.bstack1lll111_opy_():
                bstack1lllll1_opy_.append({
                    bstack1l11ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩऌ"): current_time(),
                    bstack1l11ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨऍ"): message.get(bstack1l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩऎ")),
                    bstack1l11ll_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨए"): message.get(bstack1l11ll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩऐ")),
                    **bstack111lll1_opy_.bstack1lll111_opy_()
                })
                if len(bstack1lllll1_opy_) > 0:
                    bstack111lll1_opy_.bstack1l1l1l1_opy_(bstack1lllll1_opy_)
        except Exception as err:
            pass
    def close(self):
        bstack111lll1_opy_.bstack11l1111_opy_()
    def bstack111l111_opy_(self, bstack111l11l_opy_):
        if not bstack111lll1_opy_.bstack1lll111_opy_():
            return
        kwname = bstack1l11ll_opy_ (u"ࠫࢀࢃࠠࡼࡿࠪऑ").format(bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠬࡱࡷ࡯ࡣࡰࡩࠬऒ")), bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"࠭ࡡࡳࡩࡶࠫओ"), bstack1l11ll_opy_ (u"ࠧࠨऔ"))) if bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭क"), []) else bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠩ࡮ࡻࡳࡧ࡭ࡦࠩख"))
        error_message = bstack1l11ll_opy_ (u"ࠥ࡯ࡼࡴࡡ࡮ࡧ࠽ࠤࡡࠨࡻ࠱ࡿ࡟ࠦࠥࢂࠠࡴࡶࡤࡸࡺࡹ࠺ࠡ࡞ࠥࡿ࠶ࢃ࡜ࠣࠢࡿࠤࡪࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡ࡞ࠥࡿ࠷ࢃ࡜ࠣࠤग").format(kwname, bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫघ")), str(bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ङ"))))
        bstack1l11ll1_opy_ = bstack1l11ll_opy_ (u"ࠨ࡫ࡸࡰࡤࡱࡪࡀࠠ࡝ࠤࡾ࠴ࢂࡢࠢࠡࡾࠣࡷࡹࡧࡴࡶࡵ࠽ࠤࡡࠨࡻ࠲ࡿ࡟ࠦࠧच").format(kwname, bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧछ")))
        bstack1ll1l1l_opy_ = error_message if bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩज")) else bstack1l11ll1_opy_
        bstack111llll_opy_ = {
            bstack1l11ll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬझ"): self.bstack1111lll_opy_[-1].get(bstack1l11ll_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧञ"), current_time()),
            bstack1l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬट"): bstack1ll1l1l_opy_,
            bstack1l11ll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫठ"): bstack1l11ll_opy_ (u"࠭ࡅࡓࡔࡒࡖࠬड") if bstack111l11l_opy_.get(bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧढ")) == bstack1l11ll_opy_ (u"ࠨࡈࡄࡍࡑ࠭ण") else bstack1l11ll_opy_ (u"ࠩࡌࡒࡋࡕࠧत"),
            **bstack111lll1_opy_.bstack1lll111_opy_()
        }
        bstack111lll1_opy_.bstack1l1l1l1_opy_([bstack111llll_opy_])
    def _1llllll_opy_(self):
        for bstack1lllll1l_opy_ in reversed(self._11lll11_opy_):
            bstack11111ll_opy_ = bstack1lllll1l_opy_
            data = self._11lll11_opy_[bstack1lllll1l_opy_][bstack1l11ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡦࡤࡸࡦ࠭थ")]
            if isinstance(data, bstack1l11lll_opy_):
                if not bstack1l11ll_opy_ (u"ࠫࡊࡇࡃࡉࠩद") in data.bstack1l1ll11_opy_():
                    return bstack11111ll_opy_
            else:
                return bstack11111ll_opy_
    def _11111l1_opy_(self, messages):
        try:
            bstack1l11111_opy_ = BuiltIn().get_variable_value(bstack1l11ll_opy_ (u"ࠧࠪࡻࡍࡑࡊࠤࡑࡋࡖࡆࡎࢀࠦध")) in (bstack1ll1l11_opy_.DEBUG, bstack1ll1l11_opy_.TRACE)
            for message, bstack1l11l11_opy_ in zip_longest(messages, messages[1:]):
                name = message.get(bstack1l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧन"))
                level = message.get(bstack1l11ll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ऩ"))
                if level == bstack1ll1l11_opy_.FAIL:
                    self._1l1l11l_opy_ = name or self._1l1l11l_opy_
                    self._11lll1l_opy_ = bstack1l11l11_opy_.get(bstack1l11ll_opy_ (u"ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤप")) if bstack1l11111_opy_ and bstack1l11l11_opy_ else self._11lll1l_opy_
        except:
            pass
    @classmethod
    def bstack111l1ll_opy_(self, event: str, bstack11ll11l_opy_: bstack1ll1lll_opy_, bstack1lllll11_opy_=False):
        if event == bstack1l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫफ"):
            bstack11ll11l_opy_.set(hooks=self.store[bstack1l11ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡪࡲࡳࡰࡹࠧब")])
        if event == bstack1l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡱࡩࡱࡲࡨࡨࠬभ"):
            event = bstack1l11ll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧम")
        if bstack1lllll11_opy_:
            bstack1111l1l_opy_ = {
                bstack1l11ll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪय"): event,
                bstack11ll11l_opy_.bstack1ll11ll_opy_(): bstack11ll11l_opy_.bstack1l111l1_opy_(event)
            }
            self.bstack1llll1l_opy_.append(bstack1111l1l_opy_)
        else:
            bstack111lll1_opy_.bstack111l1ll_opy_(event, bstack11ll11l_opy_)
class Messages:
    def __init__(self):
        self._11ll111_opy_ = []
    def bstack1ll1111_opy_(self):
        self._11ll111_opy_.append([])
    def bstack1l1llll_opy_(self):
        return self._11ll111_opy_.pop() if self._11ll111_opy_ else list()
    def push(self, message):
        self._11ll111_opy_[-1].append(message) if self._11ll111_opy_ else self._11ll111_opy_.append([message])
class bstack1ll1l11_opy_:
    FAIL = bstack1l11ll_opy_ (u"ࠧࡇࡃࡌࡐࠬर")
    ERROR = bstack1l11ll_opy_ (u"ࠨࡇࡕࡖࡔࡘࠧऱ")
    WARNING = bstack1l11ll_opy_ (u"࡚ࠩࡅࡗࡔࠧल")
    bstack11ll1ll_opy_ = bstack1l11ll_opy_ (u"ࠪࡍࡓࡌࡏࠨळ")
    DEBUG = bstack1l11ll_opy_ (u"ࠫࡉࡋࡂࡖࡉࠪऴ")
    TRACE = bstack1l11ll_opy_ (u"࡚ࠬࡒࡂࡅࡈࠫव")
    bstack11l111l_opy_ = [FAIL, ERROR]
def bstack111111l_opy_(bstack1lll11l_opy_):
    if not bstack1lll11l_opy_:
        return None
    if bstack1lll11l_opy_.get(bstack1l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡩࡧࡴࡢࠩश"), None):
        return getattr(bstack1lll11l_opy_[bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪष")], bstack1l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭स"), None)
    return bstack1lll11l_opy_.get(bstack1l11ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧह"), None)
def bstack111ll1l_opy_(hook_type, current_test_uuid):
    if hook_type.lower() not in [bstack1l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࠩऺ"), bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳ࠭ऻ")]:
        return
    if hook_type.lower() == bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳ़ࠫ"):
        if current_test_uuid is None:
            return bstack1l11ll_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡁࡍࡎࠪऽ")
        else:
            return bstack1l11ll_opy_ (u"ࠧࡃࡇࡉࡓࡗࡋ࡟ࡆࡃࡆࡌࠬा")
    elif hook_type.lower() == bstack1l11ll_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࠪि"):
        if current_test_uuid is None:
            return bstack1l11ll_opy_ (u"ࠩࡄࡊ࡙ࡋࡒࡠࡃࡏࡐࠬी")
        else:
            return bstack1l11ll_opy_ (u"ࠪࡅࡋ࡚ࡅࡓࡡࡈࡅࡈࡎࠧु")
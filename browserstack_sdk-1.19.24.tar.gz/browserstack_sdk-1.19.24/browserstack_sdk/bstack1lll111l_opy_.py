# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import multiprocessing
import os
import json
from time import sleep
import bstack_utils.bstack1lll11l1_opy_ as bstack1lll1ll1_opy_
from browserstack_sdk.bstack1ll1llll_opy_ import *
from bstack_utils.config import Config
from bstack_utils.messages import bstack1ll1l1ll_opy_
class bstack1lll1l1l_opy_:
    def __init__(self, args, logger, bstack1ll11lll_opy_, bstack1lll1lll_opy_):
        self.args = args
        self.logger = logger
        self.bstack1ll11lll_opy_ = bstack1ll11lll_opy_
        self.bstack1lll1lll_opy_ = bstack1lll1lll_opy_
        self._prepareconfig = None
        self.Config = None
        self.runner = None
        self.bstack1ll11111_opy_ = []
        self.bstack1l1llll1_opy_ = None
        self.bstack1lll11ll_opy_ = []
        self.bstack1llll1l1_opy_ = self.bstack1l1lllll_opy_()
        self.bstack1l1ll1ll_opy_ = -1
    def bstack1ll111ll_opy_(self, bstack1ll1l11l_opy_):
        self.parse_args()
        self.bstack1ll11l11_opy_()
        self.bstack1ll1ll1l_opy_(bstack1ll1l11l_opy_)
    @staticmethod
    def version():
        import pytest
        return pytest.__version__
    @staticmethod
    def bstack1ll11ll1_opy_():
        import importlib
        if getattr(importlib, bstack1l11ll_opy_ (u"ࠫ࡫࡯࡮ࡥࡡ࡯ࡳࡦࡪࡥࡳࠩू"), False):
            bstack1l1lll11_opy_ = importlib.find_loader(bstack1l11ll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࡤࡹࡥ࡭ࡧࡱ࡭ࡺࡳࠧृ"))
        else:
            bstack1l1lll11_opy_ = importlib.util.find_spec(bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹࡥࡳࡦ࡮ࡨࡲ࡮ࡻ࡭ࠨॄ"))
    def bstack1ll1ll11_opy_(self, arg):
        if arg in self.args:
            i = self.args.index(arg)
            self.args.pop(i + 1)
            self.args.pop(i)
    def parse_args(self):
        self.bstack1l1ll1ll_opy_ = -1
        if bstack1l11ll_opy_ (u"ࠧࡱࡣࡵࡥࡱࡲࡥ࡭ࡵࡓࡩࡷࡖ࡬ࡢࡶࡩࡳࡷࡳࠧॅ") in self.bstack1ll11lll_opy_:
            self.bstack1l1ll1ll_opy_ = int(self.bstack1ll11lll_opy_[bstack1l11ll_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨॆ")])
        try:
            bstack1ll111l1_opy_ = [bstack1l11ll_opy_ (u"ࠩ࠰࠱ࡩࡸࡩࡷࡧࡵࠫे"), bstack1l11ll_opy_ (u"ࠪ࠱࠲ࡶ࡬ࡶࡩ࡬ࡲࡸ࠭ै"), bstack1l11ll_opy_ (u"ࠫ࠲ࡶࠧॉ")]
            if self.bstack1l1ll1ll_opy_ >= 0:
                bstack1ll111l1_opy_.extend([bstack1l11ll_opy_ (u"ࠬ࠳࠭࡯ࡷࡰࡴࡷࡵࡣࡦࡵࡶࡩࡸ࠭ॊ"), bstack1l11ll_opy_ (u"࠭࠭࡯ࠩो")])
            for arg in bstack1ll111l1_opy_:
                self.bstack1ll1ll11_opy_(arg)
        except Exception as exc:
            self.logger.error(str(exc))
    def get_args(self):
        return self.args
    def bstack1ll11l11_opy_(self):
        bstack1l1llll1_opy_ = [os.path.normpath(item) for item in self.args]
        self.bstack1l1llll1_opy_ = bstack1l1llll1_opy_
        return bstack1l1llll1_opy_
    def bstack1l1ll1l1_opy_(self):
        try:
            from _pytest.config import _prepareconfig
            from _pytest.config import Config
            from _pytest import runner
            self.bstack1ll11ll1_opy_()
            self._prepareconfig = _prepareconfig
            self.Config = Config
            self.runner = runner
        except Exception as e:
            self.logger.warn(e, bstack1ll1l1ll_opy_)
    def bstack1ll1ll1l_opy_(self, bstack1ll1l11l_opy_):
        bstack1llll1ll_opy_ = Config.get_instance()
        if bstack1ll1l11l_opy_:
            self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠧ࠮࠯ࡶ࡯࡮ࡶࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫौ"))
            self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠨࡖࡵࡹࡪ्࠭"))
        if bstack1llll1ll_opy_.bstack1l1ll11l_opy_():
            self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠩ࠰࠱ࡸࡱࡩࡱࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠨॎ"))
            self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠪࡘࡷࡻࡥࠨॏ"))
        self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠫ࠲ࡶࠧॐ"))
        self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࡤࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡴࡱࡻࡧࡪࡰࠪ॑"))
        self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"࠭࠭࠮ࡦࡵ࡭ࡻ࡫ࡲࠨ॒"))
        self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠧࡤࡪࡵࡳࡲ࡫ࠧ॓"))
        if self.bstack1l1ll1ll_opy_ > 1:
            self.bstack1l1llll1_opy_.append(bstack1l11ll_opy_ (u"ࠨ࠯ࡱࠫ॔"))
            self.bstack1l1llll1_opy_.append(str(self.bstack1l1ll1ll_opy_))
    def bstack1ll1lll1_opy_(self):
        bstack1lll11ll_opy_ = []
        for spec in self.bstack1ll11111_opy_:
            bstack1l1lll1l_opy_ = [spec]
            bstack1l1lll1l_opy_ += self.bstack1l1llll1_opy_
            bstack1lll11ll_opy_.append(bstack1l1lll1l_opy_)
        self.bstack1lll11ll_opy_ = bstack1lll11ll_opy_
        return bstack1lll11ll_opy_
    def bstack1l1lllll_opy_(self):
        try:
            from pytest_bdd import reporting
            self.bstack1llll1l1_opy_ = True
            return True
        except Exception as e:
            self.bstack1llll1l1_opy_ = False
        return self.bstack1llll1l1_opy_
    def bstack1l1ll111_opy_(self, bstack1lll1111_opy_, bstack1ll111ll_opy_):
        bstack1ll111ll_opy_[bstack1l11ll_opy_ (u"ࠩࡆࡓࡓࡌࡉࡈࠩॕ")] = self.bstack1ll11lll_opy_
        multiprocessing.set_start_method(bstack1l11ll_opy_ (u"ࠪࡷࡵࡧࡷ࡯ࠩॖ"))
        if bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧॗ") in self.bstack1ll11lll_opy_:
            bstack1llll111_opy_ = []
            manager = multiprocessing.Manager()
            bstack1ll1111l_opy_ = manager.list()
            for index, platform in enumerate(self.bstack1ll11lll_opy_[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨक़")]):
                bstack1llll111_opy_.append(multiprocessing.Process(name=str(index),
                                                           target=bstack1lll1111_opy_,
                                                           args=(self.bstack1l1llll1_opy_, bstack1ll111ll_opy_, bstack1ll1111l_opy_)))
            i = 0
            bstack1ll11l1l_opy_ = len(self.bstack1ll11lll_opy_[bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩख़")])
            for t in bstack1llll111_opy_:
                os.environ[bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧग़")] = str(i)
                os.environ[bstack1l11ll_opy_ (u"ࠨࡅࡘࡖࡗࡋࡎࡕࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡉࡇࡔࡂࠩज़")] = json.dumps(self.bstack1ll11lll_opy_[bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬड़")][i % bstack1ll11l1l_opy_])
                i += 1
                t.start()
            for t in bstack1llll111_opy_:
                t.join()
            return list(bstack1ll1111l_opy_)
    @staticmethod
    def bstack1lll1l11_opy_(driver, bstack1llll11l_opy_, logger, item=None, wait=False):
        item = item or getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡸࡪࡳࠧढ़"), None)
        if item and getattr(item, bstack1l11ll_opy_ (u"ࠫࡤࡧ࠱࠲ࡻࡢࡸࡪࡹࡴࡠࡥࡤࡷࡪ࠭फ़"), None) and not getattr(item, bstack1l11ll_opy_ (u"ࠬࡥࡡ࠲࠳ࡼࡣࡸࡺ࡯ࡱࡡࡧࡳࡳ࡫ࠧय़"), False):
            logger.info(
                bstack1l11ll_opy_ (u"ࠨࡁࡶࡶࡲࡱࡦࡺࡥࠡࡶࡨࡷࡹࠦࡣࡢࡵࡨࠤࡪࡾࡥࡤࡷࡷ࡭ࡴࡴࠠࡩࡣࡶࠤࡪࡴࡤࡦࡦ࠱ࠤࡕࡸ࡯ࡤࡧࡶࡷ࡮ࡴࡧࠡࡨࡲࡶࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡺࡥࡴࡶ࡬ࡲ࡬ࠦࡩࡴࠢࡸࡲࡩ࡫ࡲࡸࡣࡼ࠲ࠧॠ"))
            bstack1ll1l1l1_opy_ = item.cls.__name__ if not item.cls is None else None
            bstack1lll1ll1_opy_.bstack1ll1l111_opy_(driver, bstack1ll1l1l1_opy_, item.name, item.module.__name__, item.path, bstack1llll11l_opy_)
            item._a11y_stop_done = True
            if wait:
                sleep(2)
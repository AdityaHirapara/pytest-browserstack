# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
class RobotHandler():
    def __init__(self, args, logger, bstack1ll11lll_opy_, bstack1lll1lll_opy_):
        self.args = args
        self.logger = logger
        self.bstack1ll11lll_opy_ = bstack1ll11lll_opy_
        self.bstack1lll1lll_opy_ = bstack1lll1lll_opy_
    @staticmethod
    def version():
        import robot
        return robot.__version__
    @staticmethod
    def bstack1l1l111_opy_(bstack1l111ll1ll_opy_):
        bstack1l111llll1_opy_ = []
        if bstack1l111ll1ll_opy_:
            tokens = str(os.path.basename(bstack1l111ll1ll_opy_)).split(bstack1l11ll_opy_ (u"ࠥࡣࠧอ"))
            camelcase_name = bstack1l11ll_opy_ (u"ࠦࠥࠨฮ").join(t.title() for t in tokens)
            suite_name, bstack1l111lll11_opy_ = os.path.splitext(camelcase_name)
            bstack1l111llll1_opy_.append(suite_name)
        return bstack1l111llll1_opy_
    @staticmethod
    def bstack1l111lll1l_opy_(typename):
        if bstack1l11ll_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࠣฯ") in typename:
            return bstack1l11ll_opy_ (u"ࠨࡁࡴࡵࡨࡶࡹ࡯࡯࡯ࡇࡵࡶࡴࡸࠢะ")
        return bstack1l11ll_opy_ (u"ࠢࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠣั")
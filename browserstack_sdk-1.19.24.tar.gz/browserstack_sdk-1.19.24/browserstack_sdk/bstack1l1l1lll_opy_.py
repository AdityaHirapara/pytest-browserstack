# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import os
import json
import logging
logger = logging.getLogger(__name__)
class BrowserStackSdk:
    def get_current_platform():
        bstack1l1l1ll1_opy_ = {}
        bstack1l1l1l1l_opy_ = os.environ.get(bstack1l11ll_opy_ (u"ࠧࡄࡗࡕࡖࡊࡔࡔࡠࡒࡏࡅ࡙ࡌࡏࡓࡏࡢࡈࡆ࡚ࡁࠨॡ"), bstack1l11ll_opy_ (u"ࠨࠩॢ"))
        if not bstack1l1l1l1l_opy_:
            return bstack1l1l1ll1_opy_
        try:
            bstack1l1l1l11_opy_ = json.loads(bstack1l1l1l1l_opy_)
            if bstack1l11ll_opy_ (u"ࠤࡲࡷࠧॣ") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠥࡳࡸࠨ।")] = bstack1l1l1l11_opy_[bstack1l11ll_opy_ (u"ࠦࡴࡹࠢ॥")]
            if bstack1l11ll_opy_ (u"ࠧࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ०") in bstack1l1l1l11_opy_ or bstack1l11ll_opy_ (u"ࠨ࡯ࡴࡘࡨࡶࡸ࡯࡯࡯ࠤ१") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠢࡰࡵ࡙ࡩࡷࡹࡩࡰࡰࠥ२")] = bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ३"), bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠤࡲࡷ࡛࡫ࡲࡴ࡫ࡲࡲࠧ४")))
            if bstack1l11ll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵࠦ५") in bstack1l1l1l11_opy_ or bstack1l11ll_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠤ६") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠥ७")] = bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠨࡢࡳࡱࡺࡷࡪࡸࠢ८"), bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠢࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠧ९")))
            if bstack1l11ll_opy_ (u"ࠣࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠥ॰") in bstack1l1l1l11_opy_ or bstack1l11ll_opy_ (u"ࠤࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠥॱ") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠥࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠦॲ")] = bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠦࡧࡸ࡯ࡸࡵࡨࡶࡤࡼࡥࡳࡵ࡬ࡳࡳࠨॳ"), bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠧࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳࠨॴ")))
            if bstack1l11ll_opy_ (u"ࠨࡤࡦࡸ࡬ࡧࡪࠨॵ") in bstack1l1l1l11_opy_ or bstack1l11ll_opy_ (u"ࠢࡥࡧࡹ࡭ࡨ࡫ࡎࡢ࡯ࡨࠦॶ") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠣࡦࡨࡺ࡮ࡩࡥࡏࡣࡰࡩࠧॷ")] = bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠤࡧࡩࡻ࡯ࡣࡦࠤॸ"), bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠥࡨࡪࡼࡩࡤࡧࡑࡥࡲ࡫ࠢॹ")))
            if bstack1l11ll_opy_ (u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨॺ") in bstack1l1l1l11_opy_ or bstack1l11ll_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࡎࡢ࡯ࡨࠦॻ") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡏࡣࡰࡩࠧॼ")] = bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠤॽ"), bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡑࡥࡲ࡫ࠢॾ")))
            if bstack1l11ll_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧॿ") in bstack1l1l1l11_opy_ or bstack1l11ll_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠧঀ") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳࠨঁ")] = bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣং"), bstack1l1l1l11_opy_.get(bstack1l11ll_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠣঃ")))
            if bstack1l11ll_opy_ (u"ࠢࡤࡷࡶࡸࡴࡳࡖࡢࡴ࡬ࡥࡧࡲࡥࡴࠤ঄") in bstack1l1l1l11_opy_:
                bstack1l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠣࡥࡸࡷࡹࡵ࡭ࡗࡣࡵ࡭ࡦࡨ࡬ࡦࡵࠥঅ")] = bstack1l1l1l11_opy_[bstack1l11ll_opy_ (u"ࠤࡦࡹࡸࡺ࡯࡮ࡘࡤࡶ࡮ࡧࡢ࡭ࡧࡶࠦআ")]
        except Exception as error:
            logger.error(bstack1l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡣࡶࡴࡵࡩࡳࡺࠠࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠢࡧࡥࡹࡧ࠺ࠡࠤই") +  str(error))
        return bstack1l1l1ll1_opy_
# coding: UTF-8
import sys
bstack11l1_opy_ = sys.version_info [0] == 2
bstack111ll1_opy_ = 2048
bstack1111l_opy_ = 7
def bstack1l11ll_opy_ (bstack11lll_opy_):
    global bstack1ll1l1_opy_
    stringNr = ord (bstack11lll_opy_ [-1])
    bstack1ll11l_opy_ = bstack11lll_opy_ [:-1]
    bstack1111l1_opy_ = stringNr % len (bstack1ll11l_opy_)
    bstack1l1ll_opy_ = bstack1ll11l_opy_ [:bstack1111l1_opy_] + bstack1ll11l_opy_ [bstack1111l1_opy_:]
    if bstack11l1_opy_:
        bstack11l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    else:
        bstack11l1ll_opy_ = str () .join ([chr (ord (char) - bstack111ll1_opy_ - (bstack111ll_opy_ + stringNr) % bstack1111l_opy_) for bstack111ll_opy_, char in enumerate (bstack1l1ll_opy_)])
    return eval (bstack11l1ll_opy_)
import atexit
import os
import signal
import sys
import yaml
import requests
import logging
import threading
import socket
import datetime
import string
import random
import json
import collections.abc
import re
import multiprocessing
import traceback
import copy
import tempfile
from packaging import version
from browserstack.local import Local
from urllib.parse import urlparse
from dotenv import load_dotenv
from bstack_utils.constants import *
from bstack_utils.percy import *
from browserstack_sdk.bstack1l1l1lll_opy_ import *
from bstack_utils.percy_sdk import PercySDK
from bstack_utils.bstack1ll11l11ll_opy_ import bstack1ll1l1ll1l_opy_
import time
import requests
def bstack1lll1llll_opy_():
  global CONFIG
  headers = {
        bstack1l11ll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪঈ"): bstack1l11ll_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨউ"),
      }
  proxies = bstack1111l1111_opy_(CONFIG, bstack1ll1l1l111_opy_)
  try:
    response = requests.get(bstack1ll1l1l111_opy_, headers=headers, proxies=proxies, timeout=5)
    if response.json():
      bstack1l1l1l1l11_opy_ = response.json()[bstack1l11ll_opy_ (u"࠭ࡨࡶࡤࡶࠫঊ")]
      logger.debug(bstack1l11l111ll_opy_.format(response.json()))
      return bstack1l1l1l1l11_opy_
    else:
      logger.debug(bstack1ll11lll1l_opy_.format(bstack1l11ll_opy_ (u"ࠢࡓࡧࡶࡴࡴࡴࡳࡦࠢࡍࡗࡔࡔࠠࡱࡣࡵࡷࡪࠦࡥࡳࡴࡲࡶࠥࠨঋ")))
  except Exception as e:
    logger.debug(bstack1ll11lll1l_opy_.format(e))
def bstack1lll11l111_opy_(hub_url):
  global CONFIG
  url = bstack1l11ll_opy_ (u"ࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࠥঌ")+  hub_url + bstack1l11ll_opy_ (u"ࠤ࠲ࡧ࡭࡫ࡣ࡬ࠤ঍")
  headers = {
        bstack1l11ll_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ঎"): bstack1l11ll_opy_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧএ"),
      }
  proxies = bstack1111l1111_opy_(CONFIG, url)
  try:
    start_time = time.perf_counter()
    requests.get(url, headers=headers, proxies=proxies, timeout=5)
    latency = time.perf_counter() - start_time
    logger.debug(bstack1l11l1ll_opy_.format(hub_url, latency))
    return dict(hub_url=hub_url, latency=latency)
  except Exception as e:
    logger.debug(bstack1lll1lll1l_opy_.format(hub_url, e))
def bstack1l11l11111_opy_():
  try:
    global bstack1ll1l1l1l1_opy_
    bstack1l1l1l1l11_opy_ = bstack1lll1llll_opy_()
    bstack1l1ll1lll_opy_ = []
    results = []
    for bstack1l1l1l1l1l_opy_ in bstack1l1l1l1l11_opy_:
      bstack1l1ll1lll_opy_.append(bstack1111lll11_opy_(target=bstack1lll11l111_opy_,args=(bstack1l1l1l1l1l_opy_,)))
    for t in bstack1l1ll1lll_opy_:
      t.start()
    for t in bstack1l1ll1lll_opy_:
      results.append(t.join())
    bstack1111lllll_opy_ = {}
    for item in results:
      hub_url = item[bstack1l11ll_opy_ (u"ࠬ࡮ࡵࡣࡡࡸࡶࡱ࠭ঐ")]
      latency = item[bstack1l11ll_opy_ (u"࠭࡬ࡢࡶࡨࡲࡨࡿࠧ঑")]
      bstack1111lllll_opy_[hub_url] = latency
    bstack1l1lll1l11_opy_ = min(bstack1111lllll_opy_, key= lambda x: bstack1111lllll_opy_[x])
    bstack1ll1l1l1l1_opy_ = bstack1l1lll1l11_opy_
    logger.debug(bstack1l1l1l1ll_opy_.format(bstack1l1lll1l11_opy_))
  except Exception as e:
    logger.debug(bstack1ll11l1l11_opy_.format(e))
from bstack_utils.messages import *
from bstack_utils import bstack1ll1l1111l_opy_
from bstack_utils.config import Config
from bstack_utils.helper import bstack111l111l1_opy_, bstack1l111ll11_opy_, bstack1111ll1ll_opy_, bstack1111111_opy_, bstack11l1l1111_opy_, \
  Notset, bstack1l11ll1l11_opy_, \
  bstack1llllllll_opy_, bstack1llll1lll1_opy_, bstack111lllll1_opy_, bstack1lll11111_opy_, bstack1l111l1l_opy_, bstack1l1lll1l1_opy_, \
  bstack11ll1lll_opy_, \
  bstack1ll1lll11l_opy_, bstack1l1lllll1l_opy_, bstack1lll1l1ll_opy_, bstack1lllll1lll_opy_, \
  bstack1l111111l_opy_, bstack1lllll11l1_opy_, is_true
from bstack_utils.bstack1ll1llll1l_opy_ import bstack1llll11ll_opy_
from bstack_utils.bstack1l1111ll_opy_ import bstack11lll1l1l_opy_
from bstack_utils.bstack1ll1llll11_opy_ import bstack1l11lll1l_opy_, bstack1l1111l11_opy_
from bstack_utils.bstack11l1l11_opy_ import bstack111lll1_opy_
from bstack_utils.bstack1lll1ll1l1_opy_ import bstack1lll1ll1l1_opy_
from bstack_utils.proxy import bstack1ll111ll11_opy_, bstack1111l1111_opy_, bstack11ll1ll1_opy_, bstack1lll111l1l_opy_
import bstack_utils.bstack1lll11l1_opy_ as bstack1lll1ll1_opy_
from browserstack_sdk.bstack1lll111l_opy_ import *
from browserstack_sdk.bstack1ll1llll_opy_ import *
from bstack_utils.bstack111ll111l_opy_ import bstack1ll1lll1l1_opy_
bstack111lll111_opy_ = bstack1l11ll_opy_ (u"ࠧࠡࠢ࠲࠮ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠭࠳ࡡࡴࠠࠡ࡫ࡩࠬࡵࡧࡧࡦࠢࡀࡁࡂࠦࡶࡰ࡫ࡧࠤ࠵࠯ࠠࡼ࡞ࡱࠤࠥࠦࡴࡳࡻࡾࡠࡳࠦࡣࡰࡰࡶࡸࠥ࡬ࡳࠡ࠿ࠣࡶࡪࡷࡵࡪࡴࡨࠬࡡ࠭ࡦࡴ࡞ࠪ࠭ࡀࡢ࡮ࠡࠢࠣࠤࠥ࡬ࡳ࠯ࡣࡳࡴࡪࡴࡤࡇ࡫࡯ࡩࡘࡿ࡮ࡤࠪࡥࡷࡹࡧࡣ࡬ࡡࡳࡥࡹ࡮ࠬࠡࡌࡖࡓࡓ࠴ࡳࡵࡴ࡬ࡲ࡬࡯ࡦࡺࠪࡳࡣ࡮ࡴࡤࡦࡺࠬࠤ࠰ࠦࠢ࠻ࠤࠣ࠯ࠥࡐࡓࡐࡐ࠱ࡷࡹࡸࡩ࡯ࡩ࡬ࡪࡾ࠮ࡊࡔࡑࡑ࠲ࡵࡧࡲࡴࡧࠫࠬࡦࡽࡡࡪࡶࠣࡲࡪࡽࡐࡢࡩࡨ࠶࠳࡫ࡶࡢ࡮ࡸࡥࡹ࡫ࠨࠣࠪࠬࠤࡂࡄࠠࡼࡿࠥ࠰ࠥࡢࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡨࡧࡷࡗࡪࡹࡳࡪࡱࡱࡈࡪࡺࡡࡪ࡮ࡶࠦࢂࡢࠧࠪࠫࠬ࡟ࠧ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠣ࡟ࠬࠤ࠰ࠦࠢ࠭࡞࡟ࡲࠧ࠯࡜࡯ࠢࠣࠤࠥࢃࡣࡢࡶࡦ࡬࠭࡫ࡸࠪࡽ࡟ࡲࠥࠦࠠࠡࡿ࡟ࡲࠥࠦࡽ࡝ࡰࠣࠤ࠴࠰ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠤ࠯࠵ࠧ঒")
bstack1lllll11l_opy_ = bstack1l11ll_opy_ (u"ࠨ࡞ࡱ࠳࠯ࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠣ࠮࠴ࡢ࡮ࡤࡱࡱࡷࡹࠦࡢࡴࡶࡤࡧࡰࡥࡰࡢࡶ࡫ࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺࡠࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠳࡞࡞ࡱࡧࡴࡴࡳࡵࠢࡥࡷࡹࡧࡣ࡬ࡡࡦࡥࡵࡹࠠ࠾ࠢࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࡜ࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࠮࡭ࡧࡱ࡫ࡹ࡮ࠠ࠮ࠢ࠴ࡡࡡࡴࡣࡰࡰࡶࡸࠥࡶ࡟ࡪࡰࡧࡩࡽࠦ࠽ࠡࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡤࡶ࡬ࡼ࡛ࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻ࠴࡬ࡦࡰࡪࡸ࡭ࠦ࠭ࠡ࠴ࡠࡠࡳࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺ࠳ࡹ࡬ࡪࡥࡨࠬ࠵࠲ࠠࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻ࠴࡬ࡦࡰࡪࡸ࡭ࠦ࠭ࠡ࠵ࠬࡠࡳࡩ࡯࡯ࡵࡷࠤ࡮ࡳࡰࡰࡴࡷࡣࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴ࠵ࡡࡥࡷࡹࡧࡣ࡬ࠢࡀࠤࡷ࡫ࡱࡶ࡫ࡵࡩ࠭ࠨࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠥ࠭ࡀࡢ࡮ࡪ࡯ࡳࡳࡷࡺ࡟ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷ࠸ࡤࡨࡳࡵࡣࡦ࡯࠳ࡩࡨࡳࡱࡰ࡭ࡺࡳ࠮࡭ࡣࡸࡲࡨ࡮ࠠ࠾ࠢࡤࡷࡾࡴࡣࠡࠪ࡯ࡥࡺࡴࡣࡩࡑࡳࡸ࡮ࡵ࡮ࡴࠫࠣࡁࡃࠦࡻ࡝ࡰ࡯ࡩࡹࠦࡣࡢࡲࡶ࠿ࡡࡴࡴࡳࡻࠣࡿࡡࡴࡣࡢࡲࡶࠤࡂࠦࡊࡔࡑࡑ࠲ࡵࡧࡲࡴࡧࠫࡦࡸࡺࡡࡤ࡭ࡢࡧࡦࡶࡳࠪ࡞ࡱࠤࠥࢃࠠࡤࡣࡷࡧ࡭࠮ࡥࡹࠫࠣࡿࡡࡴࠠࠡࠢࠣࢁࡡࡴࠠࠡࡴࡨࡸࡺࡸ࡮ࠡࡣࡺࡥ࡮ࡺࠠࡪ࡯ࡳࡳࡷࡺ࡟ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷ࠸ࡤࡨࡳࡵࡣࡦ࡯࠳ࡩࡨࡳࡱࡰ࡭ࡺࡳ࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡽ࡟ࡲࠥࠦࠠࠡࡹࡶࡉࡳࡪࡰࡰ࡫ࡱࡸ࠿ࠦࡠࡸࡵࡶ࠾࠴࠵ࡣࡥࡲ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࡂࡧࡦࡶࡳ࠾ࠦࡾࡩࡳࡩ࡯ࡥࡧࡘࡖࡎࡉ࡯࡮ࡲࡲࡲࡪࡴࡴࠩࡌࡖࡓࡓ࠴ࡳࡵࡴ࡬ࡲ࡬࡯ࡦࡺࠪࡦࡥࡵࡹࠩࠪࡿࡣ࠰ࡡࡴࠠࠡࠢࠣ࠲࠳࠴࡬ࡢࡷࡱࡧ࡭ࡕࡰࡵ࡫ࡲࡲࡸࡢ࡮ࠡࠢࢀ࠭ࡡࡴࡽ࡝ࡰ࠲࠮ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠭࠳ࡡࡴࠧও")
from ._version import __version__
bstack1l1l111l11_opy_ = None
CONFIG = {}
bstack1lllll1ll1_opy_ = {}
bstack11ll1l1l1_opy_ = {}
bstack1l1l1lll11_opy_ = None
bstack11ll11l1l_opy_ = None
bstack111l11l1_opy_ = None
bstack1llll1llll_opy_ = -1
bstack111l1l11_opy_ = 0
bstack111l1lll_opy_ = bstack1llll11l1_opy_
bstack1l11lll11_opy_ = 1
bstack1llll1ll11_opy_ = False
bstack1llll11ll1_opy_ = False
bstack1ll1l1l1ll_opy_ = bstack1l11ll_opy_ (u"ࠩࠪঔ")
bstack1llll11l11_opy_ = bstack1l11ll_opy_ (u"ࠪࠫক")
bstack1llllll111_opy_ = False
bstack1l1l1111_opy_ = True
bstack1111l1lll_opy_ = bstack1l11ll_opy_ (u"ࠫࠬখ")
bstack1l1111l1l_opy_ = []
bstack1ll1l1l1l1_opy_ = bstack1l11ll_opy_ (u"ࠬ࠭গ")
bstack1l11l1l11_opy_ = False
bstack1ll11ll1l1_opy_ = None
bstack1lll1l1l11_opy_ = None
bstack1l111ll1l_opy_ = None
bstack1ll111l111_opy_ = -1
bstack11l1lllll_opy_ = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"࠭ࡾࠨঘ")), bstack1l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧঙ"), bstack1l11ll_opy_ (u"ࠨ࠰ࡵࡳࡧࡵࡴ࠮ࡴࡨࡴࡴࡸࡴ࠮ࡪࡨࡰࡵ࡫ࡲ࠯࡬ࡶࡳࡳ࠭চ"))
bstack1l11111ll_opy_ = 0
bstack1l11l111l1_opy_ = []
bstack1l1l1l111l_opy_ = []
bstack1llll111ll_opy_ = []
bstack1lllll111l_opy_ = []
bstack11lllll1_opy_ = bstack1l11ll_opy_ (u"ࠩࠪছ")
bstack1l11lll11l_opy_ = bstack1l11ll_opy_ (u"ࠪࠫজ")
bstack1lll11lll1_opy_ = False
bstack1l1l1111ll_opy_ = False
bstack1ll111lll_opy_ = {}
bstack111111111_opy_ = None
bstack1111l11l_opy_ = None
bstack11l1l11l1_opy_ = None
bstack11llll1l1_opy_ = None
bstack1ll11l11l1_opy_ = None
bstack1l11l11l11_opy_ = None
bstack111111ll1_opy_ = None
bstack1l11ll1ll1_opy_ = None
bstack1111l1l11_opy_ = None
bstack1l1l111l1l_opy_ = None
bstack11l11lll_opy_ = None
bstack1l11l11l1l_opy_ = None
bstack1llll111l_opy_ = None
bstack1l11l1l11l_opy_ = None
bstack1lll11ll11_opy_ = None
bstack1lll11l11l_opy_ = None
bstack1llll11lll_opy_ = None
bstack1ll1lllll1_opy_ = None
bstack1lll11lll_opy_ = None
bstack11l1111l1_opy_ = None
bstack1l1ll11lll_opy_ = None
bstack1lll11l1l_opy_ = False
bstack1ll11l1111_opy_ = bstack1l11ll_opy_ (u"ࠦࠧঝ")
logger = bstack1ll1l1111l_opy_.get_logger(__name__, bstack111l1lll_opy_)
bstack1llll1ll_opy_ = Config.get_instance()
percy = bstack1lll1ll11_opy_()
bstack111l11l11_opy_ = bstack1ll1l1ll1l_opy_()
def bstack1111ll111_opy_():
  global CONFIG
  global bstack1lll11lll1_opy_
  global bstack1llll1ll_opy_
  bstack1ll11l111_opy_ = bstack111llll1_opy_(CONFIG)
  if (bstack1l11ll_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧঞ") in bstack1ll11l111_opy_ and str(bstack1ll11l111_opy_[bstack1l11ll_opy_ (u"࠭ࡳ࡬࡫ࡳࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨট")]).lower() == bstack1l11ll_opy_ (u"ࠧࡵࡴࡸࡩࠬঠ")):
    bstack1lll11lll1_opy_ = True
  bstack1llll1ll_opy_.bstack1l1llllll1_opy_(bstack1ll11l111_opy_.get(bstack1l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠬড"), False))
def bstack11l11l1l_opy_():
  from appium.version import version as appium_version
  return version.parse(appium_version)
def bstack1ll11lll11_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1l1l111lll_opy_():
  args = sys.argv
  for i in range(len(args)):
    if bstack1l11ll_opy_ (u"ࠤ࠰࠱ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡦࡳࡳ࡬ࡩࡨࡨ࡬ࡰࡪࠨঢ") == args[i].lower() or bstack1l11ll_opy_ (u"ࠥ࠱࠲ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡮ࡧ࡫ࡪࠦণ") == args[i].lower():
      path = args[i + 1]
      sys.argv.remove(args[i])
      sys.argv.remove(path)
      global bstack1111l1lll_opy_
      bstack1111l1lll_opy_ += bstack1l11ll_opy_ (u"ࠫ࠲࠳ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡈࡵ࡮ࡧ࡫ࡪࡊ࡮ࡲࡥࠡࠩত") + path
      return path
  return None
bstack1ll11ll111_opy_ = re.compile(bstack1l11ll_opy_ (u"ࡷࠨ࠮ࠫࡁ࡟ࠨࢀ࠮࠮ࠫࡁࠬࢁ࠳࠰࠿ࠣথ"))
def bstack1lll111l11_opy_(loader, node):
  value = loader.construct_scalar(node)
  for group in bstack1ll11ll111_opy_.findall(value):
    if group is not None and os.environ.get(group) is not None:
      value = value.replace(bstack1l11ll_opy_ (u"ࠨࠤࡼࠤদ") + group + bstack1l11ll_opy_ (u"ࠢࡾࠤধ"), os.environ.get(group))
  return value
def bstack11ll11ll1_opy_():
  bstack11ll111ll_opy_ = bstack1l1l111lll_opy_()
  if bstack11ll111ll_opy_ and os.path.exists(os.path.abspath(bstack11ll111ll_opy_)):
    fileName = bstack11ll111ll_opy_
  if bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡄࡑࡑࡊࡎࡍ࡟ࡇࡋࡏࡉࠬন") in os.environ and os.path.exists(
          os.path.abspath(os.environ[bstack1l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡒࡒࡋࡏࡇࡠࡈࡌࡐࡊ࠭঩")])) and not bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡏࡣࡰࡩࠬপ") in locals():
    fileName = os.environ[bstack1l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡇࡔࡔࡆࡊࡉࡢࡊࡎࡒࡅࠨফ")]
  if bstack1l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡑࡥࡲ࡫ࠧব") in locals():
    bstack11llll_opy_ = os.path.abspath(fileName)
  else:
    bstack11llll_opy_ = bstack1l11ll_opy_ (u"࠭ࠧভ")
  bstack11lll1ll_opy_ = os.getcwd()
  bstack1l111lll1_opy_ = bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡹ࡮࡮ࠪম")
  bstack11ll1l1l_opy_ = bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡺࡣࡰࡰࠬয")
  while (not os.path.exists(bstack11llll_opy_)) and bstack11lll1ll_opy_ != bstack1l11ll_opy_ (u"ࠤࠥর"):
    bstack11llll_opy_ = os.path.join(bstack11lll1ll_opy_, bstack1l111lll1_opy_)
    if not os.path.exists(bstack11llll_opy_):
      bstack11llll_opy_ = os.path.join(bstack11lll1ll_opy_, bstack11ll1l1l_opy_)
    if bstack11lll1ll_opy_ != os.path.dirname(bstack11lll1ll_opy_):
      bstack11lll1ll_opy_ = os.path.dirname(bstack11lll1ll_opy_)
    else:
      bstack11lll1ll_opy_ = bstack1l11ll_opy_ (u"ࠥࠦ঱")
  if not os.path.exists(bstack11llll_opy_):
    bstack1111ll11_opy_(
      bstack1lll1111l1_opy_.format(os.getcwd()))
  try:
    with open(bstack11llll_opy_, bstack1l11ll_opy_ (u"ࠫࡷ࠭ল")) as stream:
      yaml.add_implicit_resolver(bstack1l11ll_opy_ (u"ࠧࠧࡰࡢࡶ࡫ࡩࡽࠨ঳"), bstack1ll11ll111_opy_)
      yaml.add_constructor(bstack1l11ll_opy_ (u"ࠨࠡࡱࡣࡷ࡬ࡪࡾࠢ঴"), bstack1lll111l11_opy_)
      config = yaml.load(stream, yaml.FullLoader)
      return config
  except:
    with open(bstack11llll_opy_, bstack1l11ll_opy_ (u"ࠧࡳࠩ঵")) as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        bstack1111ll11_opy_(bstack1lll1l111l_opy_.format(str(exc)))
def bstack1l1ll1l1l_opy_(config):
  bstack111l1ll1_opy_ = bstack11llll1ll_opy_(config)
  for option in list(bstack111l1ll1_opy_):
    if option.lower() in bstack1l1l11l1ll_opy_ and option != bstack1l1l11l1ll_opy_[option.lower()]:
      bstack111l1ll1_opy_[bstack1l1l11l1ll_opy_[option.lower()]] = bstack111l1ll1_opy_[option]
      del bstack111l1ll1_opy_[option]
  return config
def bstack1lllll1l1_opy_():
  global bstack11ll1l1l1_opy_
  for key, bstack11l1llll_opy_ in bstack1l1l11ll_opy_.items():
    if isinstance(bstack11l1llll_opy_, list):
      for var in bstack11l1llll_opy_:
        if var in os.environ and os.environ[var] and str(os.environ[var]).strip():
          bstack11ll1l1l1_opy_[key] = os.environ[var]
          break
    elif bstack11l1llll_opy_ in os.environ and os.environ[bstack11l1llll_opy_] and str(os.environ[bstack11l1llll_opy_]).strip():
      bstack11ll1l1l1_opy_[key] = os.environ[bstack11l1llll_opy_]
  if bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡍࡑࡆࡅࡑࡥࡉࡅࡇࡑࡘࡎࡌࡉࡆࡔࠪশ") in os.environ:
    bstack11ll1l1l1_opy_[bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ষ")] = {}
    bstack11ll1l1l1_opy_[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧস")][bstack1l11ll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭হ")] = os.environ[bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡑࡕࡃࡂࡎࡢࡍࡉࡋࡎࡕࡋࡉࡍࡊࡘࠧ঺")]
def bstack1l11l11l_opy_():
  global bstack1lllll1ll1_opy_
  global bstack1111l1lll_opy_
  for idx, val in enumerate(sys.argv):
    if idx < len(sys.argv) and bstack1l11ll_opy_ (u"࠭࠭࠮ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ঻").lower() == val.lower():
      bstack1lllll1ll1_opy_[bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶ়ࠫ")] = {}
      bstack1lllll1ll1_opy_[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬঽ")][bstack1l11ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫা")] = sys.argv[idx + 1]
      del sys.argv[idx:idx + 2]
      break
  for key, bstack1l11ll11_opy_ in bstack1ll11111l1_opy_.items():
    if isinstance(bstack1l11ll11_opy_, list):
      for idx, val in enumerate(sys.argv):
        for var in bstack1l11ll11_opy_:
          if idx < len(sys.argv) and bstack1l11ll_opy_ (u"ࠪ࠱࠲࠭ি") + var.lower() == val.lower() and not key in bstack1lllll1ll1_opy_:
            bstack1lllll1ll1_opy_[key] = sys.argv[idx + 1]
            bstack1111l1lll_opy_ += bstack1l11ll_opy_ (u"ࠫࠥ࠳࠭ࠨী") + var + bstack1l11ll_opy_ (u"ࠬࠦࠧু") + sys.argv[idx + 1]
            del sys.argv[idx:idx + 2]
            break
    else:
      for idx, val in enumerate(sys.argv):
        if idx < len(sys.argv) and bstack1l11ll_opy_ (u"࠭࠭࠮ࠩূ") + bstack1l11ll11_opy_.lower() == val.lower() and not key in bstack1lllll1ll1_opy_:
          bstack1lllll1ll1_opy_[key] = sys.argv[idx + 1]
          bstack1111l1lll_opy_ += bstack1l11ll_opy_ (u"ࠧࠡ࠯࠰ࠫৃ") + bstack1l11ll11_opy_ + bstack1l11ll_opy_ (u"ࠨࠢࠪৄ") + sys.argv[idx + 1]
          del sys.argv[idx:idx + 2]
def bstack111l111l_opy_(config):
  bstack1l1l11ll1_opy_ = config.keys()
  for bstack1lllllll1_opy_, bstack1lllll111_opy_ in bstack11ll1l11l_opy_.items():
    if bstack1lllll111_opy_ in bstack1l1l11ll1_opy_:
      config[bstack1lllllll1_opy_] = config[bstack1lllll111_opy_]
      del config[bstack1lllll111_opy_]
  for bstack1lllllll1_opy_, bstack1lllll111_opy_ in bstack1l11llllll_opy_.items():
    if isinstance(bstack1lllll111_opy_, list):
      for bstack11l11l1ll_opy_ in bstack1lllll111_opy_:
        if bstack11l11l1ll_opy_ in bstack1l1l11ll1_opy_:
          config[bstack1lllllll1_opy_] = config[bstack11l11l1ll_opy_]
          del config[bstack11l11l1ll_opy_]
          break
    elif bstack1lllll111_opy_ in bstack1l1l11ll1_opy_:
      config[bstack1lllllll1_opy_] = config[bstack1lllll111_opy_]
      del config[bstack1lllll111_opy_]
  for bstack11l11l1ll_opy_ in list(config):
    for bstack1l1l1ll1l1_opy_ in bstack1l111ll1_opy_:
      if bstack11l11l1ll_opy_.lower() == bstack1l1l1ll1l1_opy_.lower() and bstack11l11l1ll_opy_ != bstack1l1l1ll1l1_opy_:
        config[bstack1l1l1ll1l1_opy_] = config[bstack11l11l1ll_opy_]
        del config[bstack11l11l1ll_opy_]
  bstack1l11l1lll1_opy_ = []
  if bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ৅") in config:
    bstack1l11l1lll1_opy_ = config[bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭৆")]
  for platform in bstack1l11l1lll1_opy_:
    for bstack11l11l1ll_opy_ in list(platform):
      for bstack1l1l1ll1l1_opy_ in bstack1l111ll1_opy_:
        if bstack11l11l1ll_opy_.lower() == bstack1l1l1ll1l1_opy_.lower() and bstack11l11l1ll_opy_ != bstack1l1l1ll1l1_opy_:
          platform[bstack1l1l1ll1l1_opy_] = platform[bstack11l11l1ll_opy_]
          del platform[bstack11l11l1ll_opy_]
  for bstack1lllllll1_opy_, bstack1lllll111_opy_ in bstack1l11llllll_opy_.items():
    for platform in bstack1l11l1lll1_opy_:
      if isinstance(bstack1lllll111_opy_, list):
        for bstack11l11l1ll_opy_ in bstack1lllll111_opy_:
          if bstack11l11l1ll_opy_ in platform:
            platform[bstack1lllllll1_opy_] = platform[bstack11l11l1ll_opy_]
            del platform[bstack11l11l1ll_opy_]
            break
      elif bstack1lllll111_opy_ in platform:
        platform[bstack1lllllll1_opy_] = platform[bstack1lllll111_opy_]
        del platform[bstack1lllll111_opy_]
  for bstack1l1l1llll1_opy_ in bstack111111ll_opy_:
    if bstack1l1l1llll1_opy_ in config:
      if not bstack111111ll_opy_[bstack1l1l1llll1_opy_] in config:
        config[bstack111111ll_opy_[bstack1l1l1llll1_opy_]] = {}
      config[bstack111111ll_opy_[bstack1l1l1llll1_opy_]].update(config[bstack1l1l1llll1_opy_])
      del config[bstack1l1l1llll1_opy_]
  for platform in bstack1l11l1lll1_opy_:
    for bstack1l1l1llll1_opy_ in bstack111111ll_opy_:
      if bstack1l1l1llll1_opy_ in list(platform):
        if not bstack111111ll_opy_[bstack1l1l1llll1_opy_] in platform:
          platform[bstack111111ll_opy_[bstack1l1l1llll1_opy_]] = {}
        platform[bstack111111ll_opy_[bstack1l1l1llll1_opy_]].update(platform[bstack1l1l1llll1_opy_])
        del platform[bstack1l1l1llll1_opy_]
  config = bstack1l1ll1l1l_opy_(config)
  return config
def bstack1ll11111l_opy_(config):
  global bstack1llll11l11_opy_
  if bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨে") in config and str(config[bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩৈ")]).lower() != bstack1l11ll_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ৉"):
    if not bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ৊") in config:
      config[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬো")] = {}
    if not bstack1l11ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫৌ") in config[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹ্ࠧ")]:
      current_time = datetime.datetime.now()
      bstack11llll1l_opy_ = current_time.strftime(bstack1l11ll_opy_ (u"ࠫࠪࡪ࡟ࠦࡤࡢࠩࡍࠫࡍࠨৎ"))
      hostname = socket.gethostname()
      bstack1lll1l11l1_opy_ = bstack1l11ll_opy_ (u"ࠬ࠭৏").join(random.choices(string.ascii_lowercase + string.digits, k=4))
      identifier = bstack1l11ll_opy_ (u"࠭ࡻࡾࡡࡾࢁࡤࢁࡽࠨ৐").format(bstack11llll1l_opy_, hostname, bstack1lll1l11l1_opy_)
      config[bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ৑")][bstack1l11ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ৒")] = identifier
    bstack1llll11l11_opy_ = config[bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭৓")][bstack1l11ll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬ৔")]
  return config
def bstack1ll11l111l_opy_():
  bstack1l1ll1lll1_opy_ =  bstack1lll11111_opy_()[bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠪ৕")]
  return bstack1l1ll1lll1_opy_ if bstack1l1ll1lll1_opy_ else -1
def bstack11111l1l_opy_(bstack1l1ll1lll1_opy_):
  global CONFIG
  if not bstack1l11ll_opy_ (u"ࠬࠪࡻࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࢃࠧ৖") in CONFIG[bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨৗ")]:
    return
  CONFIG[bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ৘")] = CONFIG[bstack1l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ৙")].replace(
    bstack1l11ll_opy_ (u"ࠩࠧࡿࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࢀࠫ৚"),
    str(bstack1l1ll1lll1_opy_)
  )
def bstack11lllll1l_opy_():
  global CONFIG
  if not bstack1l11ll_opy_ (u"ࠪࠨࢀࡊࡁࡕࡇࡢࡘࡎࡓࡅࡾࠩ৛") in CONFIG[bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ড়")]:
    return
  current_time = datetime.datetime.now()
  bstack11llll1l_opy_ = current_time.strftime(bstack1l11ll_opy_ (u"ࠬࠫࡤ࠮ࠧࡥ࠱ࠪࡎ࠺ࠦࡏࠪঢ়"))
  CONFIG[bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ৞")] = CONFIG[bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩয়")].replace(
    bstack1l11ll_opy_ (u"ࠨࠦࡾࡈࡆ࡚ࡅࡠࡖࡌࡑࡊࢃࠧৠ"),
    bstack11llll1l_opy_
  )
def bstack11l11111l_opy_():
  global CONFIG
  if bstack1l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫৡ") in CONFIG and not bool(CONFIG[bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬৢ")]):
    del CONFIG[bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ৣ")]
    return
  if not bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ৤") in CONFIG:
    CONFIG[bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ৥")] = bstack1l11ll_opy_ (u"ࠧࠤࠦࡾࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࡿࠪ০")
  if bstack1l11ll_opy_ (u"ࠨࠦࡾࡈࡆ࡚ࡅࡠࡖࡌࡑࡊࢃࠧ১") in CONFIG[bstack1l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ২")]:
    bstack11lllll1l_opy_()
    os.environ[bstack1l11ll_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡢࡇࡔࡓࡂࡊࡐࡈࡈࡤࡈࡕࡊࡎࡇࡣࡎࡊࠧ৩")] = CONFIG[bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭৪")]
  if not bstack1l11ll_opy_ (u"ࠬࠪࡻࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࢃࠧ৫") in CONFIG[bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ৬")]:
    return
  bstack1l1ll1lll1_opy_ = bstack1l11ll_opy_ (u"ࠧࠨ৭")
  bstack1l11lll111_opy_ = bstack1ll11l111l_opy_()
  if bstack1l11lll111_opy_ != -1:
    bstack1l1ll1lll1_opy_ = bstack1l11ll_opy_ (u"ࠨࡅࡌࠤࠬ৮") + str(bstack1l11lll111_opy_)
  if bstack1l1ll1lll1_opy_ == bstack1l11ll_opy_ (u"ࠩࠪ৯"):
    bstack1l111l1l1_opy_ = bstack1l1ll11ll1_opy_(CONFIG[bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ৰ")])
    if bstack1l111l1l1_opy_ != -1:
      bstack1l1ll1lll1_opy_ = str(bstack1l111l1l1_opy_)
  if bstack1l1ll1lll1_opy_:
    bstack11111l1l_opy_(bstack1l1ll1lll1_opy_)
    os.environ[bstack1l11ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡣࡈࡕࡍࡃࡋࡑࡉࡉࡥࡂࡖࡋࡏࡈࡤࡏࡄࠨৱ")] = CONFIG[bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ৲")]
def bstack11ll1lll1_opy_(bstack111l11ll1_opy_, bstack1ll1ll1l1l_opy_, path):
  bstack1l1l111ll1_opy_ = {
    bstack1l11ll_opy_ (u"࠭ࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ৳"): bstack1ll1ll1l1l_opy_
  }
  if os.path.exists(path):
    bstack1l1l1ll1ll_opy_ = json.load(open(path, bstack1l11ll_opy_ (u"ࠧࡳࡤࠪ৴")))
  else:
    bstack1l1l1ll1ll_opy_ = {}
  bstack1l1l1ll1ll_opy_[bstack111l11ll1_opy_] = bstack1l1l111ll1_opy_
  with open(path, bstack1l11ll_opy_ (u"ࠣࡹ࠮ࠦ৵")) as outfile:
    json.dump(bstack1l1l1ll1ll_opy_, outfile)
def bstack1l1ll11ll1_opy_(bstack111l11ll1_opy_):
  bstack111l11ll1_opy_ = str(bstack111l11ll1_opy_)
  bstack1ll11ll11_opy_ = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠩࢁࠫ৶")), bstack1l11ll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪ৷"))
  try:
    if not os.path.exists(bstack1ll11ll11_opy_):
      os.makedirs(bstack1ll11ll11_opy_)
    file_path = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠫࢃ࠭৸")), bstack1l11ll_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ৹"), bstack1l11ll_opy_ (u"࠭࠮ࡣࡷ࡬ࡰࡩ࠳࡮ࡢ࡯ࡨ࠱ࡨࡧࡣࡩࡧ࠱࡮ࡸࡵ࡮ࠨ৺"))
    if not os.path.isfile(file_path):
      with open(file_path, bstack1l11ll_opy_ (u"ࠧࡸࠩ৻")):
        pass
      with open(file_path, bstack1l11ll_opy_ (u"ࠣࡹ࠮ࠦৼ")) as outfile:
        json.dump({}, outfile)
    with open(file_path, bstack1l11ll_opy_ (u"ࠩࡵࠫ৽")) as bstack1ll111111_opy_:
      bstack11l11l1l1_opy_ = json.load(bstack1ll111111_opy_)
    if bstack111l11ll1_opy_ in bstack11l11l1l1_opy_:
      bstack1lll1l11ll_opy_ = bstack11l11l1l1_opy_[bstack111l11ll1_opy_][bstack1l11ll_opy_ (u"ࠪ࡭ࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ৾")]
      bstack1l1ll1ll1l_opy_ = int(bstack1lll1l11ll_opy_) + 1
      bstack11ll1lll1_opy_(bstack111l11ll1_opy_, bstack1l1ll1ll1l_opy_, file_path)
      return bstack1l1ll1ll1l_opy_
    else:
      bstack11ll1lll1_opy_(bstack111l11ll1_opy_, 1, file_path)
      return 1
  except Exception as e:
    logger.warn(bstack1lll1lll1_opy_.format(str(e)))
    return -1
def bstack1l11l1ll11_opy_(config):
  if not config[bstack1l11ll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭৿")] or not config[bstack1l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨ਀")]:
    return True
  else:
    return False
def bstack1l11l11ll_opy_(config, index=0):
  global bstack1llllll111_opy_
  bstack1ll1l11l11_opy_ = {}
  caps = bstack111l1lll1_opy_ + bstack1ll1111l1_opy_
  if bstack1llllll111_opy_:
    caps += bstack11l11lll1_opy_
  for key in config:
    if key in caps + [bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩਁ")]:
      continue
    bstack1ll1l11l11_opy_[key] = config[key]
  if bstack1l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪਂ") in config:
    for bstack11l1ll111_opy_ in config[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫਃ")][index]:
      if bstack11l1ll111_opy_ in caps + [bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ਄"), bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫਅ")]:
        continue
      bstack1ll1l11l11_opy_[bstack11l1ll111_opy_] = config[bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧਆ")][index][bstack11l1ll111_opy_]
  bstack1ll1l11l11_opy_[bstack1l11ll_opy_ (u"ࠬ࡮࡯ࡴࡶࡑࡥࡲ࡫ࠧਇ")] = socket.gethostname()
  if bstack1l11ll_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧਈ") in bstack1ll1l11l11_opy_:
    del (bstack1ll1l11l11_opy_[bstack1l11ll_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨਉ")])
  return bstack1ll1l11l11_opy_
def bstack1ll1lll1l_opy_(config):
  global bstack1llllll111_opy_
  bstack1111ll1l_opy_ = {}
  caps = bstack1ll1111l1_opy_
  if bstack1llllll111_opy_:
    caps += bstack11l11lll1_opy_
  for key in caps:
    if key in config:
      bstack1111ll1l_opy_[key] = config[key]
  return bstack1111ll1l_opy_
def bstack1ll1l111ll_opy_(bstack1ll1l11l11_opy_, bstack1111ll1l_opy_):
  bstack1ll1l11lll_opy_ = {}
  for key in bstack1ll1l11l11_opy_.keys():
    if key in bstack11ll1l11l_opy_:
      bstack1ll1l11lll_opy_[bstack11ll1l11l_opy_[key]] = bstack1ll1l11l11_opy_[key]
    else:
      bstack1ll1l11lll_opy_[key] = bstack1ll1l11l11_opy_[key]
  for key in bstack1111ll1l_opy_:
    if key in bstack11ll1l11l_opy_:
      bstack1ll1l11lll_opy_[bstack11ll1l11l_opy_[key]] = bstack1111ll1l_opy_[key]
    else:
      bstack1ll1l11lll_opy_[key] = bstack1111ll1l_opy_[key]
  return bstack1ll1l11lll_opy_
def bstack111ll11l1_opy_(config, index=0):
  global bstack1llllll111_opy_
  caps = {}
  config = copy.deepcopy(config)
  bstack1lll1l1l1l_opy_ = bstack111l111l1_opy_(bstack1l1ll11111_opy_, config, logger)
  bstack1111ll1l_opy_ = bstack1ll1lll1l_opy_(config)
  bstack1ll111l11l_opy_ = bstack1ll1111l1_opy_
  bstack1ll111l11l_opy_ += bstack11111l1ll_opy_
  bstack1111ll1l_opy_ = update(bstack1111ll1l_opy_, bstack1lll1l1l1l_opy_)
  if bstack1llllll111_opy_:
    bstack1ll111l11l_opy_ += bstack11l11lll1_opy_
  if bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫਊ") in config:
    if bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ਋") in config[bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭਌")][index]:
      caps[bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩ਍")] = config[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ਎")][index][bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫਏ")]
    if bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨਐ") in config[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ਑")][index]:
      caps[bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪ਒")] = str(config[bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ਓ")][index][bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬਔ")])
    bstack1ll1lll111_opy_ = bstack111l111l1_opy_(bstack1l1ll11111_opy_, config[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨਕ")][index], logger)
    bstack1ll111l11l_opy_ += list(bstack1ll1lll111_opy_.keys())
    for bstack11l1l1l1_opy_ in bstack1ll111l11l_opy_:
      if bstack11l1l1l1_opy_ in config[bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩਖ")][index]:
        if bstack11l1l1l1_opy_ == bstack1l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠩਗ"):
          try:
            bstack1ll1lll111_opy_[bstack11l1l1l1_opy_] = str(config[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫਘ")][index][bstack11l1l1l1_opy_] * 1.0)
          except:
            bstack1ll1lll111_opy_[bstack11l1l1l1_opy_] = str(config[bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬਙ")][index][bstack11l1l1l1_opy_])
        else:
          bstack1ll1lll111_opy_[bstack11l1l1l1_opy_] = config[bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ਚ")][index][bstack11l1l1l1_opy_]
        del (config[bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧਛ")][index][bstack11l1l1l1_opy_])
    bstack1111ll1l_opy_ = update(bstack1111ll1l_opy_, bstack1ll1lll111_opy_)
  bstack1ll1l11l11_opy_ = bstack1l11l11ll_opy_(config, index)
  for bstack11l11l1ll_opy_ in bstack1ll1111l1_opy_ + [bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪਜ"), bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧਝ")] + list(bstack1lll1l1l1l_opy_.keys()):
    if bstack11l11l1ll_opy_ in bstack1ll1l11l11_opy_:
      bstack1111ll1l_opy_[bstack11l11l1ll_opy_] = bstack1ll1l11l11_opy_[bstack11l11l1ll_opy_]
      del (bstack1ll1l11l11_opy_[bstack11l11l1ll_opy_])
  if bstack1l11ll1l11_opy_(config):
    bstack1ll1l11l11_opy_[bstack1l11ll_opy_ (u"ࠧࡶࡵࡨ࡛࠸ࡉࠧਞ")] = True
    caps.update(bstack1111ll1l_opy_)
    caps[bstack1l11ll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩਟ")] = bstack1ll1l11l11_opy_
  else:
    bstack1ll1l11l11_opy_[bstack1l11ll_opy_ (u"ࠩࡸࡷࡪ࡝࠳ࡄࠩਠ")] = False
    caps.update(bstack1ll1l111ll_opy_(bstack1ll1l11l11_opy_, bstack1111ll1l_opy_))
    if bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨਡ") in caps:
      caps[bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬਢ")] = caps[bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪਣ")]
      del (caps[bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫਤ")])
    if bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨਥ") in caps:
      caps[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪਦ")] = caps[bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪਧ")]
      del (caps[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫਨ")])
  return caps
def bstack1llllll11l_opy_():
  global bstack1ll1l1l1l1_opy_
  if bstack1ll11lll11_opy_() <= version.parse(bstack1l11ll_opy_ (u"ࠫ࠸࠴࠱࠴࠰࠳ࠫ਩")):
    if bstack1ll1l1l1l1_opy_ != bstack1l11ll_opy_ (u"ࠬ࠭ਪ"):
      return bstack1l11ll_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢਫ") + bstack1ll1l1l1l1_opy_ + bstack1l11ll_opy_ (u"ࠢ࠻࠺࠳࠳ࡼࡪ࠯ࡩࡷࡥࠦਬ")
    return bstack1lll1l1l1_opy_
  if bstack1ll1l1l1l1_opy_ != bstack1l11ll_opy_ (u"ࠨࠩਭ"):
    return bstack1l11ll_opy_ (u"ࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠦਮ") + bstack1ll1l1l1l1_opy_ + bstack1l11ll_opy_ (u"ࠥ࠳ࡼࡪ࠯ࡩࡷࡥࠦਯ")
  return bstack1l11ll11ll_opy_
def bstack1111llll_opy_(options):
  return hasattr(options, bstack1l11ll_opy_ (u"ࠫࡸ࡫ࡴࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷࡽࠬਰ"))
def update(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = update(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack1l1l1lllll_opy_(options, bstack1ll111lll1_opy_):
  for bstack11ll1l1ll_opy_ in bstack1ll111lll1_opy_:
    if bstack11ll1l1ll_opy_ in [bstack1l11ll_opy_ (u"ࠬࡧࡲࡨࡵࠪ਱"), bstack1l11ll_opy_ (u"࠭ࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࡵࠪਲ")]:
      continue
    if bstack11ll1l1ll_opy_ in options._experimental_options:
      options._experimental_options[bstack11ll1l1ll_opy_] = update(options._experimental_options[bstack11ll1l1ll_opy_],
                                                         bstack1ll111lll1_opy_[bstack11ll1l1ll_opy_])
    else:
      options.add_experimental_option(bstack11ll1l1ll_opy_, bstack1ll111lll1_opy_[bstack11ll1l1ll_opy_])
  if bstack1l11ll_opy_ (u"ࠧࡢࡴࡪࡷࠬਲ਼") in bstack1ll111lll1_opy_:
    for arg in bstack1ll111lll1_opy_[bstack1l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭਴")]:
      options.add_argument(arg)
    del (bstack1ll111lll1_opy_[bstack1l11ll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧਵ")])
  if bstack1l11ll_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧਸ਼") in bstack1ll111lll1_opy_:
    for ext in bstack1ll111lll1_opy_[bstack1l11ll_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨ਷")]:
      options.add_extension(ext)
    del (bstack1ll111lll1_opy_[bstack1l11ll_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩਸ")])
def bstack11lll1l1_opy_(options, bstack111l11l1l_opy_):
  if bstack1l11ll_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬਹ") in bstack111l11l1l_opy_:
    for bstack1l1l11lll_opy_ in bstack111l11l1l_opy_[bstack1l11ll_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭਺")]:
      if bstack1l1l11lll_opy_ in options._preferences:
        options._preferences[bstack1l1l11lll_opy_] = update(options._preferences[bstack1l1l11lll_opy_], bstack111l11l1l_opy_[bstack1l11ll_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧ਻")][bstack1l1l11lll_opy_])
      else:
        options.set_preference(bstack1l1l11lll_opy_, bstack111l11l1l_opy_[bstack1l11ll_opy_ (u"ࠩࡳࡶࡪ࡬ࡳࠨ਼")][bstack1l1l11lll_opy_])
  if bstack1l11ll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨ਽") in bstack111l11l1l_opy_:
    for arg in bstack111l11l1l_opy_[bstack1l11ll_opy_ (u"ࠫࡦࡸࡧࡴࠩਾ")]:
      options.add_argument(arg)
def bstack1lll11l11_opy_(options, bstack1l1llll1l_opy_):
  if bstack1l11ll_opy_ (u"ࠬࡽࡥࡣࡸ࡬ࡩࡼ࠭ਿ") in bstack1l1llll1l_opy_:
    options.use_webview(bool(bstack1l1llll1l_opy_[bstack1l11ll_opy_ (u"࠭ࡷࡦࡤࡹ࡭ࡪࡽࠧੀ")]))
  bstack1l1l1lllll_opy_(options, bstack1l1llll1l_opy_)
def bstack1111lll1l_opy_(options, bstack11l11l11l_opy_):
  for bstack1l11ll1ll_opy_ in bstack11l11l11l_opy_:
    if bstack1l11ll1ll_opy_ in [bstack1l11ll_opy_ (u"ࠧࡵࡧࡦ࡬ࡳࡵ࡬ࡰࡩࡼࡔࡷ࡫ࡶࡪࡧࡺࠫੁ"), bstack1l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ੂ")]:
      continue
    options.set_capability(bstack1l11ll1ll_opy_, bstack11l11l11l_opy_[bstack1l11ll1ll_opy_])
  if bstack1l11ll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ੃") in bstack11l11l11l_opy_:
    for arg in bstack11l11l11l_opy_[bstack1l11ll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨ੄")]:
      options.add_argument(arg)
  if bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡣࡩࡰࡲࡰࡴ࡭ࡹࡑࡴࡨࡺ࡮࡫ࡷࠨ੅") in bstack11l11l11l_opy_:
    options.bstack1llll1l11l_opy_(bool(bstack11l11l11l_opy_[bstack1l11ll_opy_ (u"ࠬࡺࡥࡤࡪࡱࡳࡱࡵࡧࡺࡒࡵࡩࡻ࡯ࡥࡸࠩ੆")]))
def bstack1l11ll1lll_opy_(options, bstack1l1l1ll1l_opy_):
  for bstack1l1l11lll1_opy_ in bstack1l1l1ll1l_opy_:
    if bstack1l1l11lll1_opy_ in [bstack1l11ll_opy_ (u"࠭ࡡࡥࡦ࡬ࡸ࡮ࡵ࡮ࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪੇ"), bstack1l11ll_opy_ (u"ࠧࡢࡴࡪࡷࠬੈ")]:
      continue
    options._options[bstack1l1l11lll1_opy_] = bstack1l1l1ll1l_opy_[bstack1l1l11lll1_opy_]
  if bstack1l11ll_opy_ (u"ࠨࡣࡧࡨ࡮ࡺࡩࡰࡰࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬ੉") in bstack1l1l1ll1l_opy_:
    for bstack1lllll1l11_opy_ in bstack1l1l1ll1l_opy_[bstack1l11ll_opy_ (u"ࠩࡤࡨࡩ࡯ࡴࡪࡱࡱࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭੊")]:
      options.bstack111l1l1ll_opy_(
        bstack1lllll1l11_opy_, bstack1l1l1ll1l_opy_[bstack1l11ll_opy_ (u"ࠪࡥࡩࡪࡩࡵ࡫ࡲࡲࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧੋ")][bstack1lllll1l11_opy_])
  if bstack1l11ll_opy_ (u"ࠫࡦࡸࡧࡴࠩੌ") in bstack1l1l1ll1l_opy_:
    for arg in bstack1l1l1ll1l_opy_[bstack1l11ll_opy_ (u"ࠬࡧࡲࡨࡵ੍ࠪ")]:
      options.add_argument(arg)
def bstack1lll1ll1ll_opy_(options, caps):
  if not hasattr(options, bstack1l11ll_opy_ (u"࠭ࡋࡆ࡛ࠪ੎")):
    return
  if options.KEY == bstack1l11ll_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬ੏") and options.KEY in caps:
    bstack1l1l1lllll_opy_(options, caps[bstack1l11ll_opy_ (u"ࠨࡩࡲࡳ࡬ࡀࡣࡩࡴࡲࡱࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭੐")])
  elif options.KEY == bstack1l11ll_opy_ (u"ࠩࡰࡳࡿࡀࡦࡪࡴࡨࡪࡴࡾࡏࡱࡶ࡬ࡳࡳࡹࠧੑ") and options.KEY in caps:
    bstack11lll1l1_opy_(options, caps[bstack1l11ll_opy_ (u"ࠪࡱࡴࢀ࠺ࡧ࡫ࡵࡩ࡫ࡵࡸࡐࡲࡷ࡭ࡴࡴࡳࠨ੒")])
  elif options.KEY == bstack1l11ll_opy_ (u"ࠫࡸࡧࡦࡢࡴ࡬࠲ࡴࡶࡴࡪࡱࡱࡷࠬ੓") and options.KEY in caps:
    bstack1111lll1l_opy_(options, caps[bstack1l11ll_opy_ (u"ࠬࡹࡡࡧࡣࡵ࡭࠳ࡵࡰࡵ࡫ࡲࡲࡸ࠭੔")])
  elif options.KEY == bstack1l11ll_opy_ (u"࠭࡭ࡴ࠼ࡨࡨ࡬࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧ੕") and options.KEY in caps:
    bstack1lll11l11_opy_(options, caps[bstack1l11ll_opy_ (u"ࠧ࡮ࡵ࠽ࡩࡩ࡭ࡥࡐࡲࡷ࡭ࡴࡴࡳࠨ੖")])
  elif options.KEY == bstack1l11ll_opy_ (u"ࠨࡵࡨ࠾࡮࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧ੗") and options.KEY in caps:
    bstack1l11ll1lll_opy_(options, caps[bstack1l11ll_opy_ (u"ࠩࡶࡩ࠿࡯ࡥࡐࡲࡷ࡭ࡴࡴࡳࠨ੘")])
def bstack1ll1ll111_opy_(caps):
  global bstack1llllll111_opy_
  if isinstance(os.environ.get(bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫਖ਼")), str):
    bstack1llllll111_opy_ = eval(os.getenv(bstack1l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬਗ਼")))
  if bstack1llllll111_opy_:
    if bstack11l11l1l_opy_() < version.parse(bstack1l11ll_opy_ (u"ࠬ࠸࠮࠴࠰࠳ࠫਜ਼")):
      return None
    else:
      from appium.options.common.base import AppiumOptions
      options = AppiumOptions().load_capabilities(caps)
      return options
  else:
    browser = bstack1l11ll_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪ࠭ੜ")
    if bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ੝") in caps:
      browser = caps[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭ਫ਼")]
    elif bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪ੟") in caps:
      browser = caps[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ੠")]
    browser = str(browser).lower()
    if browser == bstack1l11ll_opy_ (u"ࠫ࡮ࡶࡨࡰࡰࡨࠫ੡") or browser == bstack1l11ll_opy_ (u"ࠬ࡯ࡰࡢࡦࠪ੢"):
      browser = bstack1l11ll_opy_ (u"࠭ࡳࡢࡨࡤࡶ࡮࠭੣")
    if browser == bstack1l11ll_opy_ (u"ࠧࡴࡣࡰࡷࡺࡴࡧࠨ੤"):
      browser = bstack1l11ll_opy_ (u"ࠨࡥ࡫ࡶࡴࡳࡥࠨ੥")
    if browser not in [bstack1l11ll_opy_ (u"ࠩࡦ࡬ࡷࡵ࡭ࡦࠩ੦"), bstack1l11ll_opy_ (u"ࠪࡩࡩ࡭ࡥࠨ੧"), bstack1l11ll_opy_ (u"ࠫ࡮࡫ࠧ੨"), bstack1l11ll_opy_ (u"ࠬࡹࡡࡧࡣࡵ࡭ࠬ੩"), bstack1l11ll_opy_ (u"࠭ࡦࡪࡴࡨࡪࡴࡾࠧ੪")]:
      return None
    try:
      package = bstack1l11ll_opy_ (u"ࠧࡴࡧ࡯ࡩࡳ࡯ࡵ࡮࠰ࡺࡩࡧࡪࡲࡪࡸࡨࡶ࠳ࢁࡽ࠯ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ੫").format(browser)
      name = bstack1l11ll_opy_ (u"ࠨࡑࡳࡸ࡮ࡵ࡮ࡴࠩ੬")
      browser_options = getattr(__import__(package, fromlist=[name]), name)
      options = browser_options()
      if not bstack1111llll_opy_(options):
        return None
      for bstack11l11l1ll_opy_ in caps.keys():
        options.set_capability(bstack11l11l1ll_opy_, caps[bstack11l11l1ll_opy_])
      bstack1lll1ll1ll_opy_(options, caps)
      return options
    except Exception as e:
      logger.debug(str(e))
      return None
def bstack11lllllll_opy_(options, bstack1ll1l111l1_opy_):
  if not bstack1111llll_opy_(options):
    return
  for bstack11l11l1ll_opy_ in bstack1ll1l111l1_opy_.keys():
    if bstack11l11l1ll_opy_ in bstack11111l1ll_opy_:
      continue
    if bstack11l11l1ll_opy_ in options._caps and type(options._caps[bstack11l11l1ll_opy_]) in [dict, list]:
      options._caps[bstack11l11l1ll_opy_] = update(options._caps[bstack11l11l1ll_opy_], bstack1ll1l111l1_opy_[bstack11l11l1ll_opy_])
    else:
      options.set_capability(bstack11l11l1ll_opy_, bstack1ll1l111l1_opy_[bstack11l11l1ll_opy_])
  bstack1lll1ll1ll_opy_(options, bstack1ll1l111l1_opy_)
  if bstack1l11ll_opy_ (u"ࠩࡰࡳࡿࡀࡤࡦࡤࡸ࡫࡬࡫ࡲࡂࡦࡧࡶࡪࡹࡳࠨ੭") in options._caps:
    if options._caps[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨ੮")] and options._caps[bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩ੯")].lower() != bstack1l11ll_opy_ (u"ࠬ࡬ࡩࡳࡧࡩࡳࡽ࠭ੰ"):
      del options._caps[bstack1l11ll_opy_ (u"࠭࡭ࡰࡼ࠽ࡨࡪࡨࡵࡨࡩࡨࡶࡆࡪࡤࡳࡧࡶࡷࠬੱ")]
def bstack11l11l11_opy_(proxy_config):
  if bstack1l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫੲ") in proxy_config:
    proxy_config[bstack1l11ll_opy_ (u"ࠨࡵࡶࡰࡕࡸ࡯ࡹࡻࠪੳ")] = proxy_config[bstack1l11ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࡑࡴࡲࡼࡾ࠭ੴ")]
    del (proxy_config[bstack1l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧੵ")])
  if bstack1l11ll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡗࡽࡵ࡫ࠧ੶") in proxy_config and proxy_config[bstack1l11ll_opy_ (u"ࠬࡶࡲࡰࡺࡼࡘࡾࡶࡥࠨ੷")].lower() != bstack1l11ll_opy_ (u"࠭ࡤࡪࡴࡨࡧࡹ࠭੸"):
    proxy_config[bstack1l11ll_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡚ࡹࡱࡧࠪ੹")] = bstack1l11ll_opy_ (u"ࠨ࡯ࡤࡲࡺࡧ࡬ࠨ੺")
  if bstack1l11ll_opy_ (u"ࠩࡳࡶࡴࡾࡹࡂࡷࡷࡳࡨࡵ࡮ࡧ࡫ࡪ࡙ࡷࡲࠧ੻") in proxy_config:
    proxy_config[bstack1l11ll_opy_ (u"ࠪࡴࡷࡵࡸࡺࡖࡼࡴࡪ࠭੼")] = bstack1l11ll_opy_ (u"ࠫࡵࡧࡣࠨ੽")
  return proxy_config
def bstack11llll11l_opy_(config, proxy):
  from selenium.webdriver.common.proxy import Proxy
  if not bstack1l11ll_opy_ (u"ࠬࡶࡲࡰࡺࡼࠫ੾") in config:
    return proxy
  config[bstack1l11ll_opy_ (u"࠭ࡰࡳࡱࡻࡽࠬ੿")] = bstack11l11l11_opy_(config[bstack1l11ll_opy_ (u"ࠧࡱࡴࡲࡼࡾ࠭઀")])
  if proxy == None:
    proxy = Proxy(config[bstack1l11ll_opy_ (u"ࠨࡲࡵࡳࡽࡿࠧઁ")])
  return proxy
def bstack1l1l1lll1l_opy_(self):
  global CONFIG
  global bstack1l11l11l1l_opy_
  try:
    proxy = bstack11ll1ll1_opy_(CONFIG)
    if proxy:
      if proxy.endswith(bstack1l11ll_opy_ (u"ࠩ࠱ࡴࡦࡩࠧં")):
        proxies = bstack1ll111ll11_opy_(proxy, bstack1llllll11l_opy_())
        if len(proxies) > 0:
          protocol, bstack1l11ll1l1l_opy_ = proxies.popitem()
          if bstack1l11ll_opy_ (u"ࠥ࠾࠴࠵ࠢઃ") in bstack1l11ll1l1l_opy_:
            return bstack1l11ll1l1l_opy_
          else:
            return bstack1l11ll_opy_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࠧ઄") + bstack1l11ll1l1l_opy_
      else:
        return proxy
  except Exception as e:
    logger.error(bstack1l11ll_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡲࡵࡳࡽࡿࠠࡶࡴ࡯ࠤ࠿ࠦࡻࡾࠤઅ").format(str(e)))
  return bstack1l11l11l1l_opy_(self)
def bstack1l1l1l111_opy_():
  global CONFIG
  return bstack1lll111l1l_opy_(CONFIG) and bstack1l1lll1l1_opy_() and bstack1ll11lll11_opy_() >= version.parse(bstack1ll1l1l1l_opy_)
def bstack111l1ll11_opy_():
  global CONFIG
  return (bstack1l11ll_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩઆ") in CONFIG or bstack1l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫઇ") in CONFIG) and bstack11ll1lll_opy_()
def bstack11llll1ll_opy_(config):
  bstack111l1ll1_opy_ = {}
  if bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬઈ") in config:
    bstack111l1ll1_opy_ = config[bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ઉ")]
  if bstack1l11ll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩઊ") in config:
    bstack111l1ll1_opy_ = config[bstack1l11ll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪઋ")]
  proxy = bstack11ll1ll1_opy_(config)
  if proxy:
    if proxy.endswith(bstack1l11ll_opy_ (u"ࠬ࠴ࡰࡢࡥࠪઌ")) and os.path.isfile(proxy):
      bstack111l1ll1_opy_[bstack1l11ll_opy_ (u"࠭࠭ࡱࡣࡦ࠱࡫࡯࡬ࡦࠩઍ")] = proxy
    else:
      parsed_url = None
      if proxy.endswith(bstack1l11ll_opy_ (u"ࠧ࠯ࡲࡤࡧࠬ઎")):
        proxies = bstack1111l1111_opy_(config, bstack1llllll11l_opy_())
        if len(proxies) > 0:
          protocol, bstack1l11ll1l1l_opy_ = proxies.popitem()
          if bstack1l11ll_opy_ (u"ࠣ࠼࠲࠳ࠧએ") in bstack1l11ll1l1l_opy_:
            parsed_url = urlparse(bstack1l11ll1l1l_opy_)
          else:
            parsed_url = urlparse(protocol + bstack1l11ll_opy_ (u"ࠤ࠽࠳࠴ࠨઐ") + bstack1l11ll1l1l_opy_)
      else:
        parsed_url = urlparse(proxy)
      if parsed_url and parsed_url.hostname: bstack111l1ll1_opy_[bstack1l11ll_opy_ (u"ࠪࡴࡷࡵࡸࡺࡊࡲࡷࡹ࠭ઑ")] = str(parsed_url.hostname)
      if parsed_url and parsed_url.port: bstack111l1ll1_opy_[bstack1l11ll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡓࡳࡷࡺࠧ઒")] = str(parsed_url.port)
      if parsed_url and parsed_url.username: bstack111l1ll1_opy_[bstack1l11ll_opy_ (u"ࠬࡶࡲࡰࡺࡼ࡙ࡸ࡫ࡲࠨઓ")] = str(parsed_url.username)
      if parsed_url and parsed_url.password: bstack111l1ll1_opy_[bstack1l11ll_opy_ (u"࠭ࡰࡳࡱࡻࡽࡕࡧࡳࡴࠩઔ")] = str(parsed_url.password)
  return bstack111l1ll1_opy_
def bstack111llll1_opy_(config):
  if bstack1l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡈࡵ࡮ࡵࡧࡻࡸࡔࡶࡴࡪࡱࡱࡷࠬક") in config:
    return config[bstack1l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡉ࡯࡯ࡶࡨࡼࡹࡕࡰࡵ࡫ࡲࡲࡸ࠭ખ")]
  return {}
def bstack1llll111l1_opy_(caps):
  global bstack1llll11l11_opy_
  if bstack1l11ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪગ") in caps:
    caps[bstack1l11ll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫઘ")][bstack1l11ll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࠪઙ")] = True
    if bstack1llll11l11_opy_:
      caps[bstack1l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ચ")][bstack1l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨછ")] = bstack1llll11l11_opy_
  else:
    caps[bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࠬજ")] = True
    if bstack1llll11l11_opy_:
      caps[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩઝ")] = bstack1llll11l11_opy_
def bstack1lllll1ll_opy_():
  global CONFIG
  if bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ઞ") in CONFIG and is_true(CONFIG[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧટ")]):
    bstack111l1ll1_opy_ = bstack11llll1ll_opy_(CONFIG)
    bstack1l11ll11l1_opy_(CONFIG[bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧઠ")], bstack111l1ll1_opy_)
def bstack1l11ll11l1_opy_(key, bstack111l1ll1_opy_):
  global bstack1l1l111l11_opy_
  logger.info(bstack1ll1l1ll11_opy_)
  try:
    bstack1l1l111l11_opy_ = Local()
    bstack1l11l1l111_opy_ = {bstack1l11ll_opy_ (u"ࠬࡱࡥࡺࠩડ"): key}
    bstack1l11l1l111_opy_.update(bstack111l1ll1_opy_)
    logger.debug(bstack1ll11ll1ll_opy_.format(str(bstack1l11l1l111_opy_)))
    bstack1l1l111l11_opy_.start(**bstack1l11l1l111_opy_)
    if bstack1l1l111l11_opy_.isRunning():
      logger.info(bstack1llll1111_opy_)
  except Exception as e:
    bstack1111ll11_opy_(bstack1l1ll1l11_opy_.format(str(e)))
def bstack111lllll_opy_():
  global bstack1l1l111l11_opy_
  if bstack1l1l111l11_opy_.isRunning():
    logger.info(bstack111ll1l11_opy_)
    bstack1l1l111l11_opy_.stop()
  bstack1l1l111l11_opy_ = None
def bstack1ll1ll11l1_opy_(bstack1l1ll1l11l_opy_=[]):
  global CONFIG
  bstack1l1l1111l_opy_ = []
  bstack1ll11llll1_opy_ = [bstack1l11ll_opy_ (u"࠭࡯ࡴࠩઢ"), bstack1l11ll_opy_ (u"ࠧࡰࡵ࡙ࡩࡷࡹࡩࡰࡰࠪણ"), bstack1l11ll_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࡏࡣࡰࡩࠬત"), bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰ࡚ࡪࡸࡳࡪࡱࡱࠫથ"), bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨદ"), bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬધ")]
  try:
    for err in bstack1l1ll1l11l_opy_:
      bstack1l11l11ll1_opy_ = {}
      for k in bstack1ll11llll1_opy_:
        val = CONFIG[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨન")][int(err[bstack1l11ll_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ઩")])].get(k)
        if val:
          bstack1l11l11ll1_opy_[k] = val
      if(err[bstack1l11ll_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭પ")] != bstack1l11ll_opy_ (u"ࠨࠩફ")):
        bstack1l11l11ll1_opy_[bstack1l11ll_opy_ (u"ࠩࡷࡩࡸࡺࡳࠨબ")] = {
          err[bstack1l11ll_opy_ (u"ࠪࡲࡦࡳࡥࠨભ")]: err[bstack1l11ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪમ")]
        }
        bstack1l1l1111l_opy_.append(bstack1l11l11ll1_opy_)
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡧࡱࡵࡱࡦࡺࡴࡪࡰࡪࠤࡩࡧࡴࡢࠢࡩࡳࡷࠦࡥࡷࡧࡱࡸ࠿ࠦࠧય") + str(e))
  finally:
    return bstack1l1l1111l_opy_
def bstack1lllllllll_opy_(file_name):
  bstack1l111lllll_opy_ = []
  try:
    bstack11lll11l1_opy_ = os.path.join(tempfile.gettempdir(), file_name)
    if os.path.exists(bstack11lll11l1_opy_):
      with open(bstack11lll11l1_opy_) as f:
        bstack1l11llll11_opy_ = json.load(f)
        bstack1l111lllll_opy_ = bstack1l11llll11_opy_
      os.remove(bstack11lll11l1_opy_)
    return bstack1l111lllll_opy_
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡨࡶࡷࡵࡲࠡ࡮࡬ࡷࡹࡀࠠࠨર") + str(e))
def bstack1l11l1l1l1_opy_():
  global bstack1ll11l1111_opy_
  global bstack1l1111l1l_opy_
  global bstack1l11l111l1_opy_
  global bstack1l1l1l111l_opy_
  global bstack1llll111ll_opy_
  global bstack1l11lll11l_opy_
  global CONFIG
  percy.shutdown()
  bstack1l11l1111l_opy_ = os.environ.get(bstack1l11ll_opy_ (u"ࠧࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࡢ࡙ࡘࡋࡄࠨ઱"))
  if bstack1l11l1111l_opy_ in [bstack1l11ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧલ"), bstack1l11ll_opy_ (u"ࠩࡳࡥࡧࡵࡴࠨળ")]:
    bstack1l11l1llll_opy_()
  if bstack1ll11l1111_opy_:
    logger.warning(bstack1lll11l1ll_opy_.format(str(bstack1ll11l1111_opy_)))
  else:
    try:
      bstack1l1l1ll1ll_opy_ = bstack1llllllll_opy_(bstack1l11ll_opy_ (u"ࠪ࠲ࡧࡹࡴࡢࡥ࡮࠱ࡨࡵ࡮ࡧ࡫ࡪ࠲࡯ࡹ࡯࡯ࠩ઴"), logger)
      if bstack1l1l1ll1ll_opy_.get(bstack1l11ll_opy_ (u"ࠫࡳࡻࡤࡨࡧࡢࡰࡴࡩࡡ࡭ࠩવ")) and bstack1l1l1ll1ll_opy_.get(bstack1l11ll_opy_ (u"ࠬࡴࡵࡥࡩࡨࡣࡱࡵࡣࡢ࡮ࠪશ")).get(bstack1l11ll_opy_ (u"࠭ࡨࡰࡵࡷࡲࡦࡳࡥࠨષ")):
        logger.warning(bstack1lll11l1ll_opy_.format(str(bstack1l1l1ll1ll_opy_[bstack1l11ll_opy_ (u"ࠧ࡯ࡷࡧ࡫ࡪࡥ࡬ࡰࡥࡤࡰࠬસ")][bstack1l11ll_opy_ (u"ࠨࡪࡲࡷࡹࡴࡡ࡮ࡧࠪહ")])))
    except Exception as e:
      logger.error(e)
  logger.info(bstack1l1lll11ll_opy_)
  global bstack1l1l111l11_opy_
  if bstack1l1l111l11_opy_:
    bstack111lllll_opy_()
  try:
    for driver in bstack1l1111l1l_opy_:
      driver.quit()
  except Exception as e:
    pass
  logger.info(bstack1lllll1l1l_opy_)
  if bstack1l11lll11l_opy_ == bstack1l11ll_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨ઺"):
    bstack1llll111ll_opy_ = bstack1lllllllll_opy_(bstack1l11ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠴ࡪࡴࡱࡱࠫ઻"))
  if bstack1l11lll11l_opy_ == bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷ઼ࠫ") and len(bstack1l1l1l111l_opy_) == 0:
    bstack1l1l1l111l_opy_ = bstack1lllllllll_opy_(bstack1l11ll_opy_ (u"ࠬࡶࡷࡠࡲࡼࡸࡪࡹࡴࡠࡧࡵࡶࡴࡸ࡟࡭࡫ࡶࡸ࠳ࡰࡳࡰࡰࠪઽ"))
    if len(bstack1l1l1l111l_opy_) == 0:
      bstack1l1l1l111l_opy_ = bstack1lllllllll_opy_(bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹࡥࡰࡱࡲࡢࡩࡷࡸ࡯ࡳࡡ࡯࡭ࡸࡺ࠮࡫ࡵࡲࡲࠬા"))
  bstack1l1l1111l1_opy_ = bstack1l11ll_opy_ (u"ࠧࠨિ")
  if len(bstack1l11l111l1_opy_) > 0:
    bstack1l1l1111l1_opy_ = bstack1ll1ll11l1_opy_(bstack1l11l111l1_opy_)
  elif len(bstack1l1l1l111l_opy_) > 0:
    bstack1l1l1111l1_opy_ = bstack1ll1ll11l1_opy_(bstack1l1l1l111l_opy_)
  elif len(bstack1llll111ll_opy_) > 0:
    bstack1l1l1111l1_opy_ = bstack1ll1ll11l1_opy_(bstack1llll111ll_opy_)
  elif len(bstack1lllll111l_opy_) > 0:
    bstack1l1l1111l1_opy_ = bstack1ll1ll11l1_opy_(bstack1lllll111l_opy_)
  if bool(bstack1l1l1111l1_opy_):
    bstack11111llll_opy_(bstack1l1l1111l1_opy_)
  else:
    bstack11111llll_opy_()
  bstack1llll1lll1_opy_(bstack1ll111l1ll_opy_, logger)
  bstack1ll1l1111l_opy_.bstack1l1l1l1_opy_(CONFIG)
  if len(bstack1llll111ll_opy_) > 0:
    sys.exit(len(bstack1llll111ll_opy_))
def bstack1lllll1111_opy_(self, *args):
  logger.error(bstack1l1lll111l_opy_)
  bstack1l11l1l1l1_opy_()
  sys.exit(1)
def bstack1111ll11_opy_(err):
  logger.critical(bstack1lll11111l_opy_.format(str(err)))
  bstack11111llll_opy_(bstack1lll11111l_opy_.format(str(err)), True)
  atexit.unregister(bstack1l11l1l1l1_opy_)
  bstack1l11l1llll_opy_()
  sys.exit(1)
def bstack1llllll1l1_opy_(error, message):
  logger.critical(str(error))
  logger.critical(message)
  bstack11111llll_opy_(message, True)
  atexit.unregister(bstack1l11l1l1l1_opy_)
  bstack1l11l1llll_opy_()
  sys.exit(1)
def bstack1l1lll11l1_opy_():
  global CONFIG
  global bstack1lllll1ll1_opy_
  global bstack11ll1l1l1_opy_
  global bstack1l1l1111_opy_
  CONFIG = bstack11ll11ll1_opy_()
  load_dotenv(CONFIG.get(bstack1l11ll_opy_ (u"ࠨࡧࡱࡺࡋ࡯࡬ࡦࠩી")))
  bstack1lllll1l1_opy_()
  bstack1l11l11l_opy_()
  CONFIG = bstack111l111l_opy_(CONFIG)
  update(CONFIG, bstack11ll1l1l1_opy_)
  update(CONFIG, bstack1lllll1ll1_opy_)
  CONFIG = bstack1ll11111l_opy_(CONFIG)
  bstack1l1l1111_opy_ = bstack11l1l1111_opy_(CONFIG)
  bstack1llll1ll_opy_.set_property(bstack1l11ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࠪુ"), bstack1l1l1111_opy_)
  if (bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ૂ") in CONFIG and bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧૃ") in bstack1lllll1ll1_opy_) or (
          bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨૄ") in CONFIG and bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩૅ") not in bstack11ll1l1l1_opy_):
    if os.getenv(bstack1l11ll_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑ࡟ࡄࡑࡐࡆࡎࡔࡅࡅࡡࡅ࡙ࡎࡒࡄࡠࡋࡇࠫ૆")):
      CONFIG[bstack1l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪે")] = os.getenv(bstack1l11ll_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡡࡆࡓࡒࡈࡉࡏࡇࡇࡣࡇ࡛ࡉࡍࡆࡢࡍࡉ࠭ૈ"))
    else:
      bstack11l11111l_opy_()
  elif (bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ૉ") not in CONFIG and bstack1l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭૊") in CONFIG) or (
          bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨો") in bstack11ll1l1l1_opy_ and bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩૌ") not in bstack1lllll1ll1_opy_):
    del (CONFIG[bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳ્ࠩ")])
  if bstack1l11l1ll11_opy_(CONFIG):
    bstack1111ll11_opy_(bstack1l1ll111l_opy_)
  bstack1111l11ll_opy_()
  bstack11lll1ll1_opy_()
  if bstack1llllll111_opy_:
    CONFIG[bstack1l11ll_opy_ (u"ࠨࡣࡳࡴࠬ૎")] = bstack111ll11ll_opy_(CONFIG)
    logger.info(bstack1ll1l11111_opy_.format(CONFIG[bstack1l11ll_opy_ (u"ࠩࡤࡴࡵ࠭૏")]))
  if not bstack1l1l1111_opy_:
    CONFIG[bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ૐ")] = [{}]
def bstack1llll11111_opy_(config, bstack11l1l1l11_opy_):
  global CONFIG
  global bstack1llllll111_opy_
  CONFIG = config
  bstack1llllll111_opy_ = bstack11l1l1l11_opy_
def bstack11lll1ll1_opy_():
  global CONFIG
  global bstack1llllll111_opy_
  if bstack1l11ll_opy_ (u"ࠫࡦࡶࡰࠨ૑") in CONFIG:
    try:
      from appium import version
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack1llll1ll1_opy_)
    bstack1llllll111_opy_ = True
    bstack1llll1ll_opy_.set_property(bstack1l11ll_opy_ (u"ࠬࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠫ૒"), True)
def bstack111ll11ll_opy_(config):
  bstack11111ll1_opy_ = bstack1l11ll_opy_ (u"࠭ࠧ૓")
  app = config[bstack1l11ll_opy_ (u"ࠧࡢࡲࡳࠫ૔")]
  if isinstance(app, str):
    if os.path.splitext(app)[1] in bstack1ll1l1llll_opy_:
      if os.path.exists(app):
        bstack11111ll1_opy_ = bstack1lllllll11_opy_(config, app)
      elif bstack1l1l11l1l1_opy_(app):
        bstack11111ll1_opy_ = app
      else:
        bstack1111ll11_opy_(bstack1ll1l1l11_opy_.format(app))
    else:
      if bstack1l1l11l1l1_opy_(app):
        bstack11111ll1_opy_ = app
      elif os.path.exists(app):
        bstack11111ll1_opy_ = bstack1lllllll11_opy_(app)
      else:
        bstack1111ll11_opy_(bstack1l1l11l11l_opy_)
  else:
    if len(app) > 2:
      bstack1111ll11_opy_(bstack1111111l1_opy_)
    elif len(app) == 2:
      if bstack1l11ll_opy_ (u"ࠨࡲࡤࡸ࡭࠭૕") in app and bstack1l11ll_opy_ (u"ࠩࡦࡹࡸࡺ࡯࡮ࡡ࡬ࡨࠬ૖") in app:
        if os.path.exists(app[bstack1l11ll_opy_ (u"ࠪࡴࡦࡺࡨࠨ૗")]):
          bstack11111ll1_opy_ = bstack1lllllll11_opy_(config, app[bstack1l11ll_opy_ (u"ࠫࡵࡧࡴࡩࠩ૘")], app[bstack1l11ll_opy_ (u"ࠬࡩࡵࡴࡶࡲࡱࡤ࡯ࡤࠨ૙")])
        else:
          bstack1111ll11_opy_(bstack1ll1l1l11_opy_.format(app))
      else:
        bstack1111ll11_opy_(bstack1111111l1_opy_)
    else:
      for key in app:
        if key in bstack1l1l1ll11l_opy_:
          if key == bstack1l11ll_opy_ (u"࠭ࡰࡢࡶ࡫ࠫ૚"):
            if os.path.exists(app[key]):
              bstack11111ll1_opy_ = bstack1lllllll11_opy_(config, app[key])
            else:
              bstack1111ll11_opy_(bstack1ll1l1l11_opy_.format(app))
          else:
            bstack11111ll1_opy_ = app[key]
        else:
          bstack1111ll11_opy_(bstack1l1ll1ll1_opy_)
  return bstack11111ll1_opy_
def bstack1l1l11l1l1_opy_(bstack11111ll1_opy_):
  import re
  bstack1ll1lll1ll_opy_ = re.compile(bstack1l11ll_opy_ (u"ࡲࠣࡠ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡢ࡟࠯࡞࠰ࡡ࠯ࠪࠢ૛"))
  bstack11l1ll11_opy_ = re.compile(bstack1l11ll_opy_ (u"ࡳࠤࡡ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡜ࡠ࠰࡟࠱ࡢ࠰࠯࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡠࡤ࠴࡜࠮࡟࠭ࠨࠧ૜"))
  if bstack1l11ll_opy_ (u"ࠩࡥࡷ࠿࠵࠯ࠨ૝") in bstack11111ll1_opy_ or re.fullmatch(bstack1ll1lll1ll_opy_, bstack11111ll1_opy_) or re.fullmatch(bstack11l1ll11_opy_, bstack11111ll1_opy_):
    return True
  else:
    return False
def bstack1lllllll11_opy_(config, path, bstack1lll1l111_opy_=None):
  import requests
  from requests_toolbelt.multipart.encoder import MultipartEncoder
  import hashlib
  md5_hash = hashlib.md5(open(os.path.abspath(path), bstack1l11ll_opy_ (u"ࠪࡶࡧ࠭૞")).read()).hexdigest()
  bstack11l111lll_opy_ = bstack1lll111ll1_opy_(md5_hash)
  bstack11111ll1_opy_ = None
  if bstack11l111lll_opy_:
    logger.info(bstack1lll1l1lll_opy_.format(bstack11l111lll_opy_, md5_hash))
    return bstack11l111lll_opy_
  bstack11lll111l_opy_ = MultipartEncoder(
    fields={
      bstack1l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࠩ૟"): (os.path.basename(path), open(os.path.abspath(path), bstack1l11ll_opy_ (u"ࠬࡸࡢࠨૠ")), bstack1l11ll_opy_ (u"࠭ࡴࡦࡺࡷ࠳ࡵࡲࡡࡪࡰࠪૡ")),
      bstack1l11ll_opy_ (u"ࠧࡤࡷࡶࡸࡴࡳ࡟ࡪࡦࠪૢ"): bstack1lll1l111_opy_
    }
  )
  response = requests.post(bstack1l111lll_opy_, data=bstack11lll111l_opy_,
                           headers={bstack1l11ll_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧૣ"): bstack11lll111l_opy_.content_type},
                           auth=(config[bstack1l11ll_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ૤")], config[bstack1l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭૥")]))
  try:
    res = json.loads(response.text)
    bstack11111ll1_opy_ = res[bstack1l11ll_opy_ (u"ࠫࡦࡶࡰࡠࡷࡵࡰࠬ૦")]
    logger.info(bstack1ll1l1111_opy_.format(bstack11111ll1_opy_))
    bstack1111l11l1_opy_(md5_hash, bstack11111ll1_opy_)
  except ValueError as err:
    bstack1111ll11_opy_(bstack1ll1l11ll1_opy_.format(str(err)))
  return bstack11111ll1_opy_
def bstack1111l11ll_opy_():
  global CONFIG
  global bstack1l11lll11_opy_
  bstack1l1l1ll1_opy_ = 0
  bstack1l1l1l1111_opy_ = 1
  if bstack1l11ll_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬ૧") in CONFIG:
    bstack1l1l1l1111_opy_ = CONFIG[bstack1l11ll_opy_ (u"࠭ࡰࡢࡴࡤࡰࡱ࡫࡬ࡴࡒࡨࡶࡕࡲࡡࡵࡨࡲࡶࡲ࠭૨")]
  if bstack1l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ૩") in CONFIG:
    bstack1l1l1ll1_opy_ = len(CONFIG[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ૪")])
  bstack1l11lll11_opy_ = int(bstack1l1l1l1111_opy_) * int(bstack1l1l1ll1_opy_)
def bstack1lll111ll1_opy_(md5_hash):
  bstack111l1l11l_opy_ = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠩࢁࠫ૫")), bstack1l11ll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪ૬"), bstack1l11ll_opy_ (u"ࠫࡦࡶࡰࡖࡲ࡯ࡳࡦࡪࡍࡅ࠷ࡋࡥࡸ࡮࠮࡫ࡵࡲࡲࠬ૭"))
  if os.path.exists(bstack111l1l11l_opy_):
    bstack1ll1lllll_opy_ = json.load(open(bstack111l1l11l_opy_, bstack1l11ll_opy_ (u"ࠬࡸࡢࠨ૮")))
    if md5_hash in bstack1ll1lllll_opy_:
      bstack1111l1ll1_opy_ = bstack1ll1lllll_opy_[md5_hash]
      bstack11l1lll1_opy_ = datetime.datetime.now()
      bstack1llll1lll_opy_ = datetime.datetime.strptime(bstack1111l1ll1_opy_[bstack1l11ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ૯")], bstack1l11ll_opy_ (u"ࠧࠦࡦ࠲ࠩࡲ࠵࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫ૰"))
      if (bstack11l1lll1_opy_ - bstack1llll1lll_opy_).days > 30:
        return None
      elif version.parse(str(__version__)) > version.parse(bstack1111l1ll1_opy_[bstack1l11ll_opy_ (u"ࠨࡵࡧ࡯ࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭૱")]):
        return None
      return bstack1111l1ll1_opy_[bstack1l11ll_opy_ (u"ࠩ࡬ࡨࠬ૲")]
  else:
    return None
def bstack1111l11l1_opy_(md5_hash, bstack11111ll1_opy_):
  bstack1ll11ll11_opy_ = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠪࢂࠬ૳")), bstack1l11ll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ૴"))
  if not os.path.exists(bstack1ll11ll11_opy_):
    os.makedirs(bstack1ll11ll11_opy_)
  bstack111l1l11l_opy_ = os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠬࢄࠧ૵")), bstack1l11ll_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭૶"), bstack1l11ll_opy_ (u"ࠧࡢࡲࡳ࡙ࡵࡲ࡯ࡢࡦࡐࡈ࠺ࡎࡡࡴࡪ࠱࡮ࡸࡵ࡮ࠨ૷"))
  bstack1ll1l11l1l_opy_ = {
    bstack1l11ll_opy_ (u"ࠨ࡫ࡧࠫ૸"): bstack11111ll1_opy_,
    bstack1l11ll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬૹ"): datetime.datetime.strftime(datetime.datetime.now(), bstack1l11ll_opy_ (u"ࠪࠩࡩ࠵ࠥ࡮࠱ࠨ࡝ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧૺ")),
    bstack1l11ll_opy_ (u"ࠫࡸࡪ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩૻ"): str(__version__)
  }
  if os.path.exists(bstack111l1l11l_opy_):
    bstack1ll1lllll_opy_ = json.load(open(bstack111l1l11l_opy_, bstack1l11ll_opy_ (u"ࠬࡸࡢࠨૼ")))
  else:
    bstack1ll1lllll_opy_ = {}
  bstack1ll1lllll_opy_[md5_hash] = bstack1ll1l11l1l_opy_
  with open(bstack111l1l11l_opy_, bstack1l11ll_opy_ (u"ࠨࡷࠬࠤ૽")) as outfile:
    json.dump(bstack1ll1lllll_opy_, outfile)
def bstack1l11ll11l_opy_(self):
  return
def bstack11111l11l_opy_(self):
  return
def bstack111l11111_opy_(self):
  global bstack1llll111l_opy_
  bstack1llll111l_opy_(self)
def bstack1l1ll111ll_opy_():
  global bstack1l111ll1l_opy_
  bstack1l111ll1l_opy_ = True
def bstack1l1111lll_opy_(self):
  global bstack1ll1l1l1ll_opy_
  global bstack1l1l1lll11_opy_
  global bstack1111l11l_opy_
  try:
    if bstack1l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ૾") in bstack1ll1l1l1ll_opy_ and self.session_id != None and bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠨࡶࡨࡷࡹ࡙ࡴࡢࡶࡸࡷࠬ૿"), bstack1l11ll_opy_ (u"ࠩࠪ଀")) != bstack1l11ll_opy_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫଁ"):
      bstack1l11llll1_opy_ = bstack1l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫଂ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬଃ")
      if bstack1l11llll1_opy_ == bstack1l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭଄"):
        bstack1l111111l_opy_(logger)
      if self != None:
        bstack1l11lll1l_opy_(self, bstack1l11llll1_opy_, bstack1l11ll_opy_ (u"ࠧ࠭ࠢࠪଅ").join(threading.current_thread().bstackTestErrorMessages))
    threading.current_thread().testStatus = bstack1l11ll_opy_ (u"ࠨࠩଆ")
    if bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩଇ") in bstack1ll1l1l1ll_opy_ and getattr(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩଈ"), None):
      bstack1lll1l1l_opy_.bstack1lll1l11_opy_(self, bstack1ll111lll_opy_, logger, wait=True)
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡭࡯࡬ࡦࠢࡰࡥࡷࡱࡩ࡯ࡩࠣࡷࡹࡧࡴࡶࡵ࠽ࠤࠧଉ") + str(e))
  bstack1111l11l_opy_(self)
  self.session_id = None
def bstack111l1l1l1_opy_(self, command_executor=bstack1l11ll_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠶࠷࠸࠹ࠨଊ"), *args, **kwargs):
  bstack111l1ll1l_opy_ = bstack111111111_opy_(self, command_executor, *args, **kwargs)
  try:
    logger.debug(bstack1l11ll_opy_ (u"࠭ࡃࡰ࡯ࡰࡥࡳࡪࠠࡆࡺࡨࡧࡺࡺ࡯ࡳࠢࡺ࡬ࡪࡴࠠࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣ࡭ࡸࠦࡦࡢ࡮ࡶࡩࠥ࠳ࠠࡼࡿࠪଋ").format(str(command_executor)))
    logger.debug(bstack1l11ll_opy_ (u"ࠧࡉࡷࡥࠤ࡚ࡘࡌࠡ࡫ࡶࠤ࠲ࠦࡻࡾࠩଌ").format(str(command_executor._url)))
    from selenium.webdriver.remote.remote_connection import RemoteConnection
    if isinstance(command_executor, RemoteConnection) and bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰࠫ଍") in command_executor._url:
      bstack1llll1ll_opy_.set_property(bstack1l11ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡶࡩࡸࡹࡩࡰࡰࠪ଎"), True)
  except:
    pass
  if (isinstance(command_executor, str) and bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠭ଏ") in command_executor):
    bstack1llll1ll_opy_.set_property(bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬଐ"), True)
  threading.current_thread().bstackSessionDriver = self
  bstack111lll1_opy_.bstack11ll11lll_opy_(self)
  return bstack111l1ll1l_opy_
def bstack1lllllll1l_opy_(args):
  return bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷ࠭଑") in str(args)
def bstack1l11l1l1ll_opy_(self, driver_command, *args, **kwargs):
  global bstack11l1111l1_opy_
  global bstack1lll11l1l_opy_
  bstack1l1l11ll11_opy_ = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"࠭ࡩࡴࡃ࠴࠵ࡾ࡚ࡥࡴࡶࠪ଒"), None) and bstack1111111_opy_(
          threading.current_thread(), bstack1l11ll_opy_ (u"ࠧࡢ࠳࠴ࡽࡕࡲࡡࡵࡨࡲࡶࡲ࠭ଓ"), None)
  bstack1l11ll111_opy_ = getattr(self, bstack1l11ll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡂ࠳࠴ࡽࡘ࡮࡯ࡶ࡮ࡧࡗࡨࡧ࡮ࠨଔ"), None) != None and getattr(self, bstack1l11ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡃ࠴࠵ࡾ࡙ࡨࡰࡷ࡯ࡨࡘࡩࡡ࡯ࠩକ"), None) == True
  if not bstack1lll11l1l_opy_ and bstack1l1l1111_opy_ and bstack1l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪଖ") in CONFIG and CONFIG[bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫଗ")] == True and bstack1lll1ll1l1_opy_.bstack1llllllll1_opy_(driver_command) and (bstack1l11ll111_opy_ or bstack1l1l11ll11_opy_) and not bstack1lllllll1l_opy_(args):
    try:
      bstack1lll11l1l_opy_ = True
      logger.debug(bstack1l11ll_opy_ (u"ࠬࡖࡥࡳࡨࡲࡶࡲ࡯࡮ࡨࠢࡶࡧࡦࡴࠠࡧࡱࡵࠤࢀࢃࠧଘ").format(driver_command))
      logger.debug(perform_scan(self, driver_command=driver_command))
    except Exception as err:
      logger.debug(bstack1l11ll_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡳࡩࡷ࡬࡯ࡳ࡯ࠣࡷࡨࡧ࡮ࠡࡽࢀࠫଙ").format(str(err)))
    bstack1lll11l1l_opy_ = False
  response = bstack11l1111l1_opy_(self, driver_command, *args, **kwargs)
  if bstack1l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ଚ") in str(bstack1ll1l1l1ll_opy_).lower() and bstack111lll1_opy_.on():
    try:
      if driver_command == bstack1l11ll_opy_ (u"ࠨࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࠬଛ"):
        bstack111lll1_opy_.bstack1l1l111111_opy_({
            bstack1l11ll_opy_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨଜ"): response[bstack1l11ll_opy_ (u"ࠪࡺࡦࡲࡵࡦࠩଝ")],
            bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫଞ"): bstack111lll1_opy_.current_test_uuid() if bstack111lll1_opy_.current_test_uuid() else bstack111lll1_opy_.current_hook_uuid()
        })
    except:
      pass
  return response
def bstack1l1ll1llll_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
  global CONFIG
  global bstack1l1l1lll11_opy_
  global bstack1llll1llll_opy_
  global bstack111l11l1_opy_
  global bstack1llll1ll11_opy_
  global bstack1llll11ll1_opy_
  global bstack1ll1l1l1ll_opy_
  global bstack111111111_opy_
  global bstack1l1111l1l_opy_
  global bstack1ll111l111_opy_
  global bstack1ll111lll_opy_
  CONFIG[bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡗࡉࡑࠧଟ")] = str(bstack1ll1l1l1ll_opy_) + str(__version__)
  command_executor = bstack1llllll11l_opy_()
  logger.debug(bstack11lll111_opy_.format(command_executor))
  proxy = bstack11llll11l_opy_(CONFIG, proxy)
  bstack111l1llll_opy_ = 0 if bstack1llll1llll_opy_ < 0 else bstack1llll1llll_opy_
  try:
    if bstack1llll1ll11_opy_ is True:
      bstack111l1llll_opy_ = int(multiprocessing.current_process().name)
    elif bstack1llll11ll1_opy_ is True:
      bstack111l1llll_opy_ = int(threading.current_thread().name)
  except:
    bstack111l1llll_opy_ = 0
  bstack1ll1l111l1_opy_ = bstack111ll11l1_opy_(CONFIG, bstack111l1llll_opy_)
  logger.debug(bstack1ll11l1lll_opy_.format(str(bstack1ll1l111l1_opy_)))
  if bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪଠ") in CONFIG and is_true(CONFIG[bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫଡ")]):
    bstack1llll111l1_opy_(bstack1ll1l111l1_opy_)
  if bstack1lll1ll1_opy_.bstack1l1ll11ll_opy_(CONFIG, bstack111l1llll_opy_) and bstack1lll1ll1_opy_.bstack1l1l11l111_opy_(bstack1ll1l111l1_opy_, options):
    threading.current_thread().a11yPlatform = True
    bstack1lll1ll1_opy_.set_capabilities(bstack1ll1l111l1_opy_, CONFIG)
  if desired_capabilities:
    bstack1l1l11ll1l_opy_ = bstack111l111l_opy_(desired_capabilities)
    bstack1l1l11ll1l_opy_[bstack1l11ll_opy_ (u"ࠨࡷࡶࡩ࡜࠹ࡃࠨଢ")] = bstack1l11ll1l11_opy_(CONFIG)
    bstack1llll11l1l_opy_ = bstack111ll11l1_opy_(bstack1l1l11ll1l_opy_)
    if bstack1llll11l1l_opy_:
      bstack1ll1l111l1_opy_ = update(bstack1llll11l1l_opy_, bstack1ll1l111l1_opy_)
    desired_capabilities = None
  if options:
    bstack11lllllll_opy_(options, bstack1ll1l111l1_opy_)
  if not options:
    options = bstack1ll1ll111_opy_(bstack1ll1l111l1_opy_)
  bstack1ll111lll_opy_ = CONFIG.get(bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬଣ"))[bstack111l1llll_opy_]
  if proxy and bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠪ࠸࠳࠷࠰࠯࠲ࠪତ")):
    options.proxy(proxy)
  if options and bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠫ࠸࠴࠸࠯࠲ࠪଥ")):
    desired_capabilities = None
  if (
          not options and not desired_capabilities
  ) or (
          bstack1ll11lll11_opy_() < version.parse(bstack1l11ll_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫଦ")) and not desired_capabilities
  ):
    desired_capabilities = {}
    desired_capabilities.update(bstack1ll1l111l1_opy_)
  logger.info(bstack1l1l11l11_opy_)
  if bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"࠭࠴࠯࠳࠳࠲࠵࠭ଧ")):
    bstack111111111_opy_(self, command_executor=command_executor,
              options=options, keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠧ࠴࠰࠻࠲࠵࠭ନ")):
    bstack111111111_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities, options=options,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠨ࠴࠱࠹࠸࠴࠰ࠨ଩")):
    bstack111111111_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  else:
    bstack111111111_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive)
  try:
    bstack1lll111ll_opy_ = bstack1l11ll_opy_ (u"ࠩࠪପ")
    if bstack1ll11lll11_opy_() >= version.parse(bstack1l11ll_opy_ (u"ࠪ࠸࠳࠶࠮࠱ࡤ࠴ࠫଫ")):
      bstack1lll111ll_opy_ = self.caps.get(bstack1l11ll_opy_ (u"ࠦࡴࡶࡴࡪ࡯ࡤࡰࡍࡻࡢࡖࡴ࡯ࠦବ"))
    else:
      bstack1lll111ll_opy_ = self.capabilities.get(bstack1l11ll_opy_ (u"ࠧࡵࡰࡵ࡫ࡰࡥࡱࡎࡵࡣࡗࡵࡰࠧଭ"))
    if bstack1lll111ll_opy_:
      bstack1lll1l1ll_opy_(bstack1lll111ll_opy_)
      if bstack1ll11lll11_opy_() <= version.parse(bstack1l11ll_opy_ (u"࠭࠳࠯࠳࠶࠲࠵࠭ମ")):
        self.command_executor._url = bstack1l11ll_opy_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࠣଯ") + bstack1ll1l1l1l1_opy_ + bstack1l11ll_opy_ (u"ࠣ࠼࠻࠴࠴ࡽࡤ࠰ࡪࡸࡦࠧର")
      else:
        self.command_executor._url = bstack1l11ll_opy_ (u"ࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠦ଱") + bstack1lll111ll_opy_ + bstack1l11ll_opy_ (u"ࠥ࠳ࡼࡪ࠯ࡩࡷࡥࠦଲ")
      logger.debug(bstack11ll1l111_opy_.format(bstack1lll111ll_opy_))
    else:
      logger.debug(bstack1l1lllll11_opy_.format(bstack1l11ll_opy_ (u"ࠦࡔࡶࡴࡪ࡯ࡤࡰࠥࡎࡵࡣࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨࠧଳ")))
  except Exception as e:
    logger.debug(bstack1l1lllll11_opy_.format(e))
  if bstack1l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫ଴") in bstack1ll1l1l1ll_opy_:
    bstack111ll1ll1_opy_(bstack1llll1llll_opy_, bstack1ll111l111_opy_)
  bstack1l1l1lll11_opy_ = self.session_id
  if bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ଵ") in bstack1ll1l1l1ll_opy_ or bstack1l11ll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧଶ") in bstack1ll1l1l1ll_opy_ or bstack1l11ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧଷ") in bstack1ll1l1l1ll_opy_:
    threading.current_thread().bstackSessionId = self.session_id
    threading.current_thread().bstackSessionDriver = self
    threading.current_thread().bstackTestErrorMessages = []
    bstack111lll1_opy_.bstack11ll11lll_opy_(self)
  bstack1l1111l1l_opy_.append(self)
  if bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬସ") in CONFIG and bstack1l11ll_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨହ") in CONFIG[bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ଺")][bstack111l1llll_opy_]:
    bstack111l11l1_opy_ = CONFIG[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ଻")][bstack111l1llll_opy_][bstack1l11ll_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨ଼ࠫ")]
  logger.debug(bstack111llll1l_opy_.format(bstack1l1l1lll11_opy_))
try:
  try:
    import Browser
    from subprocess import Popen
    def bstack11ll1ll1l_opy_(self, args, bufsize=-1, executable=None,
              stdin=None, stdout=None, stderr=None,
              preexec_fn=None, close_fds=True,
              shell=False, cwd=None, env=None, universal_newlines=None,
              startupinfo=None, creationflags=0,
              restore_signals=True, start_new_session=False,
              pass_fds=(), *, user=None, group=None, extra_groups=None,
              encoding=None, errors=None, text=None, umask=-1, pipesize=-1):
      global CONFIG
      global bstack1l11l1l11_opy_
      if(bstack1l11ll_opy_ (u"ࠢࡪࡰࡧࡩࡽ࠴ࡪࡴࠤଽ") in args[1]):
        with open(os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"ࠨࢀࠪା")), bstack1l11ll_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩି"), bstack1l11ll_opy_ (u"ࠪ࠲ࡸ࡫ࡳࡴ࡫ࡲࡲ࡮ࡪࡳ࠯ࡶࡻࡸࠬୀ")), bstack1l11ll_opy_ (u"ࠫࡼ࠭ୁ")) as fp:
          fp.write(bstack1l11ll_opy_ (u"ࠧࠨୂ"))
        if(not os.path.exists(os.path.join(os.path.dirname(args[1]), bstack1l11ll_opy_ (u"ࠨࡩ࡯ࡦࡨࡼࡤࡨࡳࡵࡣࡦ࡯࠳ࡰࡳࠣୃ")))):
          with open(args[1], bstack1l11ll_opy_ (u"ࠧࡳࠩୄ")) as f:
            lines = f.readlines()
            index = next((i for i, line in enumerate(lines) if bstack1l11ll_opy_ (u"ࠨࡣࡶࡽࡳࡩࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡢࡲࡪࡽࡐࡢࡩࡨࠬࡨࡵ࡮ࡵࡧࡻࡸ࠱ࠦࡰࡢࡩࡨࠤࡂࠦࡶࡰ࡫ࡧࠤ࠵࠯ࠧ୅") in line), None)
            if index is not None:
                lines.insert(index+2, bstack111lll111_opy_)
            lines.insert(1, bstack1lllll11l_opy_)
            f.seek(0)
            with open(os.path.join(os.path.dirname(args[1]), bstack1l11ll_opy_ (u"ࠤ࡬ࡲࡩ࡫ࡸࡠࡤࡶࡸࡦࡩ࡫࠯࡬ࡶࠦ୆")), bstack1l11ll_opy_ (u"ࠪࡻࠬେ")) as bstack1ll11llll_opy_:
              bstack1ll11llll_opy_.writelines(lines)
        CONFIG[bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡖࡈࡐ࠭ୈ")] = str(bstack1ll1l1l1ll_opy_) + str(__version__)
        bstack111l1llll_opy_ = 0 if bstack1llll1llll_opy_ < 0 else bstack1llll1llll_opy_
        try:
          if bstack1llll1ll11_opy_ is True:
            bstack111l1llll_opy_ = int(multiprocessing.current_process().name)
          elif bstack1llll11ll1_opy_ is True:
            bstack111l1llll_opy_ = int(threading.current_thread().name)
        except:
          bstack111l1llll_opy_ = 0
        CONFIG[bstack1l11ll_opy_ (u"ࠧࡻࡳࡦ࡙࠶ࡇࠧ୉")] = False
        CONFIG[bstack1l11ll_opy_ (u"ࠨࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠧ୊")] = True
        bstack1ll1l111l1_opy_ = bstack111ll11l1_opy_(CONFIG, bstack111l1llll_opy_)
        logger.debug(bstack1ll11l1lll_opy_.format(str(bstack1ll1l111l1_opy_)))
        if CONFIG.get(bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫୋ")):
          bstack1llll111l1_opy_(bstack1ll1l111l1_opy_)
        if bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫୌ") in CONFIG and bstack1l11ll_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫୍ࠧ") in CONFIG[bstack1l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭୎")][bstack111l1llll_opy_]:
          bstack111l11l1_opy_ = CONFIG[bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ୏")][bstack111l1llll_opy_][bstack1l11ll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪ୐")]
        args.append(os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"࠭ࡾࠨ୑")), bstack1l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ୒"), bstack1l11ll_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ୓")))
        args.append(str(threading.get_ident()))
        args.append(json.dumps(bstack1ll1l111l1_opy_))
        args[1] = os.path.join(os.path.dirname(args[1]), bstack1l11ll_opy_ (u"ࠤ࡬ࡲࡩ࡫ࡸࡠࡤࡶࡸࡦࡩ࡫࠯࡬ࡶࠦ୔"))
      bstack1l11l1l11_opy_ = True
      return bstack1lll11ll11_opy_(self, args, bufsize=bufsize, executable=executable,
                    stdin=stdin, stdout=stdout, stderr=stderr,
                    preexec_fn=preexec_fn, close_fds=close_fds,
                    shell=shell, cwd=cwd, env=env, universal_newlines=universal_newlines,
                    startupinfo=startupinfo, creationflags=creationflags,
                    restore_signals=restore_signals, start_new_session=start_new_session,
                    pass_fds=pass_fds, user=user, group=group, extra_groups=extra_groups,
                    encoding=encoding, errors=errors, text=text, umask=umask, pipesize=pipesize)
  except Exception as e:
    pass
  import playwright._impl._api_structures
  import playwright._impl._helper
  def bstack11ll1111l_opy_(self,
        executablePath = None,
        channel = None,
        args = None,
        ignoreDefaultArgs = None,
        handleSIGINT = None,
        handleSIGTERM = None,
        handleSIGHUP = None,
        timeout = None,
        env = None,
        headless = None,
        devtools = None,
        proxy = None,
        downloadsPath = None,
        slowMo = None,
        tracesDir = None,
        chromiumSandbox = None,
        firefoxUserPrefs = None
        ):
    global CONFIG
    global bstack1llll1llll_opy_
    global bstack111l11l1_opy_
    global bstack1llll1ll11_opy_
    global bstack1llll11ll1_opy_
    global bstack1ll1l1l1ll_opy_
    CONFIG[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡕࡇࡏࠬ୕")] = str(bstack1ll1l1l1ll_opy_) + str(__version__)
    bstack111l1llll_opy_ = 0 if bstack1llll1llll_opy_ < 0 else bstack1llll1llll_opy_
    try:
      if bstack1llll1ll11_opy_ is True:
        bstack111l1llll_opy_ = int(multiprocessing.current_process().name)
      elif bstack1llll11ll1_opy_ is True:
        bstack111l1llll_opy_ = int(threading.current_thread().name)
    except:
      bstack111l1llll_opy_ = 0
    CONFIG[bstack1l11ll_opy_ (u"ࠦ࡮ࡹࡐ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠥୖ")] = True
    bstack1ll1l111l1_opy_ = bstack111ll11l1_opy_(CONFIG, bstack111l1llll_opy_)
    logger.debug(bstack1ll11l1lll_opy_.format(str(bstack1ll1l111l1_opy_)))
    if CONFIG.get(bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩୗ")):
      bstack1llll111l1_opy_(bstack1ll1l111l1_opy_)
    if bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ୘") in CONFIG and bstack1l11ll_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬ୙") in CONFIG[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ୚")][bstack111l1llll_opy_]:
      bstack111l11l1_opy_ = CONFIG[bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ୛")][bstack111l1llll_opy_][bstack1l11ll_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨଡ଼")]
    import urllib
    import json
    bstack1l1l1llll_opy_ = bstack1l11ll_opy_ (u"ࠫࡼࡹࡳ࠻࠱࠲ࡧࡩࡶ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺ࠿ࡤࡣࡳࡷࡂ࠭ଢ଼") + urllib.parse.quote(json.dumps(bstack1ll1l111l1_opy_))
    browser = self.connect(bstack1l1l1llll_opy_)
    return browser
except Exception as e:
    pass
def bstack1ll1111ll1_opy_():
    global bstack1l11l1l11_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack11ll1111l_opy_
        bstack1l11l1l11_opy_ = True
    except Exception as e:
        pass
    try:
      import Browser
      from subprocess import Popen
      Popen.__init__ = bstack11ll1ll1l_opy_
      bstack1l11l1l11_opy_ = True
    except Exception as e:
      pass
def bstack1ll1111111_opy_(context, bstack1l1lll1111_opy_):
  try:
    context.page.evaluate(bstack1l11ll_opy_ (u"ࠧࡥࠠ࠾ࡀࠣࡿࢂࠨ୞"), bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠪୟ")+ json.dumps(bstack1l1lll1111_opy_) + bstack1l11ll_opy_ (u"ࠢࡾࡿࠥୠ"))
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠣࡧࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡴࡡ࡮ࡧࠣࡿࢂࠨୡ"), e)
def bstack11l111111_opy_(context, message, level):
  try:
    context.page.evaluate(bstack1l11ll_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥୢ"), bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨୣ") + json.dumps(message) + bstack1l11ll_opy_ (u"ࠫ࠱ࠨ࡬ࡦࡸࡨࡰࠧࡀࠧ୤") + json.dumps(level) + bstack1l11ll_opy_ (u"ࠬࢃࡽࠨ୥"))
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠨࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡤࡲࡳࡵࡴࡢࡶ࡬ࡳࡳࠦࡻࡾࠤ୦"), e)
def bstack1l1ll11l1_opy_(self, url):
  global bstack1l11l1l11l_opy_
  try:
    bstack1l11l1ll1_opy_(url)
  except Exception as err:
    logger.debug(bstack1ll11l1l1l_opy_.format(str(err)))
  try:
    bstack1l11l1l11l_opy_(self, url)
  except Exception as e:
    try:
      bstack11111111_opy_ = str(e)
      if any(err_msg in bstack11111111_opy_ for err_msg in bstack1lll1ll1l_opy_):
        bstack1l11l1ll1_opy_(url, True)
    except Exception as err:
      logger.debug(bstack1ll11l1l1l_opy_.format(str(err)))
    raise e
def bstack11lll11l_opy_(self):
  global bstack1lll1l1l11_opy_
  bstack1lll1l1l11_opy_ = self
  return
def bstack1ll111l1l_opy_(self):
  global bstack1ll11ll1l1_opy_
  bstack1ll11ll1l1_opy_ = self
  return
def bstack11llllll1_opy_(test_name, bstack1l11l1ll1l_opy_):
  global CONFIG
  if CONFIG.get(bstack1l11ll_opy_ (u"ࠧࡱࡧࡵࡧࡾ࠭୧"), False):
    bstack111llll11_opy_ = os.path.relpath(bstack1l11l1ll1l_opy_, start=os.getcwd())
    suite_name, _ = os.path.splitext(bstack111llll11_opy_)
    bstack111l11lll_opy_ = suite_name + bstack1l11ll_opy_ (u"ࠣ࠯ࠥ୨") + test_name
    threading.current_thread().percySessionName = bstack111l11lll_opy_
def bstack1l1l1lll1_opy_(self, test, *args, **kwargs):
  global bstack11l1l11l1_opy_
  test_name = None
  bstack1l11l1ll1l_opy_ = None
  if test:
    test_name = str(test.name)
    bstack1l11l1ll1l_opy_ = str(test.source)
  bstack11llllll1_opy_(test_name, bstack1l11l1ll1l_opy_)
  bstack11l1l11l1_opy_(self, test, *args, **kwargs)
def bstack1lll111111_opy_(driver, bstack111l11lll_opy_):
  if not bstack1lll11lll1_opy_ and bstack111l11lll_opy_:
      bstack111l1l1l_opy_ = {
          bstack1l11ll_opy_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩ୩"): bstack1l11ll_opy_ (u"ࠪࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫ୪"),
          bstack1l11ll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧ୫"): {
              bstack1l11ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ୬"): bstack111l11lll_opy_
          }
      }
      bstack1l11lllll1_opy_ = bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࢀࠫ୭").format(json.dumps(bstack111l1l1l_opy_))
      driver.execute_script(bstack1l11lllll1_opy_)
  if bstack11ll11l1l_opy_:
      bstack11l1l1ll1_opy_ = {
          bstack1l11ll_opy_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࠧ୮"): bstack1l11ll_opy_ (u"ࠨࡣࡱࡲࡴࡺࡡࡵࡧࠪ୯"),
          bstack1l11ll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ୰"): {
              bstack1l11ll_opy_ (u"ࠪࡨࡦࡺࡡࠨୱ"): bstack111l11lll_opy_ + bstack1l11ll_opy_ (u"ࠫࠥࡶࡡࡴࡵࡨࡨࠦ࠭୲"),
              bstack1l11ll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫ୳"): bstack1l11ll_opy_ (u"࠭ࡩ࡯ࡨࡲࠫ୴")
          }
      }
      if bstack11ll11l1l_opy_.status == bstack1l11ll_opy_ (u"ࠧࡑࡃࡖࡗࠬ୵"):
          bstack1lll11ll1_opy_ = bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂ࠭୶").format(json.dumps(bstack11l1l1ll1_opy_))
          driver.execute_script(bstack1lll11ll1_opy_)
          bstack1l11lll1l_opy_(driver, bstack1l11ll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩ୷"))
      elif bstack11ll11l1l_opy_.status == bstack1l11ll_opy_ (u"ࠪࡊࡆࡏࡌࠨ୸"):
          reason = bstack1l11ll_opy_ (u"ࠦࠧ୹")
          bstack1l11ll1111_opy_ = bstack111l11lll_opy_ + bstack1l11ll_opy_ (u"ࠬࠦࡦࡢ࡫࡯ࡩࡩ࠭୺")
          if bstack11ll11l1l_opy_.message:
              reason = str(bstack11ll11l1l_opy_.message)
              bstack1l11ll1111_opy_ = bstack1l11ll1111_opy_ + bstack1l11ll_opy_ (u"࠭ࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠥ࠭୻") + reason
          bstack11l1l1ll1_opy_[bstack1l11ll_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪ୼")] = {
              bstack1l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧ୽"): bstack1l11ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨ୾"),
              bstack1l11ll_opy_ (u"ࠪࡨࡦࡺࡡࠨ୿"): bstack1l11ll1111_opy_
          }
          bstack1lll11ll1_opy_ = bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩ஀").format(json.dumps(bstack11l1l1ll1_opy_))
          driver.execute_script(bstack1lll11ll1_opy_)
          bstack1l11lll1l_opy_(driver, bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ஁"), reason)
          bstack1lllll11l1_opy_(reason, str(bstack11ll11l1l_opy_), str(bstack1llll1llll_opy_), logger)
def bstack1lll1l1111_opy_(driver, test):
  if CONFIG.get(bstack1l11ll_opy_ (u"࠭ࡰࡦࡴࡦࡽࠬஂ"), False) and CONFIG.get(bstack1l11ll_opy_ (u"ࠧࡱࡧࡵࡧࡾࡉࡡࡱࡶࡸࡶࡪࡓ࡯ࡥࡧࠪஃ"), bstack1l11ll_opy_ (u"ࠣࡣࡸࡸࡴࠨ஄")) == bstack1l11ll_opy_ (u"ࠤࡷࡩࡸࡺࡣࡢࡵࡨࠦஅ"):
      bstack11ll11l1_opy_ = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡴࡪࡸࡣࡺࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ஆ"), None)
      bstack11111lll_opy_(driver, bstack11ll11l1_opy_)
  if bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫ࡮ࡹࡁ࠲࠳ࡼࡘࡪࡹࡴࠨஇ"), None) and bstack1111111_opy_(
          threading.current_thread(), bstack1l11ll_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫஈ"), None):
      logger.info(bstack1l11ll_opy_ (u"ࠨࡁࡶࡶࡲࡱࡦࡺࡥࠡࡶࡨࡷࡹࠦࡣࡢࡵࡨࠤࡪࡾࡥࡤࡷࡷ࡭ࡴࡴࠠࡩࡣࡶࠤࡪࡴࡤࡦࡦ࠱ࠤࡕࡸ࡯ࡤࡧࡶࡷ࡮ࡴࡧࠡࡨࡲࡶࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡺࡥࡴࡶ࡬ࡲ࡬ࠦࡩࡴࠢࡸࡲࡩ࡫ࡲࡸࡣࡼ࠲ࠥࠨஉ"))
      bstack1lll1ll1_opy_.bstack1ll1l111_opy_(driver, class_name=test.parent.name, name=test.name, module_name=None,
                              path=test.source, bstack1llll11l_opy_=bstack1ll111lll_opy_)
def bstack1l1llll11_opy_(test, bstack111l11lll_opy_):
    try:
      data = {}
      if test:
        data[bstack1l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬஊ")] = bstack111l11lll_opy_
      if bstack11ll11l1l_opy_:
        if bstack11ll11l1l_opy_.status == bstack1l11ll_opy_ (u"ࠨࡒࡄࡗࡘ࠭஋"):
          data[bstack1l11ll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ஌")] = bstack1l11ll_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪ஍")
        elif bstack11ll11l1l_opy_.status == bstack1l11ll_opy_ (u"ࠫࡋࡇࡉࡍࠩஎ"):
          data[bstack1l11ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬஏ")] = bstack1l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ஐ")
          if bstack11ll11l1l_opy_.message:
            data[bstack1l11ll_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ஑")] = str(bstack11ll11l1l_opy_.message)
      user = CONFIG[bstack1l11ll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪஒ")]
      key = CONFIG[bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬஓ")]
      url = bstack1l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࢀࢃ࠺ࡼࡿࡃࡥࡵ࡯࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡥࡺࡺ࡯࡮ࡣࡷࡩ࠴ࡹࡥࡴࡵ࡬ࡳࡳࡹ࠯ࡼࡿ࠱࡮ࡸࡵ࡮ࠨஔ").format(user, key, bstack1l1l1lll11_opy_)
      headers = {
        bstack1l11ll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪக"): bstack1l11ll_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ஖"),
      }
      if bool(data):
        requests.put(url, json=data, headers=headers)
    except Exception as e:
      logger.error(bstack11l1l111_opy_.format(str(e)))
def bstack11111lll1_opy_(test, bstack111l11lll_opy_):
  global CONFIG
  global bstack1ll11ll1l1_opy_
  global bstack1lll1l1l11_opy_
  global bstack1l1l1lll11_opy_
  global bstack11ll11l1l_opy_
  global bstack111l11l1_opy_
  global bstack11llll1l1_opy_
  global bstack1ll11l11l1_opy_
  global bstack1l11l11l11_opy_
  global bstack1l1ll11lll_opy_
  global bstack1l1111l1l_opy_
  global bstack1ll111lll_opy_
  try:
    if not bstack1l1l1lll11_opy_:
      with open(os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"࠭ࡾࠨ஗")), bstack1l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ஘"), bstack1l11ll_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪங"))) as f:
        bstack1l1l11llll_opy_ = json.loads(bstack1l11ll_opy_ (u"ࠤࡾࠦச") + f.read().strip() + bstack1l11ll_opy_ (u"ࠪࠦࡽࠨ࠺ࠡࠤࡼࠦࠬ஛") + bstack1l11ll_opy_ (u"ࠦࢂࠨஜ"))
        bstack1l1l1lll11_opy_ = bstack1l1l11llll_opy_[str(threading.get_ident())]
  except:
    pass
  if bstack1l1111l1l_opy_:
    for driver in bstack1l1111l1l_opy_:
      if bstack1l1l1lll11_opy_ == driver.session_id:
        if test:
          bstack1lll1l1111_opy_(driver, test)
        bstack1lll111111_opy_(driver, bstack111l11lll_opy_)
  elif bstack1l1l1lll11_opy_:
    bstack1l1llll11_opy_(test, bstack111l11lll_opy_)
  if bstack1ll11ll1l1_opy_:
    bstack1ll11l11l1_opy_(bstack1ll11ll1l1_opy_)
  if bstack1lll1l1l11_opy_:
    bstack1l11l11l11_opy_(bstack1lll1l1l11_opy_)
  if bstack1l111ll1l_opy_:
    bstack1l1ll11lll_opy_()
def bstack1llll1111l_opy_(self, test, *args, **kwargs):
  bstack111l11lll_opy_ = None
  if test:
    bstack111l11lll_opy_ = str(test.name)
  bstack11111lll1_opy_(test, bstack111l11lll_opy_)
  bstack11llll1l1_opy_(self, test, *args, **kwargs)
def bstack1111l1l1l_opy_(self, parent, test, skip_on_failure=None, rpa=False):
  global bstack111111ll1_opy_
  global CONFIG
  global bstack1l1111l1l_opy_
  global bstack1l1l1lll11_opy_
  bstack1ll11lllll_opy_ = None
  try:
    if bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫ஝"), None):
      try:
        if not bstack1l1l1lll11_opy_:
          with open(os.path.join(os.path.expanduser(bstack1l11ll_opy_ (u"࠭ࡾࠨஞ")), bstack1l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧட"), bstack1l11ll_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ஠"))) as f:
            bstack1l1l11llll_opy_ = json.loads(bstack1l11ll_opy_ (u"ࠤࡾࠦ஡") + f.read().strip() + bstack1l11ll_opy_ (u"ࠪࠦࡽࠨ࠺ࠡࠤࡼࠦࠬ஢") + bstack1l11ll_opy_ (u"ࠦࢂࠨண"))
            bstack1l1l1lll11_opy_ = bstack1l1l11llll_opy_[str(threading.get_ident())]
      except:
        pass
      if bstack1l1111l1l_opy_:
        for driver in bstack1l1111l1l_opy_:
          if bstack1l1l1lll11_opy_ == driver.session_id:
            bstack1ll11lllll_opy_ = driver
    bstack11l1llll1_opy_ = bstack1lll1ll1_opy_.bstack1l1l1ll11_opy_(CONFIG, test.tags)
    if bstack1ll11lllll_opy_:
      threading.current_thread().isA11yTest = bstack1lll1ll1_opy_.bstack1lll1llll1_opy_(bstack1ll11lllll_opy_, bstack11l1llll1_opy_)
    else:
      threading.current_thread().isA11yTest = bstack11l1llll1_opy_
  except:
    pass
  bstack111111ll1_opy_(self, parent, test, skip_on_failure=skip_on_failure, rpa=rpa)
  global bstack11ll11l1l_opy_
  bstack11ll11l1l_opy_ = self._test
def bstack11l1ll1ll_opy_():
  global bstack11l1lllll_opy_
  try:
    if os.path.exists(bstack11l1lllll_opy_):
      os.remove(bstack11l1lllll_opy_)
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡥࡧ࡯ࡩࡹ࡯࡮ࡨࠢࡵࡳࡧࡵࡴࠡࡴࡨࡴࡴࡸࡴࠡࡨ࡬ࡰࡪࡀࠠࠨத") + str(e))
def bstack11l1l1lll_opy_():
  global bstack11l1lllll_opy_
  bstack1l1l1ll1ll_opy_ = {}
  try:
    if not os.path.isfile(bstack11l1lllll_opy_):
      with open(bstack11l1lllll_opy_, bstack1l11ll_opy_ (u"࠭ࡷࠨ஥")):
        pass
      with open(bstack11l1lllll_opy_, bstack1l11ll_opy_ (u"ࠢࡸ࠭ࠥ஦")) as outfile:
        json.dump({}, outfile)
    if os.path.exists(bstack11l1lllll_opy_):
      bstack1l1l1ll1ll_opy_ = json.load(open(bstack11l1lllll_opy_, bstack1l11ll_opy_ (u"ࠨࡴࡥࠫ஧")))
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡷ࡫ࡡࡥ࡫ࡱ࡫ࠥࡸ࡯ࡣࡱࡷࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫࡯࡬ࡦ࠼ࠣࠫந") + str(e))
  finally:
    return bstack1l1l1ll1ll_opy_
def bstack111ll1ll1_opy_(platform_index, item_index):
  global bstack11l1lllll_opy_
  try:
    bstack1l1l1ll1ll_opy_ = bstack11l1l1lll_opy_()
    bstack1l1l1ll1ll_opy_[item_index] = platform_index
    with open(bstack11l1lllll_opy_, bstack1l11ll_opy_ (u"ࠥࡻ࠰ࠨன")) as outfile:
      json.dump(bstack1l1l1ll1ll_opy_, outfile)
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡷࡳ࡫ࡷ࡭ࡳ࡭ࠠࡵࡱࠣࡶࡴࡨ࡯ࡵࠢࡵࡩࡵࡵࡲࡵࠢࡩ࡭ࡱ࡫࠺ࠡࠩப") + str(e))
def bstack11l11ll1l_opy_(bstack111ll1lll_opy_):
  global CONFIG
  bstack1l1l111ll_opy_ = bstack1l11ll_opy_ (u"ࠬ࠭஫")
  if not bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ஬") in CONFIG:
    logger.info(bstack1l11ll_opy_ (u"ࠧࡏࡱࠣࡴࡱࡧࡴࡧࡱࡵࡱࡸࠦࡰࡢࡵࡶࡩࡩࠦࡵ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡪࡩࡳ࡫ࡲࡢࡶࡨࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫ࡵࡲࠡࡔࡲࡦࡴࡺࠠࡳࡷࡱࠫ஭"))
  try:
    platform = CONFIG[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫம")][bstack111ll1lll_opy_]
    if bstack1l11ll_opy_ (u"ࠩࡲࡷࠬய") in platform:
      bstack1l1l111ll_opy_ += str(platform[bstack1l11ll_opy_ (u"ࠪࡳࡸ࠭ர")]) + bstack1l11ll_opy_ (u"ࠫ࠱ࠦࠧற")
    if bstack1l11ll_opy_ (u"ࠬࡵࡳࡗࡧࡵࡷ࡮ࡵ࡮ࠨல") in platform:
      bstack1l1l111ll_opy_ += str(platform[bstack1l11ll_opy_ (u"࠭࡯ࡴࡘࡨࡶࡸ࡯࡯࡯ࠩள")]) + bstack1l11ll_opy_ (u"ࠧ࠭ࠢࠪழ")
    if bstack1l11ll_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࡏࡣࡰࡩࠬவ") in platform:
      bstack1l1l111ll_opy_ += str(platform[bstack1l11ll_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࡐࡤࡱࡪ࠭ஶ")]) + bstack1l11ll_opy_ (u"ࠪ࠰ࠥ࠭ஷ")
    if bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ஸ") in platform:
      bstack1l1l111ll_opy_ += str(platform[bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠧஹ")]) + bstack1l11ll_opy_ (u"࠭ࠬࠡࠩ஺")
    if bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ஻") in platform:
      bstack1l1l111ll_opy_ += str(platform[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭஼")]) + bstack1l11ll_opy_ (u"ࠩ࠯ࠤࠬ஽")
    if bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫா") in platform:
      bstack1l1l111ll_opy_ += str(platform[bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬி")]) + bstack1l11ll_opy_ (u"ࠬ࠲ࠠࠨீ")
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"࠭ࡓࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡰࡨࡶࡦࡺࡩ࡯ࡩࠣࡴࡱࡧࡴࡧࡱࡵࡱࠥࡹࡴࡳ࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡵࡩࡵࡵࡲࡵࠢࡪࡩࡳ࡫ࡲࡢࡶ࡬ࡳࡳ࠭ு") + str(e))
  finally:
    if bstack1l1l111ll_opy_[len(bstack1l1l111ll_opy_) - 2:] == bstack1l11ll_opy_ (u"ࠧ࠭ࠢࠪூ"):
      bstack1l1l111ll_opy_ = bstack1l1l111ll_opy_[:-2]
    return bstack1l1l111ll_opy_
def bstack1l11l111_opy_(path, bstack1l1l111ll_opy_):
  try:
    import xml.etree.ElementTree as ET
    bstack111ll1111_opy_ = ET.parse(path)
    bstack11lll11ll_opy_ = bstack111ll1111_opy_.getroot()
    bstack111l111ll_opy_ = None
    for suite in bstack11lll11ll_opy_.iter(bstack1l11ll_opy_ (u"ࠨࡵࡸ࡭ࡹ࡫ࠧ௃")):
      if bstack1l11ll_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩ௄") in suite.attrib:
        suite.attrib[bstack1l11ll_opy_ (u"ࠪࡲࡦࡳࡥࠨ௅")] += bstack1l11ll_opy_ (u"ࠫࠥ࠭ெ") + bstack1l1l111ll_opy_
        bstack111l111ll_opy_ = suite
    bstack1ll1ll1l1_opy_ = None
    for robot in bstack11lll11ll_opy_.iter(bstack1l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫே")):
      bstack1ll1ll1l1_opy_ = robot
    bstack1111llll1_opy_ = len(bstack1ll1ll1l1_opy_.findall(bstack1l11ll_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬை")))
    if bstack1111llll1_opy_ == 1:
      bstack1ll1ll1l1_opy_.remove(bstack1ll1ll1l1_opy_.findall(bstack1l11ll_opy_ (u"ࠧࡴࡷ࡬ࡸࡪ࠭௉"))[0])
      bstack1lll1lll11_opy_ = ET.Element(bstack1l11ll_opy_ (u"ࠨࡵࡸ࡭ࡹ࡫ࠧொ"), attrib={bstack1l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧோ"): bstack1l11ll_opy_ (u"ࠪࡗࡺ࡯ࡴࡦࡵࠪௌ"), bstack1l11ll_opy_ (u"ࠫ࡮ࡪ்ࠧ"): bstack1l11ll_opy_ (u"ࠬࡹ࠰ࠨ௎")})
      bstack1ll1ll1l1_opy_.insert(1, bstack1lll1lll11_opy_)
      bstack1l1llllll_opy_ = None
      for suite in bstack1ll1ll1l1_opy_.iter(bstack1l11ll_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬ௏")):
        bstack1l1llllll_opy_ = suite
      bstack1l1llllll_opy_.append(bstack111l111ll_opy_)
      bstack11l11111_opy_ = None
      for status in bstack111l111ll_opy_.iter(bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧௐ")):
        bstack11l11111_opy_ = status
      bstack1l1llllll_opy_.append(bstack11l11111_opy_)
    bstack111ll1111_opy_.write(path)
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡴࡦࡸࡳࡪࡰࡪࠤࡼ࡮ࡩ࡭ࡧࠣ࡫ࡪࡴࡥࡳࡣࡷ࡭ࡳ࡭ࠠࡳࡱࡥࡳࡹࠦࡲࡦࡲࡲࡶࡹ࠭௑") + str(e))
def bstack111ll11l_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name):
  global bstack1ll1lllll1_opy_
  global CONFIG
  if bstack1l11ll_opy_ (u"ࠤࡳࡽࡹ࡮࡯࡯ࡲࡤࡸ࡭ࠨ௒") in options:
    del options[bstack1l11ll_opy_ (u"ࠥࡴࡾࡺࡨࡰࡰࡳࡥࡹ࡮ࠢ௓")]
  bstack1l1l111ll1_opy_ = bstack11l1l1lll_opy_()
  for bstack11l11ll11_opy_ in bstack1l1l111ll1_opy_.keys():
    path = os.path.join(os.getcwd(), bstack1l11ll_opy_ (u"ࠫࡵࡧࡢࡰࡶࡢࡶࡪࡹࡵ࡭ࡶࡶࠫ௔"), str(bstack11l11ll11_opy_), bstack1l11ll_opy_ (u"ࠬࡵࡵࡵࡲࡸࡸ࠳ࡾ࡭࡭ࠩ௕"))
    bstack1l11l111_opy_(path, bstack11l11ll1l_opy_(bstack1l1l111ll1_opy_[bstack11l11ll11_opy_]))
  bstack11l1ll1ll_opy_()
  return bstack1ll1lllll1_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name)
def bstack1lll1ll111_opy_(self, ff_profile_dir):
  global bstack1l11ll1ll1_opy_
  if not ff_profile_dir:
    return None
  return bstack1l11ll1ll1_opy_(self, ff_profile_dir)
def bstack111lll1ll_opy_(datasources, opts_for_run, outs_dir, pabot_args, suite_group):
  from pabot.pabot import QueueItem
  global CONFIG
  global bstack1llll11l11_opy_
  bstack1lll111lll_opy_ = []
  if bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ௖") in CONFIG:
    bstack1lll111lll_opy_ = CONFIG[bstack1l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪௗ")]
  return [
    QueueItem(
      datasources,
      outs_dir,
      opts_for_run,
      suite,
      pabot_args[bstack1l11ll_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࠤ௘")],
      pabot_args[bstack1l11ll_opy_ (u"ࠤࡹࡩࡷࡨ࡯ࡴࡧࠥ௙")],
      argfile,
      pabot_args.get(bstack1l11ll_opy_ (u"ࠥ࡬࡮ࡼࡥࠣ௚")),
      pabot_args[bstack1l11ll_opy_ (u"ࠦࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠢ௛")],
      platform[0],
      bstack1llll11l11_opy_
    )
    for suite in suite_group
    for argfile in pabot_args[bstack1l11ll_opy_ (u"ࠧࡧࡲࡨࡷࡰࡩࡳࡺࡦࡪ࡮ࡨࡷࠧ௜")] or [(bstack1l11ll_opy_ (u"ࠨࠢ௝"), None)]
    for platform in enumerate(bstack1lll111lll_opy_)
  ]
def bstack111ll1ll_opy_(self, datasources, outs_dir, options,
                        execution_item, command, verbose, argfile,
                        hive=None, processes=0, platform_index=0, bstack1l1lll1lll_opy_=bstack1l11ll_opy_ (u"ࠧࠨ௞")):
  global bstack1l1l111l1l_opy_
  self.platform_index = platform_index
  self.bstack1l1l1l11l1_opy_ = bstack1l1lll1lll_opy_
  bstack1l1l111l1l_opy_(self, datasources, outs_dir, options,
                      execution_item, command, verbose, argfile, hive, processes)
def bstack1lll11l1l1_opy_(caller_id, datasources, is_last, item, outs_dir):
  global bstack11l11lll_opy_
  global bstack1111l1lll_opy_
  if not bstack1l11ll_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ௟") in item.options:
    item.options[bstack1l11ll_opy_ (u"ࠩࡹࡥࡷ࡯ࡡࡣ࡮ࡨࠫ௠")] = []
  for v in item.options[bstack1l11ll_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬ௡")]:
    if bstack1l11ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡔࡑࡇࡔࡇࡑࡕࡑࡎࡔࡄࡆ࡚ࠪ௢") in v:
      item.options[bstack1l11ll_opy_ (u"ࠬࡼࡡࡳ࡫ࡤࡦࡱ࡫ࠧ௣")].remove(v)
    if bstack1l11ll_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡉࡌࡊࡃࡕࡋࡘ࠭௤") in v:
      item.options[bstack1l11ll_opy_ (u"ࠧࡷࡣࡵ࡭ࡦࡨ࡬ࡦࠩ௥")].remove(v)
  item.options[bstack1l11ll_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ௦")].insert(0, bstack1l11ll_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡒࡏࡅ࡙ࡌࡏࡓࡏࡌࡒࡉࡋࡘ࠻ࡽࢀࠫ௧").format(item.platform_index))
  item.options[bstack1l11ll_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬ௨")].insert(0, bstack1l11ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡈࡊࡌࡌࡐࡅࡄࡐࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒ࠻ࡽࢀࠫ௩").format(item.bstack1l1l1l11l1_opy_))
  if bstack1111l1lll_opy_:
    item.options[bstack1l11ll_opy_ (u"ࠬࡼࡡࡳ࡫ࡤࡦࡱ࡫ࠧ௪")].insert(0, bstack1l11ll_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡉࡌࡊࡃࡕࡋࡘࡀࡻࡾࠩ௫").format(bstack1111l1lll_opy_))
  return bstack11l11lll_opy_(caller_id, datasources, is_last, item, outs_dir)
def bstack11lllll11_opy_(command, item_index):
  if bstack1llll1ll_opy_.get_property(bstack1l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ௬")):
    os.environ[bstack1l11ll_opy_ (u"ࠨࡅࡘࡖࡗࡋࡎࡕࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡉࡇࡔࡂࠩ௭")] = json.dumps(CONFIG[bstack1l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ௮")][item_index % bstack111l1l11_opy_])
  global bstack1111l1lll_opy_
  if bstack1111l1lll_opy_:
    command[0] = command[0].replace(bstack1l11ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ௯"), bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠰ࡷࡩࡱࠠࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠡ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠠࠨ௰") + str(
      item_index) + bstack1l11ll_opy_ (u"ࠬࠦࠧ௱") + bstack1111l1lll_opy_, 1)
  else:
    command[0] = command[0].replace(bstack1l11ll_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬ௲"),
                                    bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠳ࡳࡥ࡭ࠣࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠤ࠲࠳ࡢࡴࡶࡤࡧࡰࡥࡩࡵࡧࡰࡣ࡮ࡴࡤࡦࡺࠣࠫ௳") + str(item_index), 1)
def bstack1lll1111ll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index):
  global bstack1111l1l11_opy_
  bstack11lllll11_opy_(command, item_index)
  return bstack1111l1l11_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
def bstack1l1lll1ll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir):
  global bstack1111l1l11_opy_
  bstack11lllll11_opy_(command, item_index)
  return bstack1111l1l11_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
def bstack1ll111llll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout):
  global bstack1111l1l11_opy_
  bstack11lllll11_opy_(command, item_index)
  return bstack1111l1l11_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
def bstack11ll1l11_opy_(self, runner, quiet=False, capture=True):
  global bstack1ll1111lll_opy_
  bstack1l11ll111l_opy_ = bstack1ll1111lll_opy_(self, runner, quiet=False, capture=True)
  if self.exception:
    if not hasattr(runner, bstack1l11ll_opy_ (u"ࠨࡧࡻࡧࡪࡶࡴࡪࡱࡱࡣࡦࡸࡲࠨ௴")):
      runner.exception_arr = []
    if not hasattr(runner, bstack1l11ll_opy_ (u"ࠩࡨࡼࡨࡥࡴࡳࡣࡦࡩࡧࡧࡣ࡬ࡡࡤࡶࡷ࠭௵")):
      runner.exc_traceback_arr = []
    runner.exception = self.exception
    runner.exc_traceback = self.exc_traceback
    runner.exception_arr.append(self.exception)
    runner.exc_traceback_arr.append(self.exc_traceback)
  return bstack1l11ll111l_opy_
def bstack1l1l11111_opy_(self, name, context, *args):
  os.environ[bstack1l11ll_opy_ (u"ࠪࡇ࡚ࡘࡒࡆࡐࡗࡣࡕࡒࡁࡕࡈࡒࡖࡒࡥࡄࡂࡖࡄࠫ௶")] = json.dumps(CONFIG[bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ௷")][int(threading.current_thread()._name) % bstack111l1l11_opy_])
  global bstack111111l1_opy_
  if name == bstack1l11ll_opy_ (u"ࠬࡨࡥࡧࡱࡵࡩࡤ࡬ࡥࡢࡶࡸࡶࡪ࠭௸"):
    bstack111111l1_opy_(self, name, context, *args)
    try:
      if not bstack1lll11lll1_opy_:
        bstack1ll11lllll_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11l1lll_opy_(bstack1l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬ௹")) else context.browser
        bstack1l1lll1111_opy_ = str(self.feature.name)
        bstack1ll1111111_opy_(context, bstack1l1lll1111_opy_)
        bstack1ll11lllll_opy_.execute_script(bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠤࠬ௺") + json.dumps(bstack1l1lll1111_opy_) + bstack1l11ll_opy_ (u"ࠨࡿࢀࠫ௻"))
      self.driver_before_scenario = False
    except Exception as e:
      logger.debug(bstack1l11ll_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡥࡵࠢࡶࡩࡸࡹࡩࡰࡰࠣࡲࡦࡳࡥࠡ࡫ࡱࠤࡧ࡫ࡦࡰࡴࡨࠤ࡫࡫ࡡࡵࡷࡵࡩ࠿ࠦࡻࡾࠩ௼").format(str(e)))
  elif name == bstack1l11ll_opy_ (u"ࠪࡦࡪ࡬࡯ࡳࡧࡢࡷࡨ࡫࡮ࡢࡴ࡬ࡳࠬ௽"):
    bstack111111l1_opy_(self, name, context, *args)
    try:
      if not hasattr(self, bstack1l11ll_opy_ (u"ࠫࡩࡸࡩࡷࡧࡵࡣࡧ࡫ࡦࡰࡴࡨࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭௾")):
        self.driver_before_scenario = True
      if (not bstack1lll11lll1_opy_):
        scenario_name = args[0].name
        feature_name = bstack1l1lll1111_opy_ = str(self.feature.name)
        bstack1l1lll1111_opy_ = feature_name + bstack1l11ll_opy_ (u"ࠬࠦ࠭ࠡࠩ௿") + scenario_name
        bstack1ll11lllll_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11l1lll_opy_(bstack1l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬఀ")) else context.browser
        if self.driver_before_scenario:
          bstack1ll1111111_opy_(context, bstack1l1lll1111_opy_)
          bstack1ll11lllll_opy_.execute_script(bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠤࠬఁ") + json.dumps(bstack1l1lll1111_opy_) + bstack1l11ll_opy_ (u"ࠨࡿࢀࠫం"))
    except Exception as e:
      logger.debug(bstack1l11ll_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡥࡵࠢࡶࡩࡸࡹࡩࡰࡰࠣࡲࡦࡳࡥࠡ࡫ࡱࠤࡧ࡫ࡦࡰࡴࡨࠤࡸࡩࡥ࡯ࡣࡵ࡭ࡴࡀࠠࡼࡿࠪః").format(str(e)))
  elif name == bstack1l11ll_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡶࡧࡪࡴࡡࡳ࡫ࡲࠫఄ"):
    try:
      bstack1lll111l1_opy_ = args[0].status.name
      bstack1ll11lllll_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪఅ") in threading.current_thread().__dict__.keys() else context.browser
      if str(bstack1lll111l1_opy_).lower() == bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬఆ"):
        bstack1l1llll111_opy_ = bstack1l11ll_opy_ (u"࠭ࠧఇ")
        bstack11l111ll_opy_ = bstack1l11ll_opy_ (u"ࠧࠨఈ")
        bstack1ll11ll1l_opy_ = bstack1l11ll_opy_ (u"ࠨࠩఉ")
        try:
          import traceback
          bstack1l1llll111_opy_ = self.exception.__class__.__name__
          bstack11111111l_opy_ = traceback.format_tb(self.exc_traceback)
          bstack11l111ll_opy_ = bstack1l11ll_opy_ (u"ࠩࠣࠫఊ").join(bstack11111111l_opy_)
          bstack1ll11ll1l_opy_ = bstack11111111l_opy_[-1]
        except Exception as e:
          logger.debug(bstack1ll111111l_opy_.format(str(e)))
        bstack1l1llll111_opy_ += bstack1ll11ll1l_opy_
        bstack11l111111_opy_(context, json.dumps(str(args[0].name) + bstack1l11ll_opy_ (u"ࠥࠤ࠲ࠦࡆࡢ࡫࡯ࡩࡩࠧ࡜࡯ࠤఋ") + str(bstack11l111ll_opy_)),
                            bstack1l11ll_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥఌ"))
        if self.driver_before_scenario:
          bstack1l1111l11_opy_(getattr(context, bstack1l11ll_opy_ (u"ࠬࡶࡡࡨࡧࠪ఍"), None), bstack1l11ll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨఎ"), bstack1l1llll111_opy_)
          bstack1ll11lllll_opy_.execute_script(bstack1l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡢࡰࡱࡳࡹࡧࡴࡦࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡪࡡࡵࡣࠥ࠾ࠬఏ") + json.dumps(str(args[0].name) + bstack1l11ll_opy_ (u"ࠣࠢ࠰ࠤࡋࡧࡩ࡭ࡧࡧࠥࡡࡴࠢఐ") + str(bstack11l111ll_opy_)) + bstack1l11ll_opy_ (u"ࠩ࠯ࠤࠧࡲࡥࡷࡧ࡯ࠦ࠿ࠦࠢࡦࡴࡵࡳࡷࠨࡽࡾࠩ఑"))
        if self.driver_before_scenario:
          bstack1l11lll1l_opy_(bstack1ll11lllll_opy_, bstack1l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪఒ"), bstack1l11ll_opy_ (u"ࠦࡘࡩࡥ࡯ࡣࡵ࡭ࡴࠦࡦࡢ࡫࡯ࡩࡩࠦࡷࡪࡶ࡫࠾ࠥࡢ࡮ࠣఓ") + str(bstack1l1llll111_opy_))
      else:
        bstack11l111111_opy_(context, bstack1l11ll_opy_ (u"ࠧࡖࡡࡴࡵࡨࡨࠦࠨఔ"), bstack1l11ll_opy_ (u"ࠨࡩ࡯ࡨࡲࠦక"))
        if self.driver_before_scenario:
          bstack1l1111l11_opy_(getattr(context, bstack1l11ll_opy_ (u"ࠧࡱࡣࡪࡩࠬఖ"), None), bstack1l11ll_opy_ (u"ࠣࡲࡤࡷࡸ࡫ࡤࠣగ"))
        bstack1ll11lllll_opy_.execute_script(bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡤࡲࡳࡵࡴࡢࡶࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡥࡣࡷࡥࠧࡀࠧఘ") + json.dumps(str(args[0].name) + bstack1l11ll_opy_ (u"ࠥࠤ࠲ࠦࡐࡢࡵࡶࡩࡩࠧࠢఙ")) + bstack1l11ll_opy_ (u"ࠫ࠱ࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤ࡬ࡲ࡫ࡵࠢࡾࡿࠪచ"))
        if self.driver_before_scenario:
          bstack1l11lll1l_opy_(bstack1ll11lllll_opy_, bstack1l11ll_opy_ (u"ࠧࡶࡡࡴࡵࡨࡨࠧఛ"))
    except Exception as e:
      logger.debug(bstack1l11ll_opy_ (u"࠭ࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡰࡥࡷࡱࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡵࡷࡥࡹࡻࡳࠡ࡫ࡱࠤࡦ࡬ࡴࡦࡴࠣࡪࡪࡧࡴࡶࡴࡨ࠾ࠥࢁࡽࠨజ").format(str(e)))
  elif name == bstack1l11ll_opy_ (u"ࠧࡢࡨࡷࡩࡷࡥࡦࡦࡣࡷࡹࡷ࡫ࠧఝ"):
    try:
      bstack1ll11lllll_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11l1lll_opy_(bstack1l11ll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧఞ")) else context.browser
      if context.failed is True:
        bstack11l1ll1l_opy_ = []
        bstack1l11l1l1_opy_ = []
        bstack11l11ll1_opy_ = []
        bstack1l1llll1ll_opy_ = bstack1l11ll_opy_ (u"ࠩࠪట")
        try:
          import traceback
          for exc in self.exception_arr:
            bstack11l1ll1l_opy_.append(exc.__class__.__name__)
          for exc_tb in self.exc_traceback_arr:
            bstack11111111l_opy_ = traceback.format_tb(exc_tb)
            bstack1ll11l1ll_opy_ = bstack1l11ll_opy_ (u"ࠪࠤࠬఠ").join(bstack11111111l_opy_)
            bstack1l11l1l1_opy_.append(bstack1ll11l1ll_opy_)
            bstack11l11ll1_opy_.append(bstack11111111l_opy_[-1])
        except Exception as e:
          logger.debug(bstack1ll111111l_opy_.format(str(e)))
        bstack1l1llll111_opy_ = bstack1l11ll_opy_ (u"ࠫࠬడ")
        for i in range(len(bstack11l1ll1l_opy_)):
          bstack1l1llll111_opy_ += bstack11l1ll1l_opy_[i] + bstack11l11ll1_opy_[i] + bstack1l11ll_opy_ (u"ࠬࡢ࡮ࠨఢ")
        bstack1l1llll1ll_opy_ = bstack1l11ll_opy_ (u"࠭ࠠࠨణ").join(bstack1l11l1l1_opy_)
        if not self.driver_before_scenario:
          bstack11l111111_opy_(context, bstack1l1llll1ll_opy_, bstack1l11ll_opy_ (u"ࠢࡦࡴࡵࡳࡷࠨత"))
          bstack1l1111l11_opy_(getattr(context, bstack1l11ll_opy_ (u"ࠨࡲࡤ࡫ࡪ࠭థ"), None), bstack1l11ll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤద"), bstack1l1llll111_opy_)
          bstack1ll11lllll_opy_.execute_script(bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨధ") + json.dumps(bstack1l1llll1ll_opy_) + bstack1l11ll_opy_ (u"ࠫ࠱ࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤࡨࡶࡷࡵࡲࠣࡿࢀࠫన"))
          bstack1l11lll1l_opy_(bstack1ll11lllll_opy_, bstack1l11ll_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧ఩"), bstack1l11ll_opy_ (u"ࠨࡓࡰ࡯ࡨࠤࡸࡩࡥ࡯ࡣࡵ࡭ࡴࡹࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡ࡞ࡱࠦప") + str(bstack1l1llll111_opy_))
          bstack111lll11l_opy_ = bstack1lllll1lll_opy_(bstack1l1llll1ll_opy_, self.feature.name, logger)
          if (bstack111lll11l_opy_ != None):
            bstack1lllll111l_opy_.append(bstack111lll11l_opy_)
      else:
        if not self.driver_before_scenario:
          bstack11l111111_opy_(context, bstack1l11ll_opy_ (u"ࠢࡇࡧࡤࡸࡺࡸࡥ࠻ࠢࠥఫ") + str(self.feature.name) + bstack1l11ll_opy_ (u"ࠣࠢࡳࡥࡸࡹࡥࡥࠣࠥబ"), bstack1l11ll_opy_ (u"ࠤ࡬ࡲ࡫ࡵࠢభ"))
          bstack1l1111l11_opy_(getattr(context, bstack1l11ll_opy_ (u"ࠪࡴࡦ࡭ࡥࠨమ"), None), bstack1l11ll_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦయ"))
          bstack1ll11lllll_opy_.execute_script(bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡨࡦࡺࡡࠣ࠼ࠪర") + json.dumps(bstack1l11ll_opy_ (u"ࠨࡆࡦࡣࡷࡹࡷ࡫࠺ࠡࠤఱ") + str(self.feature.name) + bstack1l11ll_opy_ (u"ࠢࠡࡲࡤࡷࡸ࡫ࡤࠢࠤల")) + bstack1l11ll_opy_ (u"ࠨ࠮ࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡩ࡯ࡨࡲࠦࢂࢃࠧళ"))
          bstack1l11lll1l_opy_(bstack1ll11lllll_opy_, bstack1l11ll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩఴ"))
          bstack111lll11l_opy_ = bstack1lllll1lll_opy_(bstack1l1llll1ll_opy_, self.feature.name, logger)
          if (bstack111lll11l_opy_ != None):
            bstack1lllll111l_opy_.append(bstack111lll11l_opy_)
    except Exception as e:
      logger.debug(bstack1l11ll_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦ࡭ࡢࡴ࡮ࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥ࡯࡮ࠡࡣࡩࡸࡪࡸࠠࡧࡧࡤࡸࡺࡸࡥ࠻ࠢࡾࢁࠬవ").format(str(e)))
  else:
    bstack111111l1_opy_(self, name, context, *args)
  if name in [bstack1l11ll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡪࡪࡧࡴࡶࡴࡨࠫశ"), bstack1l11ll_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭ష")]:
    bstack111111l1_opy_(self, name, context, *args)
    if (name == bstack1l11ll_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤࡹࡣࡦࡰࡤࡶ࡮ࡵࠧస") and self.driver_before_scenario) or (
            name == bstack1l11ll_opy_ (u"ࠧࡢࡨࡷࡩࡷࡥࡦࡦࡣࡷࡹࡷ࡫ࠧహ") and not self.driver_before_scenario):
      try:
        bstack1ll11lllll_opy_ = threading.current_thread().bstackSessionDriver if bstack1l11l1lll_opy_(bstack1l11ll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧ఺")) else context.browser
        bstack1ll11lllll_opy_.quit()
      except Exception:
        pass
def bstack11l1l11l_opy_(config, startdir):
  return bstack1l11ll_opy_ (u"ࠤࡧࡶ࡮ࡼࡥࡳ࠼ࠣࡿ࠵ࢃࠢ఻").format(bstack1l11ll_opy_ (u"ࠥࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠤ఼"))
notset = Notset()
def bstack1l1l1l11l_opy_(self, name: str, default=notset, skip: bool = False):
  global bstack1lll11l11l_opy_
  if str(name).lower() == bstack1l11ll_opy_ (u"ࠫࡩࡸࡩࡷࡧࡵࠫఽ"):
    return bstack1l11ll_opy_ (u"ࠧࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠦా")
  else:
    return bstack1lll11l11l_opy_(self, name, default, skip)
def bstack111lll1l1_opy_(item, when):
  global bstack1llll11lll_opy_
  try:
    bstack1llll11lll_opy_(item, when)
  except Exception as e:
    pass
def bstack1l11l111l_opy_():
  return
def bstack1111l111_opy_(type, name, status, reason, bstack1111111ll_opy_, bstack11111ll11_opy_):
  bstack111l1l1l_opy_ = {
    bstack1l11ll_opy_ (u"࠭ࡡࡤࡶ࡬ࡳࡳ࠭ి"): type,
    bstack1l11ll_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪీ"): {}
  }
  if type == bstack1l11ll_opy_ (u"ࠨࡣࡱࡲࡴࡺࡡࡵࡧࠪు"):
    bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬూ")][bstack1l11ll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩృ")] = bstack1111111ll_opy_
    bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧౄ")][bstack1l11ll_opy_ (u"ࠬࡪࡡࡵࡣࠪ౅")] = json.dumps(str(bstack11111ll11_opy_))
  if type == bstack1l11ll_opy_ (u"࠭ࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧె"):
    bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪే")][bstack1l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ై")] = name
  if type == bstack1l11ll_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠬ౉"):
    bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ొ")][bstack1l11ll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫో")] = status
    if status == bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬౌ"):
      bstack111l1l1l_opy_[bstack1l11ll_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴ్ࠩ")][bstack1l11ll_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ౎")] = json.dumps(str(reason))
  bstack1l11lllll1_opy_ = bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࢂ࠭౏").format(json.dumps(bstack111l1l1l_opy_))
  return bstack1l11lllll1_opy_
def bstack1l11lllll_opy_(driver_command, response):
    if driver_command == bstack1l11ll_opy_ (u"ࠩࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹ࠭౐"):
        bstack111lll1_opy_.bstack1l1l111111_opy_({
            bstack1l11ll_opy_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ౑"): response[bstack1l11ll_opy_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ౒")],
            bstack1l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ౓"): bstack111lll1_opy_.current_test_uuid()
        })
def bstack111llllll_opy_(item, call, rep):
  global bstack1lll11lll_opy_
  global bstack1l1111l1l_opy_
  global bstack1lll11lll1_opy_
  name = bstack1l11ll_opy_ (u"࠭ࠧ౔")
  try:
    if rep.when == bstack1l11ll_opy_ (u"ࠧࡤࡣ࡯ࡰౕࠬ"):
      bstack1l1l1lll11_opy_ = threading.current_thread().bstackSessionId
      try:
        if not bstack1lll11lll1_opy_:
          name = str(rep.nodeid)
          bstack1l1ll1ll11_opy_ = bstack1111l111_opy_(bstack1l11ll_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦౖࠩ"), name, bstack1l11ll_opy_ (u"ࠩࠪ౗"), bstack1l11ll_opy_ (u"ࠪࠫౘ"), bstack1l11ll_opy_ (u"ࠫࠬౙ"), bstack1l11ll_opy_ (u"ࠬ࠭ౚ"))
          threading.current_thread().bstack11ll11ll_opy_ = name
          for driver in bstack1l1111l1l_opy_:
            if bstack1l1l1lll11_opy_ == driver.session_id:
              driver.execute_script(bstack1l1ll1ll11_opy_)
      except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࠢࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠠࡧࡱࡵࠤࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠡࡵࡨࡷࡸ࡯࡯࡯࠼ࠣࡿࢂ࠭౛").format(str(e)))
      try:
        bstack1ll1lll1l1_opy_(rep.outcome.lower())
        if rep.outcome.lower() != bstack1l11ll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨ౜"):
          status = bstack1l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨౝ") if rep.outcome.lower() == bstack1l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ౞") else bstack1l11ll_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪ౟")
          reason = bstack1l11ll_opy_ (u"ࠫࠬౠ")
          if status == bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬౡ"):
            reason = rep.longrepr.reprcrash.message
            if (not threading.current_thread().bstackTestErrorMessages):
              threading.current_thread().bstackTestErrorMessages = []
            threading.current_thread().bstackTestErrorMessages.append(reason)
          level = bstack1l11ll_opy_ (u"࠭ࡩ࡯ࡨࡲࠫౢ") if status == bstack1l11ll_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧౣ") else bstack1l11ll_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧ౤")
          data = name + bstack1l11ll_opy_ (u"ࠩࠣࡴࡦࡹࡳࡦࡦࠤࠫ౥") if status == bstack1l11ll_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪ౦") else name + bstack1l11ll_opy_ (u"ࠫࠥ࡬ࡡࡪ࡮ࡨࡨࠦࠦࠧ౧") + reason
          bstack1lll11llll_opy_ = bstack1111l111_opy_(bstack1l11ll_opy_ (u"ࠬࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠧ౨"), bstack1l11ll_opy_ (u"࠭ࠧ౩"), bstack1l11ll_opy_ (u"ࠧࠨ౪"), bstack1l11ll_opy_ (u"ࠨࠩ౫"), level, data)
          for driver in bstack1l1111l1l_opy_:
            if bstack1l1l1lll11_opy_ == driver.session_id:
              driver.execute_script(bstack1lll11llll_opy_)
      except Exception as e:
        logger.debug(bstack1l11ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡣࡰࡰࡷࡩࡽࡺࠠࡧࡱࡵࠤࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠡࡵࡨࡷࡸ࡯࡯࡯࠼ࠣࡿࢂ࠭౬").format(str(e)))
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡳࡵࡣࡷࡩࠥ࡯࡮ࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡺࡥࡴࡶࠣࡷࡹࡧࡴࡶࡵ࠽ࠤࢀࢃࠧ౭").format(str(e)))
  bstack1lll11lll_opy_(item, call, rep)
def bstack11111lll_opy_(driver, bstack1l111l11_opy_):
  PercySDK.screenshot(driver, bstack1l111l11_opy_)
def bstack11ll11l11_opy_(driver):
  if bstack111l11l11_opy_.bstack1ll111l11_opy_() is True or bstack111l11l11_opy_.capturing() is True:
    return
  bstack111l11l11_opy_.bstack1llllll1ll_opy_()
  while not bstack111l11l11_opy_.bstack1ll111l11_opy_():
    bstack1l1111ll1_opy_ = bstack111l11l11_opy_.bstack11l111l11_opy_()
    bstack11111lll_opy_(driver, bstack1l1111ll1_opy_)
  bstack111l11l11_opy_.bstack111ll1l1l_opy_()
def bstack11l1ll1l1_opy_(sequence, driver_command, response = None, bstack111l1l111_opy_ = None, args = None):
    try:
      if sequence != bstack1l11ll_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࠫ౮"):
        return
      if not CONFIG.get(bstack1l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼࠫ౯"), False):
        return
      bstack1l1111ll1_opy_ = bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"࠭ࡰࡦࡴࡦࡽࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩ౰"), None)
      for command in bstack1ll11111ll_opy_:
        if command == driver_command:
          for driver in bstack1l1111l1l_opy_:
            bstack11ll11l11_opy_(driver)
      bstack11l1l1l1l_opy_ = CONFIG.get(bstack1l11ll_opy_ (u"ࠧࡱࡧࡵࡧࡾࡉࡡࡱࡶࡸࡶࡪࡓ࡯ࡥࡧࠪ౱"), bstack1l11ll_opy_ (u"ࠣࡣࡸࡸࡴࠨ౲"))
      if driver_command in bstack1l11ll1l_opy_[bstack11l1l1l1l_opy_]:
        bstack111l11l11_opy_.bstack1ll1111l11_opy_(bstack1l1111ll1_opy_, driver_command)
    except Exception as e:
      pass
def bstack1l1l1l1ll1_opy_(framework_name):
  global bstack1ll1l1l1ll_opy_
  global bstack1l11l1l11_opy_
  global bstack1l1l1111ll_opy_
  bstack1ll1l1l1ll_opy_ = framework_name
  logger.info(bstack1l1llll1l1_opy_.format(bstack1ll1l1l1ll_opy_.split(bstack1l11ll_opy_ (u"ࠩ࠰ࠫ౳"))[0]))
  try:
    from selenium import webdriver
    from selenium.webdriver.common.service import Service
    from selenium.webdriver.remote.webdriver import WebDriver
    if bstack1l1l1111_opy_:
      Service.start = bstack1l11ll11l_opy_
      Service.stop = bstack11111l11l_opy_
      webdriver.Remote.get = bstack1l1ll11l1_opy_
      WebDriver.close = bstack111l11111_opy_
      WebDriver.quit = bstack1l1111lll_opy_
      webdriver.Remote.__init__ = bstack1l1ll1llll_opy_
      WebDriver.getAccessibilityResults = getAccessibilityResults
      WebDriver.get_accessibility_results = getAccessibilityResults
      WebDriver.getAccessibilityResultsSummary = getAccessibilityResultsSummary
      WebDriver.get_accessibility_results_summary = getAccessibilityResultsSummary
      WebDriver.performScan = perform_scan
      WebDriver.perform_scan = perform_scan
    if not bstack1l1l1111_opy_ and bstack111lll1_opy_.on():
      webdriver.Remote.__init__ = bstack111l1l1l1_opy_
    WebDriver.execute = bstack1l11l1l1ll_opy_
    bstack1l11l1l11_opy_ = True
  except Exception as e:
    pass
  try:
    if bstack1l1l1111_opy_:
      from QWeb.keywords import browser
      browser.close_browser = bstack1l1ll111ll_opy_
  except Exception as e:
    pass
  bstack1ll1111ll1_opy_()
  if not bstack1l11l1l11_opy_:
    bstack1llllll1l1_opy_(bstack1l11ll_opy_ (u"ࠥࡔࡦࡩ࡫ࡢࡩࡨࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠧ౴"), bstack1l1lll1ll1_opy_)
  if bstack1l1l1l111_opy_():
    try:
      from selenium.webdriver.remote.remote_connection import RemoteConnection
      RemoteConnection._get_proxy_url = bstack1l1l1lll1l_opy_
    except Exception as e:
      logger.error(bstack1l1111l1_opy_.format(str(e)))
  if bstack111l1ll11_opy_():
    bstack1ll1lll11l_opy_(CONFIG, logger)
  if (bstack1l11ll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪ౵") in str(framework_name).lower()):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        if CONFIG.get(bstack1l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼࠫ౶"), False):
          bstack11lll1l1l_opy_(bstack11l1ll1l1_opy_)
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        WebDriverCreator._get_ff_profile = bstack1lll1ll111_opy_
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCache.close = bstack1ll111l1l_opy_
      except Exception as e:
        logger.warn(bstack1111l111l_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        ApplicationCache.close = bstack11lll11l_opy_
      except Exception as e:
        logger.debug(bstack11l1ll11l_opy_ + str(e))
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack1111l111l_opy_)
    Output.start_test = bstack1l1l1lll1_opy_
    Output.end_test = bstack1llll1111l_opy_
    TestStatus.__init__ = bstack1111l1l1l_opy_
    QueueItem.__init__ = bstack111ll1ll_opy_
    pabot._create_items = bstack111lll1ll_opy_
    try:
      from pabot import __version__ as bstack1l111111_opy_
      if version.parse(bstack1l111111_opy_) >= version.parse(bstack1l11ll_opy_ (u"࠭࠲࠯࠳࠸࠲࠵࠭౷")):
        pabot._run = bstack1ll111llll_opy_
      elif version.parse(bstack1l111111_opy_) >= version.parse(bstack1l11ll_opy_ (u"ࠧ࠳࠰࠴࠷࠳࠶ࠧ౸")):
        pabot._run = bstack1l1lll1ll_opy_
      else:
        pabot._run = bstack1lll1111ll_opy_
    except Exception as e:
      pabot._run = bstack1lll1111ll_opy_
    pabot._create_command_for_execution = bstack1lll11l1l1_opy_
    pabot._report_results = bstack111ll11l_opy_
  if bstack1l11ll_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ౹") in str(framework_name).lower():
    if not bstack1l1l1111_opy_:
      return
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack11ll11111_opy_)
    Runner.run_hook = bstack1l1l11111_opy_
    Step.run = bstack11ll1l11_opy_
  if bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ౺") in str(framework_name).lower():
    if not bstack1l1l1111_opy_:
      return
    try:
      if CONFIG.get(bstack1l11ll_opy_ (u"ࠪࡴࡪࡸࡣࡺࠩ౻"), False):
          bstack11lll1l1l_opy_(bstack11l1ll1l1_opy_)
      from pytest_selenium import pytest_selenium
      from _pytest.config import Config
      pytest_selenium.pytest_report_header = bstack11l1l11l_opy_
      from pytest_selenium.drivers import browserstack
      browserstack.pytest_selenium_runtest_makereport = bstack1l11l111l_opy_
      Config.getoption = bstack1l1l1l11l_opy_
    except Exception as e:
      pass
    try:
      from pytest_bdd import reporting
      reporting.runtest_makereport = bstack111llllll_opy_
    except Exception as e:
      pass
def bstack1l1l11l1_opy_():
  global CONFIG
  if bstack1l11ll_opy_ (u"ࠫࡵࡧࡲࡢ࡮࡯ࡩࡱࡹࡐࡦࡴࡓࡰࡦࡺࡦࡰࡴࡰࠫ౼") in CONFIG and int(CONFIG[bstack1l11ll_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬ౽")]) > 1:
    logger.warn(bstack1111ll1l1_opy_)
def bstack111l1111_opy_(arg, bstack1ll111ll_opy_, bstack1l111lllll_opy_=None):
  global CONFIG
  global bstack1ll1l1l1l1_opy_
  global bstack1llllll111_opy_
  global bstack1l1l1111_opy_
  global bstack1llll1ll_opy_
  bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭౾")
  if bstack1ll111ll_opy_ and isinstance(bstack1ll111ll_opy_, str):
    bstack1ll111ll_opy_ = eval(bstack1ll111ll_opy_)
  CONFIG = bstack1ll111ll_opy_[bstack1l11ll_opy_ (u"ࠧࡄࡑࡑࡊࡎࡍࠧ౿")]
  bstack1ll1l1l1l1_opy_ = bstack1ll111ll_opy_[bstack1l11ll_opy_ (u"ࠨࡊࡘࡆࡤ࡛ࡒࡍࠩಀ")]
  bstack1llllll111_opy_ = bstack1ll111ll_opy_[bstack1l11ll_opy_ (u"ࠩࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫಁ")]
  bstack1l1l1111_opy_ = bstack1ll111ll_opy_[bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡄ࡙࡙ࡕࡍࡂࡖࡌࡓࡓ࠭ಂ")]
  bstack1llll1ll_opy_.set_property(bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬಃ"), bstack1l1l1111_opy_)
  os.environ[bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧ಄")] = bstack1l11l1111l_opy_
  os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡉࡏࡏࡈࡌࡋࠬಅ")] = json.dumps(CONFIG)
  os.environ[bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡈࡖࡄࡢ࡙ࡗࡒࠧಆ")] = bstack1ll1l1l1l1_opy_
  os.environ[bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡊࡕࡢࡅࡕࡖ࡟ࡂࡗࡗࡓࡒࡇࡔࡆࠩಇ")] = str(bstack1llllll111_opy_)
  os.environ[bstack1l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡒ࡜ࡘࡊ࡙ࡔࡠࡒࡏ࡙ࡌࡏࡎࠨಈ")] = str(True)
  if bstack111lllll1_opy_(arg, [bstack1l11ll_opy_ (u"ࠪ࠱ࡳ࠭ಉ"), bstack1l11ll_opy_ (u"ࠫ࠲࠳࡮ࡶ࡯ࡳࡶࡴࡩࡥࡴࡵࡨࡷࠬಊ")]) != -1:
    os.environ[bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕ࡟ࡔࡆࡕࡗࡣࡕࡇࡒࡂࡎࡏࡉࡑ࠭ಋ")] = str(True)
  if len(sys.argv) <= 1:
    logger.critical(bstack1ll1l1ll1_opy_)
    return
  bstack1l1ll1111_opy_()
  global bstack1l11lll11_opy_
  global bstack1llll1llll_opy_
  global bstack1llll11l11_opy_
  global bstack1111l1lll_opy_
  global bstack1l1l1l111l_opy_
  global bstack1l1l1111ll_opy_
  global bstack1llll1ll11_opy_
  arg.append(bstack1l11ll_opy_ (u"ࠨ࠭ࡘࠤಌ"))
  arg.append(bstack1l11ll_opy_ (u"ࠢࡪࡩࡱࡳࡷ࡫࠺ࡎࡱࡧࡹࡱ࡫ࠠࡢ࡮ࡵࡩࡦࡪࡹࠡ࡫ࡰࡴࡴࡸࡴࡦࡦ࠽ࡴࡾࡺࡥࡴࡶ࠱ࡔࡾࡺࡥࡴࡶ࡚ࡥࡷࡴࡩ࡯ࡩࠥ಍"))
  arg.append(bstack1l11ll_opy_ (u"ࠣ࠯࡚ࠦಎ"))
  arg.append(bstack1l11ll_opy_ (u"ࠤ࡬࡫ࡳࡵࡲࡦ࠼ࡗ࡬ࡪࠦࡨࡰࡱ࡮࡭ࡲࡶ࡬ࠣಏ"))
  global bstack111111111_opy_
  global bstack1111l11l_opy_
  global bstack11l1111l1_opy_
  global bstack111111ll1_opy_
  global bstack1l11ll1ll1_opy_
  global bstack1l1l111l1l_opy_
  global bstack11l11lll_opy_
  global bstack1llll111l_opy_
  global bstack1l11l1l11l_opy_
  global bstack1l11l11l1l_opy_
  global bstack1lll11l11l_opy_
  global bstack1llll11lll_opy_
  global bstack1lll11lll_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack111111111_opy_ = webdriver.Remote.__init__
    bstack1111l11l_opy_ = WebDriver.quit
    bstack1llll111l_opy_ = WebDriver.close
    bstack1l11l1l11l_opy_ = WebDriver.get
    bstack11l1111l1_opy_ = WebDriver.execute
  except Exception as e:
    pass
  if bstack1lll111l1l_opy_(CONFIG) and bstack1l1lll1l1_opy_():
    if bstack1ll11lll11_opy_() < version.parse(bstack1ll1l1l1l_opy_):
      logger.error(bstack111ll111_opy_.format(bstack1ll11lll11_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack1l11l11l1l_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack1l1111l1_opy_.format(str(e)))
  try:
    from _pytest.config import Config
    bstack1lll11l11l_opy_ = Config.getoption
    from _pytest import runner
    bstack1llll11lll_opy_ = runner._update_current_test_var
  except Exception as e:
    logger.warn(e, bstack1ll1l1ll_opy_)
  try:
    from pytest_bdd import reporting
    bstack1lll11lll_opy_ = reporting.runtest_makereport
  except Exception as e:
    logger.debug(bstack1l11ll_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣ࡭ࡳࡹࡴࡢ࡮࡯ࠤࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠡࡶࡲࠤࡷࡻ࡮ࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡺࡥࡴࡶࡶࠫಐ"))
  bstack1llll11l11_opy_ = CONFIG.get(bstack1l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨ಑"), {}).get(bstack1l11ll_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧಒ"))
  bstack1llll1ll11_opy_ = True
  bstack1l1l1l1ll1_opy_(bstack1llll1ll1l_opy_)
  os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡛ࡓࡆࡔࡑࡅࡒࡋࠧಓ")] = CONFIG[bstack1l11ll_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩಔ")]
  os.environ[bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡂࡅࡆࡉࡘ࡙࡟ࡌࡇ࡜ࠫಕ")] = CONFIG[bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬಖ")]
  os.environ[bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡄ࡙࡙ࡕࡍࡂࡖࡌࡓࡓ࠭ಗ")] = bstack1l1l1111_opy_.__str__()
  from _pytest.config import main as bstack1ll1111l1l_opy_
  bstack11l1lll1l_opy_ = []
  try:
    bstack1l11ll1l1_opy_ = bstack1ll1111l1l_opy_(arg)
    if bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡪࡸࡲࡰࡴࡢࡰ࡮ࡹࡴࠨಘ") in multiprocessing.current_process().__dict__.keys():
      for bstack1l1l1l1l1_opy_ in multiprocessing.current_process().bstack_error_list:
        bstack11l1lll1l_opy_.append(bstack1l1l1l1l1_opy_)
    try:
      bstack1111111l_opy_ = (bstack11l1lll1l_opy_, int(bstack1l11ll1l1_opy_))
      bstack1l111lllll_opy_.append(bstack1111111l_opy_)
    except:
      bstack1l111lllll_opy_.append((bstack11l1lll1l_opy_, bstack1l11ll1l1_opy_))
  except Exception as e:
    logger.error(traceback.format_exc())
    bstack11l1lll1l_opy_.append({bstack1l11ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪಙ"): bstack1l11ll_opy_ (u"࠭ࡐࡳࡱࡦࡩࡸࡹࠠࠨಚ") + os.environ.get(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧಛ")), bstack1l11ll_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧಜ"): traceback.format_exc(), bstack1l11ll_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨಝ"): int(os.environ.get(bstack1l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓࡐࡆ࡚ࡆࡐࡔࡐࡣࡎࡔࡄࡆ࡚ࠪಞ")))})
    bstack1l111lllll_opy_.append((bstack11l1lll1l_opy_, 1))
def bstack1llll1l1l1_opy_(arg):
  bstack1l1l1l1ll1_opy_(bstack1ll1l11ll_opy_)
  os.environ[bstack1l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬಟ")] = str(bstack1llllll111_opy_)
  from behave.__main__ import main as bstack1llll1l1ll_opy_
  bstack1llll1l1ll_opy_(arg)
def bstack11l1111l_opy_():
  logger.info(bstack1ll11l1l1_opy_)
  import argparse
  parser = argparse.ArgumentParser()
  parser.add_argument(bstack1l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫಠ"), help=bstack1l11ll_opy_ (u"࠭ࡇࡦࡰࡨࡶࡦࡺࡥࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠠࡤࡱࡱࡪ࡮࡭ࠧಡ"))
  parser.add_argument(bstack1l11ll_opy_ (u"ࠧ࠮ࡷࠪಢ"), bstack1l11ll_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬಣ"), help=bstack1l11ll_opy_ (u"ࠩ࡜ࡳࡺࡸࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡵࡴࡧࡵࡲࡦࡳࡥࠨತ"))
  parser.add_argument(bstack1l11ll_opy_ (u"ࠪ࠱ࡰ࠭ಥ"), bstack1l11ll_opy_ (u"ࠫ࠲࠳࡫ࡦࡻࠪದ"), help=bstack1l11ll_opy_ (u"ࠬ࡟࡯ࡶࡴࠣࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠢࡤࡧࡨ࡫ࡳࡴࠢ࡮ࡩࡾ࠭ಧ"))
  parser.add_argument(bstack1l11ll_opy_ (u"࠭࠭ࡧࠩನ"), bstack1l11ll_opy_ (u"ࠧ࠮࠯ࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ಩"), help=bstack1l11ll_opy_ (u"ࠨ࡛ࡲࡹࡷࠦࡴࡦࡵࡷࠤ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧಪ"))
  bstack111ll1l1_opy_ = parser.parse_args()
  try:
    bstack1ll1ll11ll_opy_ = bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡩࡨࡲࡪࡸࡩࡤ࠰ࡼࡱࡱ࠴ࡳࡢ࡯ࡳࡰࡪ࠭ಫ")
    if bstack111ll1l1_opy_.framework and bstack111ll1l1_opy_.framework not in (bstack1l11ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪಬ"), bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱ࠷ࠬಭ")):
      bstack1ll1ll11ll_opy_ = bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࠮ࡺ࡯࡯࠲ࡸࡧ࡭ࡱ࡮ࡨࠫಮ")
    bstack1111l1l1_opy_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1ll1ll11ll_opy_)
    bstack1llll1l111_opy_ = open(bstack1111l1l1_opy_, bstack1l11ll_opy_ (u"࠭ࡲࠨಯ"))
    bstack11l1l11ll_opy_ = bstack1llll1l111_opy_.read()
    bstack1llll1l111_opy_.close()
    if bstack111ll1l1_opy_.username:
      bstack11l1l11ll_opy_ = bstack11l1l11ll_opy_.replace(bstack1l11ll_opy_ (u"࡚ࠧࡑࡘࡖࡤ࡛ࡓࡆࡔࡑࡅࡒࡋࠧರ"), bstack111ll1l1_opy_.username)
    if bstack111ll1l1_opy_.key:
      bstack11l1l11ll_opy_ = bstack11l1l11ll_opy_.replace(bstack1l11ll_opy_ (u"ࠨ࡛ࡒ࡙ࡗࡥࡁࡄࡅࡈࡗࡘࡥࡋࡆ࡛ࠪಱ"), bstack111ll1l1_opy_.key)
    if bstack111ll1l1_opy_.framework:
      bstack11l1l11ll_opy_ = bstack11l1l11ll_opy_.replace(bstack1l11ll_opy_ (u"ࠩ࡜ࡓ࡚ࡘ࡟ࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࠪಲ"), bstack111ll1l1_opy_.framework)
    file_name = bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡼࡱࡱ࠭ಳ")
    file_path = os.path.abspath(file_name)
    bstack11l111l1_opy_ = open(file_path, bstack1l11ll_opy_ (u"ࠫࡼ࠭಴"))
    bstack11l111l1_opy_.write(bstack11l1l11ll_opy_)
    bstack11l111l1_opy_.close()
    logger.info(bstack1ll11ll11l_opy_)
    try:
      os.environ[bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧವ")] = bstack111ll1l1_opy_.framework if bstack111ll1l1_opy_.framework != None else bstack1l11ll_opy_ (u"ࠨࠢಶ")
      config = yaml.safe_load(bstack11l1l11ll_opy_)
      config[bstack1l11ll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧಷ")] = bstack1l11ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮࠮ࡵࡨࡸࡺࡶࠧಸ")
      bstack1ll1ll1l11_opy_(bstack1l11llll_opy_, config)
    except Exception as e:
      logger.debug(bstack1llllll1l_opy_.format(str(e)))
  except Exception as e:
    logger.error(bstack1lll1l1ll1_opy_.format(str(e)))
def bstack1ll1ll1l11_opy_(bstack111l11ll_opy_, config, bstack1l1l1l1lll_opy_={}):
  global bstack1l1l1111_opy_
  global bstack1l11lll11l_opy_
  if not config:
    return
  bstack111l1111l_opy_ = bstack1111l1ll_opy_ if not bstack1l1l1111_opy_ else (
    bstack11111l11_opy_ if bstack1l11ll_opy_ (u"ࠩࡤࡴࡵ࠭ಹ") in config else bstack1lll1lllll_opy_)
  bstack1ll1l1l11l_opy_ = False
  bstack1ll111l1l1_opy_ = False
  if bstack1l1l1111_opy_ is True:
      if bstack1l11ll_opy_ (u"ࠪࡥࡵࡶࠧ಺") in config:
          bstack1ll1l1l11l_opy_ = True
      else:
          bstack1ll111l1l1_opy_ = True
  bstack1l1l11111l_opy_ = {
      bstack1l11ll_opy_ (u"ࠫࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼࠫ಻"): bstack111lll1_opy_.bstack1lll1ll11l_opy_(bstack1l11lll11l_opy_),
      bstack1l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽ಼ࠬ"): bstack1lll1ll1_opy_.bstack11ll1111_opy_(config),
      bstack1l11ll_opy_ (u"࠭ࡰࡦࡴࡦࡽࠬಽ"): config.get(bstack1l11ll_opy_ (u"ࠧࡱࡧࡵࡧࡾ࠭ಾ"), False),
      bstack1l11ll_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵࡧࠪಿ"): bstack1ll111l1l1_opy_,
      bstack1l11ll_opy_ (u"ࠩࡤࡴࡵࡥࡡࡶࡶࡲࡱࡦࡺࡥࠨೀ"): bstack1ll1l1l11l_opy_
  }
  data = {
    bstack1l11ll_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬು"): config[bstack1l11ll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ೂ")],
    bstack1l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨೃ"): config[bstack1l11ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩೄ")],
    bstack1l11ll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ೅"): bstack111l11ll_opy_,
    bstack1l11ll_opy_ (u"ࠨࡦࡨࡸࡪࡩࡴࡦࡦࡉࡶࡦࡳࡥࡸࡱࡵ࡯ࠬೆ"): os.environ.get(bstack1l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡈࡕࡅࡒࡋࡗࡐࡔࡎࠫೇ"), bstack1l11lll11l_opy_),
    bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠬೈ"): bstack11lllll1_opy_,
    bstack1l11ll_opy_ (u"ࠫࡴࡶࡴࡪ࡯ࡤࡰࡤ࡮ࡵࡣࡡࡸࡶࡱ࠭೉"): bstack1l1lllll1l_opy_(),
    bstack1l11ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨೊ"): {
      bstack1l11ll_opy_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࡠࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫೋ"): str(config[bstack1l11ll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧೌ")]) if bstack1l11ll_opy_ (u"ࠨࡵࡲࡹࡷࡩࡥࠨ್") in config else bstack1l11ll_opy_ (u"ࠤࡸࡲࡰࡴ࡯ࡸࡰࠥ೎"),
      bstack1l11ll_opy_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬ೏"): sys.version,
      bstack1l11ll_opy_ (u"ࠫࡷ࡫ࡦࡦࡴࡵࡩࡷ࠭೐"): bstack1l11111l_opy_(os.getenv(bstack1l11ll_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠢ೑"), bstack1l11ll_opy_ (u"ࠨࠢ೒"))),
      bstack1l11ll_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ೓"): bstack1l11ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ೔"),
      bstack1l11ll_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࠪೕ"): bstack111l1111l_opy_,
      bstack1l11ll_opy_ (u"ࠪࡴࡷࡵࡤࡶࡥࡷࡣࡲࡧࡰࠨೖ"): bstack1l1l11111l_opy_,
      bstack1l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡪࡸࡦࡤࡻࡵࡪࡦࠪ೗"): os.environ[bstack1l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪ೘")],
      bstack1l11ll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡘࡨࡶࡸ࡯࡯࡯ࠩ೙"): bstack1llll11ll_opy_(os.environ.get(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩ೚"), bstack1l11lll11l_opy_)),
      bstack1l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫ೛"): config[bstack1l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ೜")] if config[bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ೝ")] else bstack1l11ll_opy_ (u"ࠦࡺࡴ࡫࡯ࡱࡺࡲࠧೞ"),
      bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ೟"): str(config[bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨೠ")]) if bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩೡ") in config else bstack1l11ll_opy_ (u"ࠣࡷࡱ࡯ࡳࡵࡷ࡯ࠤೢ"),
      bstack1l11ll_opy_ (u"ࠩࡲࡷࠬೣ"): sys.platform,
      bstack1l11ll_opy_ (u"ࠪ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠬ೤"): socket.gethostname()
    }
  }
  update(data[bstack1l11ll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧ೥")], bstack1l1l1l1lll_opy_)
  try:
    response = bstack1l111ll11_opy_(bstack1l11ll_opy_ (u"ࠬࡖࡏࡔࡖࠪ೦"), bstack1111ll1ll_opy_(bstack11ll111l_opy_), data, {
      bstack1l11ll_opy_ (u"࠭ࡡࡶࡶ࡫ࠫ೧"): (config[bstack1l11ll_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩ೨")], config[bstack1l11ll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫ೩")])
    })
    if response:
      logger.debug(bstack1l11l1111_opy_.format(bstack111l11ll_opy_, str(response.json())))
  except Exception as e:
    logger.debug(bstack1l1ll11l1l_opy_.format(str(e)))
def bstack1l11111l_opy_(framework):
  return bstack1l11ll_opy_ (u"ࠤࡾࢁ࠲ࡶࡹࡵࡪࡲࡲࡦ࡭ࡥ࡯ࡶ࠲ࡿࢂࠨ೪").format(str(framework), __version__) if framework else bstack1l11ll_opy_ (u"ࠥࡴࡾࡺࡨࡰࡰࡤ࡫ࡪࡴࡴ࠰ࡽࢀࠦ೫").format(
    __version__)
def bstack1l1ll1111_opy_():
  global CONFIG
  global bstack111l1lll_opy_
  if bool(CONFIG):
    return
  try:
    bstack1l1lll11l1_opy_()
    logger.debug(bstack1lll1111l_opy_.format(str(CONFIG)))
    bstack111l1lll_opy_ = bstack1ll1l1111l_opy_.bstack1ll1ll111l_opy_(CONFIG, bstack111l1lll_opy_)
    bstack1111ll111_opy_()
  except Exception as e:
    logger.error(bstack1l11ll_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡴࡧࡷࡹࡵ࠲ࠠࡦࡴࡵࡳࡷࡀࠠࠣ೬") + str(e))
    sys.exit(1)
  sys.excepthook = bstack1l1llll11l_opy_
  atexit.register(bstack1l11l1l1l1_opy_)
  signal.signal(signal.SIGINT, bstack1lllll1111_opy_)
  signal.signal(signal.SIGTERM, bstack1lllll1111_opy_)
def bstack1l1llll11l_opy_(exctype, value, traceback):
  global bstack1l1111l1l_opy_
  try:
    for driver in bstack1l1111l1l_opy_:
      bstack1l11lll1l_opy_(driver, bstack1l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ೭"), bstack1l11ll_opy_ (u"ࠨࡓࡦࡵࡶ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࡸ࡫ࡷ࡬࠿ࠦ࡜࡯ࠤ೮") + str(value))
  except Exception:
    pass
  bstack11111llll_opy_(value, True)
  sys.__excepthook__(exctype, value, traceback)
  sys.exit(1)
def bstack11111llll_opy_(message=bstack1l11ll_opy_ (u"ࠧࠨ೯"), bstack11l1lll11_opy_ = False):
  global CONFIG
  bstack11l111ll1_opy_ = bstack1l11ll_opy_ (u"ࠨࡩ࡯ࡳࡧࡧ࡬ࡆࡺࡦࡩࡵࡺࡩࡰࡰࠪ೰") if bstack11l1lll11_opy_ else bstack1l11ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨೱ")
  try:
    if message:
      bstack1l1l1l1lll_opy_ = {
        bstack11l111ll1_opy_ : str(message)
      }
      bstack1ll1ll1l11_opy_(bstack1llll1l11_opy_, CONFIG, bstack1l1l1l1lll_opy_)
    else:
      bstack1ll1ll1l11_opy_(bstack1llll1l11_opy_, CONFIG)
  except Exception as e:
    logger.debug(bstack1l11lll1l1_opy_.format(str(e)))
def bstack1l11l11lll_opy_(bstack1l1l111l_opy_, size):
  bstack11ll111l1_opy_ = []
  while len(bstack1l1l111l_opy_) > size:
    bstack1l1ll1111l_opy_ = bstack1l1l111l_opy_[:size]
    bstack11ll111l1_opy_.append(bstack1l1ll1111l_opy_)
    bstack1l1l111l_opy_ = bstack1l1l111l_opy_[size:]
  bstack11ll111l1_opy_.append(bstack1l1l111l_opy_)
  return bstack11ll111l1_opy_
def bstack1ll11l11l_opy_(args):
  if bstack1l11ll_opy_ (u"ࠪ࠱ࡲ࠭ೲ") in args and bstack1l11ll_opy_ (u"ࠫࡵࡪࡢࠨೳ") in args:
    return True
  return False
def run_on_browserstack(bstack11l1l111l_opy_=None, bstack1l111lllll_opy_=None, bstack1111ll11l_opy_=False):
  global CONFIG
  global bstack1ll1l1l1l1_opy_
  global bstack1llllll111_opy_
  global bstack1l11lll11l_opy_
  bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠬ࠭೴")
  bstack1llll1lll1_opy_(bstack1ll111l1ll_opy_, logger)
  if bstack11l1l111l_opy_ and isinstance(bstack11l1l111l_opy_, str):
    bstack11l1l111l_opy_ = eval(bstack11l1l111l_opy_)
  if bstack11l1l111l_opy_:
    CONFIG = bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"࠭ࡃࡐࡐࡉࡍࡌ࠭೵")]
    bstack1ll1l1l1l1_opy_ = bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠧࡉࡗࡅࡣ࡚ࡘࡌࠨ೶")]
    bstack1llllll111_opy_ = bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠨࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪ೷")]
    bstack1llll1ll_opy_.set_property(bstack1l11ll_opy_ (u"ࠩࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫ೸"), bstack1llllll111_opy_)
    bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪ೹")
  if not bstack1111ll11l_opy_:
    if len(sys.argv) <= 1:
      logger.critical(bstack1ll1l1ll1_opy_)
      return
    if sys.argv[1] == bstack1l11ll_opy_ (u"ࠫ࠲࠳ࡶࡦࡴࡶ࡭ࡴࡴࠧ೺") or sys.argv[1] == bstack1l11ll_opy_ (u"ࠬ࠳ࡶࠨ೻"):
      logger.info(bstack1l11ll_opy_ (u"࠭ࡂࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡖࡹࡵࡪࡲࡲ࡙ࠥࡄࡌࠢࡹࡿࢂ࠭೼").format(__version__))
      return
    if sys.argv[1] == bstack1l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠭೽"):
      bstack11l1111l_opy_()
      return
  args = sys.argv
  bstack1l1ll1111_opy_()
  global bstack1l11lll11_opy_
  global bstack111l1l11_opy_
  global bstack1llll1ll11_opy_
  global bstack1llll11ll1_opy_
  global bstack1llll1llll_opy_
  global bstack1llll11l11_opy_
  global bstack1111l1lll_opy_
  global bstack1l11l111l1_opy_
  global bstack1l1l1l111l_opy_
  global bstack1l1l1111ll_opy_
  global bstack1l11111ll_opy_
  bstack111l1l11_opy_ = len(CONFIG.get(bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ೾"), []))
  if not bstack1l11l1111l_opy_:
    if args[1] == bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ೿") or args[1] == bstack1l11ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰ࠶ࠫഀ"):
      bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫഁ")
      args = args[2:]
    elif args[1] == bstack1l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫം"):
      bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬഃ")
      args = args[2:]
    elif args[1] == bstack1l11ll_opy_ (u"ࠧࡱࡣࡥࡳࡹ࠭ഄ"):
      bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠨࡲࡤࡦࡴࡺࠧഅ")
      args = args[2:]
    elif args[1] == bstack1l11ll_opy_ (u"ࠩࡵࡳࡧࡵࡴ࠮࡫ࡱࡸࡪࡸ࡮ࡢ࡮ࠪആ"):
      bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠫഇ")
      args = args[2:]
    elif args[1] == bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫഈ"):
      bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬഉ")
      args = args[2:]
    elif args[1] == bstack1l11ll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭ഊ"):
      bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧഋ")
      args = args[2:]
    else:
      if not bstack1l11ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫഌ") in CONFIG or str(CONFIG[bstack1l11ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ഍")]).lower() in [bstack1l11ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪഎ"), bstack1l11ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱ࠷ࠬഏ")]:
        bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬഐ")
        args = args[1:]
      elif str(CONFIG[bstack1l11ll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ഑")]).lower() == bstack1l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ഒ"):
        bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧഓ")
        args = args[1:]
      elif str(CONFIG[bstack1l11ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬഔ")]).lower() == bstack1l11ll_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩക"):
        bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪഖ")
        args = args[1:]
      elif str(CONFIG[bstack1l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨഗ")]).lower() == bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ഘ"):
        bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧങ")
        args = args[1:]
      elif str(CONFIG[bstack1l11ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫച")]).lower() == bstack1l11ll_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩഛ"):
        bstack1l11l1111l_opy_ = bstack1l11ll_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧࠪജ")
        args = args[1:]
      else:
        os.environ[bstack1l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡊࡗࡇࡍࡆ࡙ࡒࡖࡐ࠭ഝ")] = bstack1l11l1111l_opy_
        bstack1111ll11_opy_(bstack1llllll11_opy_)
  os.environ[bstack1l11ll_opy_ (u"ࠬࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࡠࡗࡖࡉࡉ࠭ഞ")] = bstack1l11l1111l_opy_
  bstack1l11lll11l_opy_ = bstack1l11l1111l_opy_
  global bstack1lll11ll11_opy_
  if bstack11l1l111l_opy_:
    try:
      os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࠨട")] = bstack1l11l1111l_opy_
      bstack1ll1ll1l11_opy_(bstack11lll1111_opy_, CONFIG)
    except Exception as e:
      logger.debug(bstack1l11lll1l1_opy_.format(str(e)))
  global bstack111111111_opy_
  global bstack1111l11l_opy_
  global bstack11l1l11l1_opy_
  global bstack11llll1l1_opy_
  global bstack1l11l11l11_opy_
  global bstack1ll11l11l1_opy_
  global bstack111111ll1_opy_
  global bstack1l11ll1ll1_opy_
  global bstack1111l1l11_opy_
  global bstack1l1l111l1l_opy_
  global bstack11l11lll_opy_
  global bstack1llll111l_opy_
  global bstack111111l1_opy_
  global bstack1ll1111lll_opy_
  global bstack1l11l1l11l_opy_
  global bstack1l11l11l1l_opy_
  global bstack1lll11l11l_opy_
  global bstack1llll11lll_opy_
  global bstack1ll1lllll1_opy_
  global bstack1lll11lll_opy_
  global bstack11l1111l1_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack111111111_opy_ = webdriver.Remote.__init__
    bstack1111l11l_opy_ = WebDriver.quit
    bstack1llll111l_opy_ = WebDriver.close
    bstack1l11l1l11l_opy_ = WebDriver.get
    bstack11l1111l1_opy_ = WebDriver.execute
  except Exception as e:
    pass
  try:
    import Browser
    from subprocess import Popen
    bstack1lll11ll11_opy_ = Popen.__init__
  except Exception as e:
    pass
  try:
    global bstack1l1ll11lll_opy_
    from QWeb.keywords import browser
    bstack1l1ll11lll_opy_ = browser.close_browser
  except Exception as e:
    pass
  if bstack1lll111l1l_opy_(CONFIG) and bstack1l1lll1l1_opy_():
    if bstack1ll11lll11_opy_() < version.parse(bstack1ll1l1l1l_opy_):
      logger.error(bstack111ll111_opy_.format(bstack1ll11lll11_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack1l11l11l1l_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack1l1111l1_opy_.format(str(e)))
  if not CONFIG.get(bstack1l11ll_opy_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡂࡷࡷࡳࡈࡧࡰࡵࡷࡵࡩࡑࡵࡧࡴࠩഠ"), False) and not bstack11l1l111l_opy_:
    logger.info(bstack1l11lll1_opy_)
  if bstack1l11l1111l_opy_ != bstack1l11ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨഡ") or (bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩഢ") and not bstack11l1l111l_opy_):
    bstack1l11l11111_opy_()
  if (bstack1l11l1111l_opy_ in [bstack1l11ll_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩണ"), bstack1l11ll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪത"), bstack1l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭ഥ")]):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCreator._get_ff_profile = bstack1lll1ll111_opy_
        bstack1ll11l11l1_opy_ = WebDriverCache.close
      except Exception as e:
        logger.warn(bstack1111l111l_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        bstack1l11l11l11_opy_ = ApplicationCache.close
      except Exception as e:
        logger.debug(bstack11l1ll11l_opy_ + str(e))
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack1111l111l_opy_)
    if bstack1l11l1111l_opy_ != bstack1l11ll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧദ"):
      bstack11l1ll1ll_opy_()
    bstack11l1l11l1_opy_ = Output.start_test
    bstack11llll1l1_opy_ = Output.end_test
    bstack111111ll1_opy_ = TestStatus.__init__
    bstack1111l1l11_opy_ = pabot._run
    bstack1l1l111l1l_opy_ = QueueItem.__init__
    bstack11l11lll_opy_ = pabot._create_command_for_execution
    bstack1ll1lllll1_opy_ = pabot._report_results
  if bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧധ"):
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack11ll11111_opy_)
    bstack111111l1_opy_ = Runner.run_hook
    bstack1ll1111lll_opy_ = Step.run
  if bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨന"):
    try:
      from _pytest.config import Config
      bstack1lll11l11l_opy_ = Config.getoption
      from _pytest import runner
      bstack1llll11lll_opy_ = runner._update_current_test_var
    except Exception as e:
      logger.warn(e, bstack1ll1l1ll_opy_)
    try:
      from pytest_bdd import reporting
      bstack1lll11lll_opy_ = reporting.runtest_makereport
    except Exception as e:
      logger.debug(bstack1l11ll_opy_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡵࡱࠣࡶࡺࡴࠠࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠤࡹ࡫ࡳࡵࡵࠪഩ"))
  try:
    framework_name = bstack1l11ll_opy_ (u"ࠪࡖࡴࡨ࡯ࡵࠩപ") if bstack1l11l1111l_opy_ in [bstack1l11ll_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪഫ"), bstack1l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫബ"), bstack1l11ll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧഭ")] else bstack1ll1lll11_opy_(bstack1l11l1111l_opy_)
    bstack111lll1_opy_.launch(CONFIG, {
      bstack1l11ll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡲࡦࡳࡥࠨമ"): bstack1l11ll_opy_ (u"ࠨࡽ࠳ࢁ࠲ࡩࡵࡤࡷࡰࡦࡪࡸࠧയ").format(framework_name) if bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩര") and bstack1l111l1l_opy_() else framework_name,
      bstack1l11ll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡶࡦࡴࡶ࡭ࡴࡴࠧറ"): bstack1llll11ll_opy_(framework_name),
      bstack1l11ll_opy_ (u"ࠫࡸࡪ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩല"): __version__,
      bstack1l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡷࡶࡩࡩ࠭ള"): bstack1l11l1111l_opy_
    })
  except Exception as e:
    logger.debug(bstack1ll1ll11l_opy_.format(bstack1l11ll_opy_ (u"࠭ࡏࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ഴ"), str(e)))
  if bstack1l11l1111l_opy_ in bstack11l1l1ll_opy_:
    try:
      framework_name = bstack1l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭വ") if bstack1l11l1111l_opy_ in [bstack1l11ll_opy_ (u"ࠨࡲࡤࡦࡴࡺࠧശ"), bstack1l11ll_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨഷ")] else bstack1l11l1111l_opy_
      if bstack1l1l1111_opy_ and bstack1l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪസ") in CONFIG and CONFIG[bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫഹ")] == True:
        if bstack1l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬഺ") in CONFIG:
          os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡢࡅࡈࡉࡅࡔࡕࡌࡆࡎࡒࡉࡕ࡛ࡢࡇࡔࡔࡆࡊࡉࡘࡖࡆ࡚ࡉࡐࡐࡢ࡝ࡒࡒ഻ࠧ")] = os.getenv(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨ഼"), json.dumps(CONFIG[bstack1l11ll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨഽ")]))
          CONFIG[bstack1l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩാ")].pop(bstack1l11ll_opy_ (u"ࠪ࡭ࡳࡩ࡬ࡶࡦࡨࡘࡦ࡭ࡳࡊࡰࡗࡩࡸࡺࡩ࡯ࡩࡖࡧࡴࡶࡥࠨി"), None)
          CONFIG[bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫീ")].pop(bstack1l11ll_opy_ (u"ࠬ࡫ࡸࡤ࡮ࡸࡨࡪ࡚ࡡࡨࡵࡌࡲ࡙࡫ࡳࡵ࡫ࡱ࡫ࡘࡩ࡯ࡱࡧࠪു"), None)
        bstack1l1ll1l1l1_opy_, bstack1l1ll1l1ll_opy_ = bstack1lll1ll1_opy_.bstack111111l1l_opy_(CONFIG, bstack1l11l1111l_opy_, bstack1llll11ll_opy_(framework_name), str(bstack1ll11lll11_opy_()))
        if not bstack1l1ll1l1l1_opy_ is None:
          os.environ[bstack1l11ll_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫൂ")] = bstack1l1ll1l1l1_opy_
          os.environ[bstack1l11ll_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡖࡈࡗ࡙ࡥࡒࡖࡐࡢࡍࡉ࠭ൃ")] = str(bstack1l1ll1l1ll_opy_)
    except Exception as e:
      logger.debug(bstack1ll1ll11l_opy_.format(bstack1l11ll_opy_ (u"ࠨࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨൄ"), str(e)))
  if bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ൅"):
    bstack1llll1ll11_opy_ = True
    if bstack11l1l111l_opy_ and bstack1111ll11l_opy_:
      bstack1llll11l11_opy_ = CONFIG.get(bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧെ"), {}).get(bstack1l11ll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭േ"))
      bstack1l1l1l1ll1_opy_(bstack11llllll_opy_)
    elif bstack11l1l111l_opy_:
      bstack1llll11l11_opy_ = CONFIG.get(bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩൈ"), {}).get(bstack1l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ൉"))
      global bstack1l1111l1l_opy_
      try:
        if bstack1ll11l11l_opy_(bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪൊ")]) and multiprocessing.current_process().name == bstack1l11ll_opy_ (u"ࠨ࠲ࠪോ"):
          bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬൌ")].remove(bstack1l11ll_opy_ (u"ࠪ࠱ࡲ്࠭"))
          bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧൎ")].remove(bstack1l11ll_opy_ (u"ࠬࡶࡤࡣࠩ൏"))
          bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ൐")] = bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪ൑")][0]
          with open(bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫ൒")], bstack1l11ll_opy_ (u"ࠩࡵࠫ൓")) as f:
            bstack1lllll11ll_opy_ = f.read()
          bstack1l11l1l1l_opy_ = bstack1l11ll_opy_ (u"ࠥࠦࠧ࡬ࡲࡰ࡯ࠣࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡶࡨࡰࠦࡩ࡮ࡲࡲࡶࡹࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡯࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡦ࠽ࠣࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡ࡬ࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡪ࠮ࡻࡾࠫ࠾ࠤ࡫ࡸ࡯࡮ࠢࡳࡨࡧࠦࡩ࡮ࡲࡲࡶࡹࠦࡐࡥࡤ࠾ࠤࡴ࡭࡟ࡥࡤࠣࡁࠥࡖࡤࡣ࠰ࡧࡳࡤࡨࡲࡦࡣ࡮࠿ࠏࡪࡥࡧࠢࡰࡳࡩࡥࡢࡳࡧࡤ࡯࠭ࡹࡥ࡭ࡨ࠯ࠤࡦࡸࡧ࠭ࠢࡷࡩࡲࡶ࡯ࡳࡣࡵࡽࠥࡃࠠ࠱ࠫ࠽ࠎࠥࠦࡴࡳࡻ࠽ࠎࠥࠦࠠࠡࡣࡵ࡫ࠥࡃࠠࡴࡶࡵࠬ࡮ࡴࡴࠩࡣࡵ࡫࠮࠱࠱࠱ࠫࠍࠤࠥ࡫ࡸࡤࡧࡳࡸࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡣࡶࠤࡪࡀࠊࠡࠢࠣࠤࡵࡧࡳࡴࠌࠣࠤࡴ࡭࡟ࡥࡤࠫࡷࡪࡲࡦ࠭ࡣࡵ࡫࠱ࡺࡥ࡮ࡲࡲࡶࡦࡸࡹࠪࠌࡓࡨࡧ࠴ࡤࡰࡡࡥࠤࡂࠦ࡭ࡰࡦࡢࡦࡷ࡫ࡡ࡬ࠌࡓࡨࡧ࠴ࡤࡰࡡࡥࡶࡪࡧ࡫ࠡ࠿ࠣࡱࡴࡪ࡟ࡣࡴࡨࡥࡰࠐࡐࡥࡤࠫ࠭࠳ࡹࡥࡵࡡࡷࡶࡦࡩࡥࠩࠫ࡟ࡲࠧࠨࠢൔ").format(str(bstack11l1l111l_opy_))
          bstack1l11llll1l_opy_ = bstack1l11l1l1l_opy_ + bstack1lllll11ll_opy_
          bstack11lll1lll_opy_ = bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧൕ")] + bstack1l11ll_opy_ (u"ࠬࡥࡢࡴࡶࡤࡧࡰࡥࡴࡦ࡯ࡳ࠲ࡵࡿࠧൖ")
          with open(bstack11lll1lll_opy_, bstack1l11ll_opy_ (u"࠭ࡷࠨൗ")):
            pass
          with open(bstack11lll1lll_opy_, bstack1l11ll_opy_ (u"ࠢࡸ࠭ࠥ൘")) as f:
            f.write(bstack1l11llll1l_opy_)
          import subprocess
          process_data = subprocess.run([bstack1l11ll_opy_ (u"ࠣࡲࡼࡸ࡭ࡵ࡮ࠣ൙"), bstack11lll1lll_opy_])
          if os.path.exists(bstack11lll1lll_opy_):
            os.unlink(bstack11lll1lll_opy_)
          os._exit(process_data.returncode)
        else:
          if bstack1ll11l11l_opy_(bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ൚")]):
            bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭൛")].remove(bstack1l11ll_opy_ (u"ࠫ࠲ࡳࠧ൜"))
            bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ൝")].remove(bstack1l11ll_opy_ (u"࠭ࡰࡥࡤࠪ൞"))
            bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪൟ")] = bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫൠ")][0]
          bstack1l1l1l1ll1_opy_(bstack11llllll_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬൡ")])))
          sys.argv = sys.argv[2:]
          mod_globals = globals()
          mod_globals[bstack1l11ll_opy_ (u"ࠪࡣࡤࡴࡡ࡮ࡧࡢࡣࠬൢ")] = bstack1l11ll_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ൣ")
          mod_globals[bstack1l11ll_opy_ (u"ࠬࡥ࡟ࡧ࡫࡯ࡩࡤࡥࠧ൤")] = os.path.abspath(bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ൥")])
          exec(open(bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪ൦")]).read(), mod_globals)
      except BaseException as e:
        try:
          traceback.print_exc()
          logger.error(bstack1l11ll_opy_ (u"ࠨࡅࡤࡹ࡬࡮ࡴࠡࡇࡻࡧࡪࡶࡴࡪࡱࡱ࠾ࠥࢁࡽࠨ൧").format(str(e)))
          for driver in bstack1l1111l1l_opy_:
            bstack1l111lllll_opy_.append({
              bstack1l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ൨"): bstack11l1l111l_opy_[bstack1l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭൩")],
              bstack1l11ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪ൪"): str(e),
              bstack1l11ll_opy_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ൫"): multiprocessing.current_process().name
            })
            bstack1l11lll1l_opy_(driver, bstack1l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭൬"), bstack1l11ll_opy_ (u"ࠢࡔࡧࡶࡷ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡹ࡬ࡸ࡭ࡀࠠ࡝ࡰࠥ൭") + str(e))
        except Exception:
          pass
      finally:
        try:
          for driver in bstack1l1111l1l_opy_:
            driver.quit()
        except Exception as e:
          pass
    else:
      percy.init(bstack1llllll111_opy_, CONFIG, logger)
      bstack1lllll1ll_opy_()
      bstack1l1l11l1_opy_()
      bstack1ll111ll_opy_ = {
        bstack1l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫ൮"): args[0],
        bstack1l11ll_opy_ (u"ࠩࡆࡓࡓࡌࡉࡈࠩ൯"): CONFIG,
        bstack1l11ll_opy_ (u"ࠪࡌ࡚ࡈ࡟ࡖࡔࡏࠫ൰"): bstack1ll1l1l1l1_opy_,
        bstack1l11ll_opy_ (u"ࠫࡎ࡙࡟ࡂࡒࡓࡣࡆ࡛ࡔࡐࡏࡄࡘࡊ࠭൱"): bstack1llllll111_opy_
      }
      percy.bstack1ll1ll1ll_opy_()
      if bstack1l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ൲") in CONFIG:
        bstack1llll111_opy_ = []
        manager = multiprocessing.Manager()
        bstack1ll1111l_opy_ = manager.list()
        if bstack1ll11l11l_opy_(args):
          for index, platform in enumerate(CONFIG[bstack1l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ൳")]):
            if index == 0:
              bstack1ll111ll_opy_[bstack1l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪ൴")] = args
            bstack1llll111_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1ll111ll_opy_, bstack1ll1111l_opy_)))
        else:
          for index, platform in enumerate(CONFIG[bstack1l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ൵")]):
            bstack1llll111_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1ll111ll_opy_, bstack1ll1111l_opy_)))
        for t in bstack1llll111_opy_:
          t.start()
        for t in bstack1llll111_opy_:
          t.join()
        bstack1l11l111l1_opy_ = list(bstack1ll1111l_opy_)
      else:
        if bstack1ll11l11l_opy_(args):
          bstack1ll111ll_opy_[bstack1l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ൶")] = args
          test = multiprocessing.Process(name=str(0),
                                         target=run_on_browserstack, args=(bstack1ll111ll_opy_,))
          test.start()
          test.join()
        else:
          bstack1l1l1l1ll1_opy_(bstack11llllll_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(args[0])))
          mod_globals = globals()
          mod_globals[bstack1l11ll_opy_ (u"ࠪࡣࡤࡴࡡ࡮ࡧࡢࡣࠬ൷")] = bstack1l11ll_opy_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭൸")
          mod_globals[bstack1l11ll_opy_ (u"ࠬࡥ࡟ࡧ࡫࡯ࡩࡤࡥࠧ൹")] = os.path.abspath(args[0])
          sys.argv = sys.argv[2:]
          exec(open(args[0]).read(), mod_globals)
  elif bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"࠭ࡰࡢࡤࡲࡸࠬൺ") or bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ൻ"):
    percy.init(bstack1llllll111_opy_, CONFIG, logger)
    percy.bstack1ll1ll1ll_opy_()
    try:
      from pabot import pabot
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack1111l111l_opy_)
    bstack1lllll1ll_opy_()
    bstack1l1l1l1ll1_opy_(bstack1l11111l1_opy_)
    if bstack1l1l1111_opy_ and bstack1l11ll_opy_ (u"ࠨ࠯࠰ࡴࡷࡵࡣࡦࡵࡶࡩࡸ࠭ർ") in args:
      i = args.index(bstack1l11ll_opy_ (u"ࠩ࠰࠱ࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠧൽ"))
      args.pop(i)
      args.pop(i)
    if bstack1l1l1111_opy_:
      args.insert(0, str(bstack1l11lll11_opy_))
      args.insert(0, str(bstack1l11ll_opy_ (u"ࠪ࠱࠲ࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠨൾ")))
    if bstack111lll1_opy_.on():
      try:
        from robot.run import USAGE
        from robot.utils import ArgumentParser
        from pabot.arguments import _parse_pabot_args
        bstack1l1l1ll111_opy_, pabot_args = _parse_pabot_args(args)
        opts, bstack11l11llll_opy_ = ArgumentParser(
            USAGE,
            auto_pythonpath=False,
            auto_argumentfile=True,
            env_options=bstack1l11ll_opy_ (u"ࠦࡗࡕࡂࡐࡖࡢࡓࡕ࡚ࡉࡐࡐࡖࠦൿ"),
        ).parse_args(bstack1l1l1ll111_opy_)
        bstack111111l11_opy_ = args.index(bstack1l1l1ll111_opy_[0]) if len(bstack1l1l1ll111_opy_) > 0 else len(args)
        args.insert(bstack111111l11_opy_, str(bstack1l11ll_opy_ (u"ࠬ࠳࠭࡭࡫ࡶࡸࡪࡴࡥࡳࠩ඀")))
        args.insert(bstack111111l11_opy_ + 1, str(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥࡲࡰࡤࡲࡸࡤࡲࡩࡴࡶࡨࡲࡪࡸ࠮ࡱࡻࠪඁ"))))
        if is_true(os.environ.get(bstack1l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡒࡆࡔࡘࡒࠬං"))) and str(os.environ.get(bstack1l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡓࡇࡕ࡙ࡓࡥࡔࡆࡕࡗࡗࠬඃ"), bstack1l11ll_opy_ (u"ࠩࡱࡹࡱࡲࠧ඄"))) != bstack1l11ll_opy_ (u"ࠪࡲࡺࡲ࡬ࠨඅ"):
          for bstack1ll1l111l_opy_ in bstack11l11llll_opy_:
            args.remove(bstack1ll1l111l_opy_)
          bstack1l1ll1l111_opy_ = os.environ.get(bstack1l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡖࡊࡘࡕࡏࡡࡗࡉࡘ࡚ࡓࠨආ")).split(bstack1l11ll_opy_ (u"ࠬ࠲ࠧඇ"))
          for bstack1ll1l11l1_opy_ in bstack1l1ll1l111_opy_:
            args.append(bstack1ll1l11l1_opy_)
      except Exception as e:
        logger.error(bstack1l11ll_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡦࡺࡴࡢࡥ࡫࡭ࡳ࡭ࠠ࡭࡫ࡶࡸࡪࡴࡥࡳࠢࡩࡳࡷࠦࡏࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠴ࠠࡆࡴࡵࡳࡷࠦ࠭ࠡࠤඈ").format(e))
    pabot.main(args)
  elif bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠨඉ"):
    try:
      from robot import run_cli
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack1111l111l_opy_)
    for a in args:
      if bstack1l11ll_opy_ (u"ࠨࡄࡖࡘࡆࡉࡋࡑࡎࡄࡘࡋࡕࡒࡎࡋࡑࡈࡊ࡞ࠧඊ") in a:
        bstack1llll1llll_opy_ = int(a.split(bstack1l11ll_opy_ (u"ࠩ࠽ࠫඋ"))[1])
      if bstack1l11ll_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡇࡉࡋࡒࡏࡄࡃࡏࡍࡉࡋࡎࡕࡋࡉࡍࡊࡘࠧඌ") in a:
        bstack1llll11l11_opy_ = str(a.split(bstack1l11ll_opy_ (u"ࠫ࠿࠭ඍ"))[1])
      if bstack1l11ll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡈࡒࡉࡂࡔࡊࡗࠬඎ") in a:
        bstack1111l1lll_opy_ = str(a.split(bstack1l11ll_opy_ (u"࠭࠺ࠨඏ"))[1])
    bstack1l11lll1ll_opy_ = None
    if bstack1l11ll_opy_ (u"ࠧ࠮࠯ࡥࡷࡹࡧࡣ࡬ࡡ࡬ࡸࡪࡳ࡟ࡪࡰࡧࡩࡽ࠭ඐ") in args:
      i = args.index(bstack1l11ll_opy_ (u"ࠨ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠧඑ"))
      args.pop(i)
      bstack1l11lll1ll_opy_ = args.pop(i)
    if bstack1l11lll1ll_opy_ is not None:
      global bstack1ll111l111_opy_
      bstack1ll111l111_opy_ = bstack1l11lll1ll_opy_
    bstack1l1l1l1ll1_opy_(bstack1l11111l1_opy_)
    run_cli(args)
    if bstack1l11ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠭ඒ") in multiprocessing.current_process().__dict__.keys():
      for bstack1l1l1l1l1_opy_ in multiprocessing.current_process().bstack_error_list:
        bstack1l111lllll_opy_.append(bstack1l1l1l1l1_opy_)
  elif bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪඓ"):
    percy.init(bstack1llllll111_opy_, CONFIG, logger)
    percy.bstack1ll1ll1ll_opy_()
    bstack1ll1ll1ll1_opy_ = bstack1lll1l1l_opy_(args, logger, CONFIG, bstack1l1l1111_opy_)
    bstack1ll1ll1ll1_opy_.bstack1l1ll1l1_opy_()
    bstack1lllll1ll_opy_()
    bstack1llll11ll1_opy_ = True
    bstack1l1l1111ll_opy_ = bstack1ll1ll1ll1_opy_.bstack1l1lllll_opy_()
    bstack1ll1ll1ll1_opy_.bstack1ll111ll_opy_(bstack1lll11lll1_opy_)
    bstack1l1lllll1_opy_ = bstack1ll1ll1ll1_opy_.bstack1l1ll111_opy_(bstack111l1111_opy_, {
      bstack1l11ll_opy_ (u"ࠫࡍ࡛ࡂࡠࡗࡕࡐࠬඔ"): bstack1ll1l1l1l1_opy_,
      bstack1l11ll_opy_ (u"ࠬࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧඕ"): bstack1llllll111_opy_,
      bstack1l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩඖ"): bstack1l1l1111_opy_
    })
    try:
      bstack11l1lll1l_opy_, bstack1l1l11l1l_opy_ = map(list, zip(*bstack1l1lllll1_opy_))
      bstack1l1l1l111l_opy_ = bstack11l1lll1l_opy_[0]
      for status_code in bstack1l1l11l1l_opy_:
        if status_code != 0:
          bstack1l11111ll_opy_ = status_code
          break
    except Exception as e:
      logger.debug(bstack1l11ll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡷࡦࡼࡥࠡࡧࡵࡶࡴࡸࡳࠡࡣࡱࡨࠥࡹࡴࡢࡶࡸࡷࠥࡩ࡯ࡥࡧ࠱ࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠ࠻ࠢࡾࢁࠧ඗").format(str(e)))
  elif bstack1l11l1111l_opy_ == bstack1l11ll_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ඘"):
    try:
      from behave.__main__ import main as bstack1llll1l1ll_opy_
      from behave.configuration import Configuration
    except Exception as e:
      bstack1llllll1l1_opy_(e, bstack11ll11111_opy_)
    bstack1lllll1ll_opy_()
    bstack1llll11ll1_opy_ = True
    bstack1l1ll1ll_opy_ = 1
    if bstack1l11ll_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ඙") in CONFIG:
      bstack1l1ll1ll_opy_ = CONFIG[bstack1l11ll_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪක")]
    bstack1l1lll11l_opy_ = int(bstack1l1ll1ll_opy_) * int(len(CONFIG[bstack1l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧඛ")]))
    config = Configuration(args)
    bstack111lll11_opy_ = config.paths
    if len(bstack111lll11_opy_) == 0:
      import glob
      pattern = bstack1l11ll_opy_ (u"ࠬ࠰ࠪ࠰ࠬ࠱ࡪࡪࡧࡴࡶࡴࡨࠫග")
      bstack1lll11ll1l_opy_ = glob.glob(pattern, recursive=True)
      args.extend(bstack1lll11ll1l_opy_)
      config = Configuration(args)
      bstack111lll11_opy_ = config.paths
    bstack1ll11111_opy_ = [os.path.normpath(item) for item in bstack111lll11_opy_]
    bstack1l1ll11l11_opy_ = [os.path.normpath(item) for item in args]
    bstack1lll1l11l_opy_ = [item for item in bstack1l1ll11l11_opy_ if item not in bstack1ll11111_opy_]
    import platform as pf
    if pf.system().lower() == bstack1l11ll_opy_ (u"࠭ࡷࡪࡰࡧࡳࡼࡹࠧඝ"):
      from pathlib import PureWindowsPath, PurePosixPath
      bstack1ll11111_opy_ = [str(PurePosixPath(PureWindowsPath(bstack111lll1l_opy_)))
                    for bstack111lll1l_opy_ in bstack1ll11111_opy_]
    bstack1lll11ll_opy_ = []
    for spec in bstack1ll11111_opy_:
      bstack1l1lll1l_opy_ = []
      bstack1l1lll1l_opy_ += bstack1lll1l11l_opy_
      bstack1l1lll1l_opy_.append(spec)
      bstack1lll11ll_opy_.append(bstack1l1lll1l_opy_)
    execution_items = []
    for bstack1l1lll1l_opy_ in bstack1lll11ll_opy_:
      for index, _ in enumerate(CONFIG[bstack1l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪඞ")]):
        item = {}
        item[bstack1l11ll_opy_ (u"ࠨࡣࡵ࡫ࠬඟ")] = bstack1l11ll_opy_ (u"ࠩࠣࠫච").join(bstack1l1lll1l_opy_)
        item[bstack1l11ll_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩඡ")] = index
        execution_items.append(item)
    bstack1l111l11l_opy_ = bstack1l11l11lll_opy_(execution_items, bstack1l1lll11l_opy_)
    for execution_item in bstack1l111l11l_opy_:
      bstack1llll111_opy_ = []
      for item in execution_item:
        bstack1llll111_opy_.append(bstack1111lll11_opy_(name=str(item[bstack1l11ll_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪජ")]),
                                             target=bstack1llll1l1l1_opy_,
                                             args=(item[bstack1l11ll_opy_ (u"ࠬࡧࡲࡨࠩඣ")],)))
      for t in bstack1llll111_opy_:
        t.start()
      for t in bstack1llll111_opy_:
        t.join()
  else:
    bstack1111ll11_opy_(bstack1llllll11_opy_)
  if not bstack11l1l111l_opy_:
    bstack1l11l1llll_opy_()
  bstack1ll1l1111l_opy_.bstack1ll11l1ll1_opy_()
def browserstack_initialize(bstack11l111l1l_opy_=None):
  run_on_browserstack(bstack11l111l1l_opy_, None, True)
def bstack1l11l1llll_opy_():
  global CONFIG
  global bstack1l11lll11l_opy_
  global bstack1l11111ll_opy_
  bstack111lll1_opy_.stop()
  bstack111lll1_opy_.bstack1ll1l1lll_opy_()
  if bstack1lll1ll1_opy_.bstack11ll1111_opy_(CONFIG):
    bstack1lll1ll1_opy_.bstack1l111l111_opy_()
  [bstack1l1lll1l1l_opy_, bstack11lll1l11_opy_] = get_build_link()
  if bstack1l1lll1l1l_opy_ is not None and bstack1ll11l111l_opy_() != -1:
    sessions = bstack11llll111_opy_(bstack1l1lll1l1l_opy_)
    bstack1ll111ll1l_opy_(sessions, bstack11lll1l11_opy_)
  if bstack1l11lll11l_opy_ == bstack1l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ඤ") and bstack1l11111ll_opy_ != 0:
    sys.exit(bstack1l11111ll_opy_)
def bstack1ll1lll11_opy_(bstack1l1ll111l1_opy_):
  if bstack1l1ll111l1_opy_:
    return bstack1l1ll111l1_opy_.capitalize()
  else:
    return bstack1l11ll_opy_ (u"ࠧࠨඥ")
def bstack11111l1l1_opy_(bstack11ll1ll11_opy_):
  if bstack1l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ඦ") in bstack11ll1ll11_opy_ and bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧට")] != bstack1l11ll_opy_ (u"ࠪࠫඨ"):
    return bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩඩ")]
  else:
    bstack111l11lll_opy_ = bstack1l11ll_opy_ (u"ࠧࠨඪ")
    if bstack1l11ll_opy_ (u"࠭ࡤࡦࡸ࡬ࡧࡪ࠭ණ") in bstack11ll1ll11_opy_ and bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠧࡥࡧࡹ࡭ࡨ࡫ࠧඬ")] != None:
      bstack111l11lll_opy_ += bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨත")] + bstack1l11ll_opy_ (u"ࠤ࠯ࠤࠧථ")
      if bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠪࡳࡸ࠭ද")] == bstack1l11ll_opy_ (u"ࠦ࡮ࡵࡳࠣධ"):
        bstack111l11lll_opy_ += bstack1l11ll_opy_ (u"ࠧ࡯ࡏࡔࠢࠥන")
      bstack111l11lll_opy_ += (bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"࠭࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠪ඲")] or bstack1l11ll_opy_ (u"ࠧࠨඳ"))
      return bstack111l11lll_opy_
    else:
      bstack111l11lll_opy_ += bstack1ll1lll11_opy_(bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩප")]) + bstack1l11ll_opy_ (u"ࠤࠣࠦඵ") + (
              bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬබ")] or bstack1l11ll_opy_ (u"ࠫࠬභ")) + bstack1l11ll_opy_ (u"ࠧ࠲ࠠࠣම")
      if bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"࠭࡯ࡴࠩඹ")] == bstack1l11ll_opy_ (u"ࠢࡘ࡫ࡱࡨࡴࡽࡳࠣය"):
        bstack111l11lll_opy_ += bstack1l11ll_opy_ (u"࡙ࠣ࡬ࡲࠥࠨර")
      bstack111l11lll_opy_ += bstack11ll1ll11_opy_[bstack1l11ll_opy_ (u"ࠩࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭඼")] or bstack1l11ll_opy_ (u"ࠪࠫල")
      return bstack111l11lll_opy_
def bstack1l1l111l1_opy_(bstack11l11l111_opy_):
  if bstack11l11l111_opy_ == bstack1l11ll_opy_ (u"ࠦࡩࡵ࡮ࡦࠤ඾"):
    return bstack1l11ll_opy_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࡨࡴࡨࡩࡳࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡨࡴࡨࡩࡳࠨ࠾ࡄࡱࡰࡴࡱ࡫ࡴࡦࡦ࠿࠳࡫ࡵ࡮ࡵࡀ࠿࠳ࡹࡪ࠾ࠨ඿")
  elif bstack11l11l111_opy_ == bstack1l11ll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨව"):
    return bstack1l11ll_opy_ (u"ࠧ࠽ࡶࡧࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࡵࡩࡩࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃࡌࡡࡪ࡮ࡨࡨࡁ࠵ࡦࡰࡰࡷࡂࡁ࠵ࡴࡥࡀࠪශ")
  elif bstack11l11l111_opy_ == bstack1l11ll_opy_ (u"ࠣࡲࡤࡷࡸ࡫ࡤࠣෂ"):
    return bstack1l11ll_opy_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾࡬ࡸࡥࡦࡰ࠾ࠦࡃࡂࡦࡰࡰࡷࠤࡨࡵ࡬ࡰࡴࡀࠦ࡬ࡸࡥࡦࡰࠥࡂࡕࡧࡳࡴࡧࡧࡀ࠴࡬࡯࡯ࡶࡁࡀ࠴ࡺࡤ࠿ࠩස")
  elif bstack11l11l111_opy_ == bstack1l11ll_opy_ (u"ࠥࡩࡷࡸ࡯ࡳࠤහ"):
    return bstack1l11ll_opy_ (u"ࠫࡁࡺࡤࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࡲࡦࡦ࠾ࠦࡃࡂࡦࡰࡰࡷࠤࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࡈࡶࡷࡵࡲ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭ළ")
  elif bstack11l11l111_opy_ == bstack1l11ll_opy_ (u"ࠧࡺࡩ࡮ࡧࡲࡹࡹࠨෆ"):
    return bstack1l11ll_opy_ (u"࠭࠼ࡵࡦࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠥࡨࡩࡦ࠹࠲࠷࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥࠧࡪ࡫ࡡ࠴࠴࠹ࠦࡃ࡚ࡩ࡮ࡧࡲࡹࡹࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁࠫ෇")
  elif bstack11l11l111_opy_ == bstack1l11ll_opy_ (u"ࠢࡳࡷࡱࡲ࡮ࡴࡧࠣ෈"):
    return bstack1l11ll_opy_ (u"ࠨ࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽ࡦࡱࡧࡣ࡬࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥࡦࡱࡧࡣ࡬ࠤࡁࡖࡺࡴ࡮ࡪࡰࡪࡀ࠴࡬࡯࡯ࡶࡁࡀ࠴ࡺࡤ࠿ࠩ෉")
  else:
    return bstack1l11ll_opy_ (u"ࠩ࠿ࡸࡩࠦࡡ࡭࡫ࡪࡲࡂࠨࡣࡦࡰࡷࡩࡷࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࡨ࡬ࡢࡥ࡮࠿ࠧࡄ࠼ࡧࡱࡱࡸࠥࡩ࡯࡭ࡱࡵࡁࠧࡨ࡬ࡢࡥ࡮ࠦࡃ්࠭") + bstack1ll1lll11_opy_(
      bstack11l11l111_opy_) + bstack1l11ll_opy_ (u"ࠪࡀ࠴࡬࡯࡯ࡶࡁࡀ࠴ࡺࡤ࠿ࠩ෋")
def bstack11111ll1l_opy_(session):
  return bstack1l11ll_opy_ (u"ࠫࡁࡺࡲࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡴࡲࡻࠧࡄ࠼ࡵࡦࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠡࡵࡨࡷࡸ࡯࡯࡯࠯ࡱࡥࡲ࡫ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࡿࢂࠨࠠࡵࡣࡵ࡫ࡪࡺ࠽ࠣࡡࡥࡰࡦࡴ࡫ࠣࡀࡾࢁࡁ࠵ࡡ࠿࠾࠲ࡸࡩࡄࡻࡾࡽࢀࡀࡹࡪࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨ࠾ࡼࡿ࠿࠳ࡹࡪ࠾࠽ࡶࡧࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࡂࢀࢃ࠼࠰ࡶࡧࡂࡁࡺࡤࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢ࠿ࡽࢀࡀ࠴ࡺࡤ࠿࠾ࡷࡨࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࡃࢁࡽ࠽࠱ࡷࡨࡃࡂ࠯ࡵࡴࡁࠫ෌").format(
    session[bstack1l11ll_opy_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡤࡻࡲ࡭ࠩ෍")], bstack11111l1l1_opy_(session), bstack1l1l111l1_opy_(session[bstack1l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤࡹࡴࡢࡶࡸࡷࠬ෎")]),
    bstack1l1l111l1_opy_(session[bstack1l11ll_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧා")]),
    bstack1ll1lll11_opy_(session[bstack1l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩැ")] or session[bstack1l11ll_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࠩෑ")] or bstack1l11ll_opy_ (u"ࠪࠫි")) + bstack1l11ll_opy_ (u"ࠦࠥࠨී") + (session[bstack1l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧු")] or bstack1l11ll_opy_ (u"࠭ࠧ෕")),
    session[bstack1l11ll_opy_ (u"ࠧࡰࡵࠪූ")] + bstack1l11ll_opy_ (u"ࠣࠢࠥ෗") + session[bstack1l11ll_opy_ (u"ࠩࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ෘ")], session[bstack1l11ll_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬෙ")] or bstack1l11ll_opy_ (u"ࠫࠬේ"),
    session[bstack1l11ll_opy_ (u"ࠬࡩࡲࡦࡣࡷࡩࡩࡥࡡࡵࠩෛ")] if session[bstack1l11ll_opy_ (u"࠭ࡣࡳࡧࡤࡸࡪࡪ࡟ࡢࡶࠪො")] else bstack1l11ll_opy_ (u"ࠧࠨෝ"))
def bstack1ll111ll1l_opy_(sessions, bstack11lll1l11_opy_):
  try:
    bstack1llll1l1l_opy_ = bstack1l11ll_opy_ (u"ࠣࠤෞ")
    if not os.path.exists(bstack1l111llll_opy_):
      os.mkdir(bstack1l111llll_opy_)
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1l11ll_opy_ (u"ࠩࡤࡷࡸ࡫ࡴࡴ࠱ࡵࡩࡵࡵࡲࡵ࠰࡫ࡸࡲࡲࠧෟ")), bstack1l11ll_opy_ (u"ࠪࡶࠬ෠")) as f:
      bstack1llll1l1l_opy_ = f.read()
    bstack1llll1l1l_opy_ = bstack1llll1l1l_opy_.replace(bstack1l11ll_opy_ (u"ࠫࢀࠫࡒࡆࡕࡘࡐ࡙࡙࡟ࡄࡑࡘࡒ࡙ࠫࡽࠨ෡"), str(len(sessions)))
    bstack1llll1l1l_opy_ = bstack1llll1l1l_opy_.replace(bstack1l11ll_opy_ (u"ࠬࢁࠥࡃࡗࡌࡐࡉࡥࡕࡓࡎࠨࢁࠬ෢"), bstack11lll1l11_opy_)
    bstack1llll1l1l_opy_ = bstack1llll1l1l_opy_.replace(bstack1l11ll_opy_ (u"࠭ࡻࠦࡄࡘࡍࡑࡊ࡟ࡏࡃࡐࡉࠪࢃࠧ෣"),
                                              sessions[0].get(bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥ࡮ࡢ࡯ࡨࠫ෤")) if sessions[0] else bstack1l11ll_opy_ (u"ࠨࠩ෥"))
    with open(os.path.join(bstack1l111llll_opy_, bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠮ࡴࡨࡴࡴࡸࡴ࠯ࡪࡷࡱࡱ࠭෦")), bstack1l11ll_opy_ (u"ࠪࡻࠬ෧")) as stream:
      stream.write(bstack1llll1l1l_opy_.split(bstack1l11ll_opy_ (u"ࠫࢀࠫࡓࡆࡕࡖࡍࡔࡔࡓࡠࡆࡄࡘࡆࠫࡽࠨ෨"))[0])
      for session in sessions:
        stream.write(bstack11111ll1l_opy_(session))
      stream.write(bstack1llll1l1l_opy_.split(bstack1l11ll_opy_ (u"ࠬࢁࠥࡔࡇࡖࡗࡎࡕࡎࡔࡡࡇࡅ࡙ࡇࠥࡾࠩ෩"))[1])
    logger.info(bstack1l11ll_opy_ (u"࠭ࡇࡦࡰࡨࡶࡦࡺࡥࡥࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠡࡤࡸ࡭ࡱࡪࠠࡢࡴࡷ࡭࡫ࡧࡣࡵࡵࠣࡥࡹࠦࡻࡾࠩ෪").format(bstack1l111llll_opy_));
  except Exception as e:
    logger.debug(bstack1ll1l1lll1_opy_.format(str(e)))
def bstack11llll111_opy_(bstack1l1lll1l1l_opy_):
  global CONFIG
  try:
    host = bstack1l11ll_opy_ (u"ࠧࡢࡲ࡬࠱ࡨࡲ࡯ࡶࡦࠪ෫") if bstack1l11ll_opy_ (u"ࠨࡣࡳࡴࠬ෬") in CONFIG else bstack1l11ll_opy_ (u"ࠩࡤࡴ࡮࠭෭")
    user = CONFIG[bstack1l11ll_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬ෮")]
    key = CONFIG[bstack1l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧ෯")]
    bstack11111l111_opy_ = bstack1l11ll_opy_ (u"ࠬࡧࡰࡱ࠯ࡤࡹࡹࡵ࡭ࡢࡶࡨࠫ෰") if bstack1l11ll_opy_ (u"࠭ࡡࡱࡲࠪ෱") in CONFIG else bstack1l11ll_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡦࠩෲ")
    url = bstack1l11ll_opy_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡾࢁ࠿ࢁࡽࡁࡽࢀ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳ࠯ࡼࡿ࠲ࡦࡺ࡯࡬ࡥࡵ࠲ࡿࢂ࠵ࡳࡦࡵࡶ࡭ࡴࡴࡳ࠯࡬ࡶࡳࡳ࠭ෳ").format(user, key, host, bstack11111l111_opy_,
                                                                                bstack1l1lll1l1l_opy_)
    headers = {
      bstack1l11ll_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ෴"): bstack1l11ll_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭෵"),
    }
    proxies = bstack1111l1111_opy_(CONFIG, url)
    response = requests.get(url, headers=headers, proxies=proxies)
    if response.json():
      return list(map(lambda session: session[bstack1l11ll_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ෶")], response.json()))
  except Exception as e:
    logger.debug(bstack1l111l1ll_opy_.format(str(e)))
def get_build_link():
  global CONFIG
  global bstack11lllll1_opy_
  try:
    if bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨ෷") in CONFIG:
      host = bstack1l11ll_opy_ (u"࠭ࡡࡱ࡫࠰ࡧࡱࡵࡵࡥࠩ෸") if bstack1l11ll_opy_ (u"ࠧࡢࡲࡳࠫ෹") in CONFIG else bstack1l11ll_opy_ (u"ࠨࡣࡳ࡭ࠬ෺")
      user = CONFIG[bstack1l11ll_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ෻")]
      key = CONFIG[bstack1l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭෼")]
      bstack11111l111_opy_ = bstack1l11ll_opy_ (u"ࠫࡦࡶࡰ࠮ࡣࡸࡸࡴࡳࡡࡵࡧࠪ෽") if bstack1l11ll_opy_ (u"ࠬࡧࡰࡱࠩ෾") in CONFIG else bstack1l11ll_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡥࠨ෿")
      url = bstack1l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡽࢀ࠾ࢀࢃࡀࡼࡿ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡻࡾ࠱ࡥࡹ࡮ࡲࡤࡴ࠰࡭ࡷࡴࡴࠧ฀").format(user, key, host, bstack11111l111_opy_)
      headers = {
        bstack1l11ll_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧก"): bstack1l11ll_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬข"),
      }
      if bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬฃ") in CONFIG:
        params = {bstack1l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩค"): CONFIG[bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨฅ")], bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩฆ"): CONFIG[bstack1l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩง")]}
      else:
        params = {bstack1l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭จ"): CONFIG[bstack1l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬฉ")]}
      proxies = bstack1111l1111_opy_(CONFIG, url)
      response = requests.get(url, params=params, headers=headers, proxies=proxies)
      if response.json():
        bstack1l1lll111_opy_ = response.json()[0][bstack1l11ll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴ࡟ࡣࡷ࡬ࡰࡩ࠭ช")]
        if bstack1l1lll111_opy_:
          bstack11lll1l11_opy_ = bstack1l1lll111_opy_[bstack1l11ll_opy_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡣࡺࡸ࡬ࠨซ")].split(bstack1l11ll_opy_ (u"ࠬࡶࡵࡣ࡮࡬ࡧ࠲ࡨࡵࡪ࡮ࡧࠫฌ"))[0] + bstack1l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡸ࠵ࠧญ") + bstack1l1lll111_opy_[
            bstack1l11ll_opy_ (u"ࠧࡩࡣࡶ࡬ࡪࡪ࡟ࡪࡦࠪฎ")]
          logger.info(bstack1ll11lll1_opy_.format(bstack11lll1l11_opy_))
          bstack11lllll1_opy_ = bstack1l1lll111_opy_[bstack1l11ll_opy_ (u"ࠨࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫฏ")]
          bstack1111lll1_opy_ = CONFIG[bstack1l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬฐ")]
          if bstack1l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬฑ") in CONFIG:
            bstack1111lll1_opy_ += bstack1l11ll_opy_ (u"ࠫࠥ࠭ฒ") + CONFIG[bstack1l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧณ")]
          if bstack1111lll1_opy_ != bstack1l1lll111_opy_[bstack1l11ll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫด")]:
            logger.debug(bstack1ll111ll1_opy_.format(bstack1l1lll111_opy_[bstack1l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬต")], bstack1111lll1_opy_))
          return [bstack1l1lll111_opy_[bstack1l11ll_opy_ (u"ࠨࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫถ")], bstack11lll1l11_opy_]
    else:
      logger.warn(bstack111111lll_opy_)
  except Exception as e:
    logger.debug(bstack1l1lllllll_opy_.format(str(e)))
  return [None, None]
def bstack1l11l1ll1_opy_(url, bstack1ll1ll1lll_opy_=False):
  global CONFIG
  global bstack1ll11l1111_opy_
  if not bstack1ll11l1111_opy_:
    hostname = bstack11ll1llll_opy_(url)
    is_private = bstack1ll1llllll_opy_(hostname)
    if (bstack1l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ท") in CONFIG and not is_true(CONFIG[bstack1l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧธ")])) and (is_private or bstack1ll1ll1lll_opy_):
      bstack1ll11l1111_opy_ = hostname
def bstack11ll1llll_opy_(url):
  return urlparse(url).hostname
def bstack1ll1llllll_opy_(hostname):
  for bstack11l1111ll_opy_ in bstack11llll11_opy_:
    regex = re.compile(bstack11l1111ll_opy_)
    if regex.match(hostname):
      return True
  return False
def bstack1l11l1lll_opy_(key_name):
  return True if key_name in threading.current_thread().__dict__.keys() else False
def getAccessibilityResults(driver):
  global CONFIG
  global bstack1llll1llll_opy_
  bstack1ll1llll1_opy_ = not (bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠫ࡮ࡹࡁ࠲࠳ࡼࡘࡪࡹࡴࠨน"), None) and bstack1111111_opy_(
          threading.current_thread(), bstack1l11ll_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫบ"), None))
  bstack1ll1111ll_opy_ = getattr(driver, bstack1l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡇ࠱࠲ࡻࡖ࡬ࡴࡻ࡬ࡥࡕࡦࡥࡳ࠭ป"), None) != True
  if not bstack1lll1ll1_opy_.bstack1l1ll11ll_opy_(CONFIG, bstack1llll1llll_opy_) or (bstack1ll1111ll_opy_ and bstack1ll1llll1_opy_):
    logger.warning(bstack1l11ll_opy_ (u"ࠢࡏࡱࡷࠤࡦࡴࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡸ࡫ࡳࡴ࡫ࡲࡲ࠱ࠦࡣࡢࡰࡱࡳࡹࠦࡲࡦࡶࡵ࡭ࡪࡼࡥࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡴࡨࡷࡺࡲࡴࡴ࠰ࠥผ"))
    return {}
  try:
    logger.debug(bstack1l11ll_opy_ (u"ࠨࡒࡨࡶ࡫ࡵࡲ࡮࡫ࡱ࡫ࠥࡹࡣࡢࡰࠣࡦࡪ࡬࡯ࡳࡧࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠬฝ"))
    logger.debug(perform_scan(driver))
    results = driver.execute_async_script(bstack1lll1ll1l1_opy_.bstack1l11l11l1_opy_)
    return results
  except Exception:
    logger.error(bstack1l11ll_opy_ (u"ࠤࡑࡳࠥࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡸࡥࡴࡷ࡯ࡸࡸࠦࡷࡦࡴࡨࠤ࡫ࡵࡵ࡯ࡦ࠱ࠦพ"))
    return {}
def getAccessibilityResultsSummary(driver):
  global CONFIG
  global bstack1llll1llll_opy_
  bstack1ll1llll1_opy_ = not (bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠪ࡭ࡸࡇ࠱࠲ࡻࡗࡩࡸࡺࠧฟ"), None) and bstack1111111_opy_(
          threading.current_thread(), bstack1l11ll_opy_ (u"ࠫࡦ࠷࠱ࡺࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪภ"), None))
  bstack1ll1111ll_opy_ = getattr(driver, bstack1l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡆ࠷࠱ࡺࡕ࡫ࡳࡺࡲࡤࡔࡥࡤࡲࠬม"), None) != True
  if not bstack1lll1ll1_opy_.bstack1l1ll11ll_opy_(CONFIG, bstack1llll1llll_opy_) or (bstack1ll1111ll_opy_ and bstack1ll1llll1_opy_):
    logger.warning(bstack1l11ll_opy_ (u"ࠨࡎࡰࡶࠣࡥࡳࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡷࡪࡹࡳࡪࡱࡱ࠰ࠥࡩࡡ࡯ࡰࡲࡸࠥࡸࡥࡵࡴ࡬ࡩࡻ࡫ࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡳࡧࡶࡹࡱࡺࡳࠡࡵࡸࡱࡲࡧࡲࡺ࠰ࠥย"))
    return {}
  try:
    logger.debug(bstack1l11ll_opy_ (u"ࠧࡑࡧࡵࡪࡴࡸ࡭ࡪࡰࡪࠤࡸࡩࡡ࡯ࠢࡥࡩ࡫ࡵࡲࡦࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡶࡪࡹࡵ࡭ࡶࡶࠤࡸࡻ࡭࡮ࡣࡵࡽࠬร"))
    logger.debug(perform_scan(driver))
    bstack1l1111111_opy_ = driver.execute_async_script(bstack1lll1ll1l1_opy_.bstack1l1l1l11ll_opy_)
    return bstack1l1111111_opy_
  except Exception:
    logger.error(bstack1l11ll_opy_ (u"ࠣࡐࡲࠤࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡸࡻ࡭࡮ࡣࡵࡽࠥࡽࡡࡴࠢࡩࡳࡺࡴࡤ࠯ࠤฤ"))
    return {}
def perform_scan(driver, *args, **kwargs):
  global CONFIG
  global bstack1llll1llll_opy_
  bstack1ll1llll1_opy_ = not (bstack1111111_opy_(threading.current_thread(), bstack1l11ll_opy_ (u"ࠩ࡬ࡷࡆ࠷࠱ࡺࡖࡨࡷࡹ࠭ล"), None) and bstack1111111_opy_(
          threading.current_thread(), bstack1l11ll_opy_ (u"ࠪࡥ࠶࠷ࡹࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩฦ"), None))
  bstack1ll1111ll_opy_ = getattr(driver, bstack1l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡅ࠶࠷ࡹࡔࡪࡲࡹࡱࡪࡓࡤࡣࡱࠫว"), None) != True
  if not bstack1lll1ll1_opy_.bstack1l1ll11ll_opy_(CONFIG, bstack1llll1llll_opy_) or (bstack1ll1111ll_opy_ and bstack1ll1llll1_opy_):
    logger.warning(bstack1l11ll_opy_ (u"ࠧࡔ࡯ࡵࠢࡤࡲࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࠢࡶࡩࡸࡹࡩࡰࡰ࠯ࠤࡨࡧ࡮࡯ࡱࡷࠤࡷࡻ࡮ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡵࡦࡥࡳ࠴ࠢศ"))
    return {}
  try:
    bstack1ll1ll1111_opy_ = driver.execute_async_script(bstack1lll1ll1l1_opy_.perform_scan, {bstack1l11ll_opy_ (u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭ษ"): kwargs.get(bstack1l11ll_opy_ (u"ࠧࡥࡴ࡬ࡺࡪࡸ࡟ࡤࡱࡰࡱࡦࡴࡤࠨส"), None) or bstack1l11ll_opy_ (u"ࠨࠩห")})
    return bstack1ll1ll1111_opy_
  except Exception:
    logger.error(bstack1l11ll_opy_ (u"ࠤࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡸࡵ࡯ࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡶࡧࡦࡴ࠮ࠣฬ"))
    return {}